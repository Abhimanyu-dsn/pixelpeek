"use strict";(()=>{var De=`/*
 * Light, Atlassian-style UI: white surfaces, a blue accent, subtle 1px borders, compact
 * 12-14px type, 3-6px corner radii, and a soft two-layer overlay shadow. Monospace is
 * reserved for CSS-like values.
 */

:host {
  all: initial;

  --pp-font: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
  --pp-mono: ui-monospace, SFMono-Regular, Menlo, monospace;

  --pp-blue-300: #579DFF;  /* outline fill */
  --pp-blue-400: #0C66E4;  /* primary accent */
  --pp-blue-500: #0055CC;  /* hover / pressed */
  --pp-blue-a12: #E9F2FF;  /* selected surface */
  --pp-blue-a35: #85B8FF;  /* selected border */

  --pp-green-400: #1F845A;
  --pp-green-bg: #DCFFF1;
  --pp-red-400: #C9372C;
  --pp-red-bg: #FFECEB;
  --pp-amber-300: #A54800;
  --pp-amber-a15: #FFF7D6;
  --pp-amber-a40: #F5CD47;

  --pp-bg: #FFFFFF;
  --pp-bg-subtle: #F7F8F9;
  --pp-bg-hover: #F1F2F4;
  --pp-border: #DCDFE4;
  --pp-border-strong: #B3B9C4;
  --pp-text: #172B4D;
  --pp-text-subtle: #44546F;
  --pp-text-subtlest: #626F86;

  --pp-space-025: 2px;
  --pp-space-050: 4px;
  --pp-space-100: 8px;
  --pp-space-150: 12px;
  --pp-space-200: 16px;
  --pp-space-300: 24px;

  --pp-font-size-body-small: 12px;
  --pp-line-height-body-small: 16px;
  --pp-font-size-body: 14px;
  --pp-line-height-body: 20px;

  --pp-radius-small: 4px;
  --pp-radius: 8px;

  --pp-shadow-overlay: 0 8px 12px rgba(9, 30, 66, 0.15), 0 0 1px rgba(9, 30, 66, 0.31);
}

.pixelpeek-outline {
  position: fixed;
  pointer-events: none;
  border: 2px solid var(--pp-blue-400);
  background: rgba(12, 102, 228, 0.1);
  box-sizing: border-box;
  z-index: 1;
  transition: none;
}

.pixelpeek-outline.locked {
  border-color: var(--pp-blue-500);
  background: rgba(12, 102, 228, 0.14);
}

.pixelpeek-chip {
  position: fixed;
  pointer-events: none;
  background: var(--pp-bg);
  color: var(--pp-text);
  border: 1px solid var(--pp-border-strong);
  font: 500 var(--pp-font-size-body-small)/var(--pp-line-height-body-small) var(--pp-font);
  padding: var(--pp-space-025) var(--pp-space-100);
  border-radius: var(--pp-radius-small);
  z-index: 2;
  white-space: nowrap;
}

.pixelpeek-chip.locked {
  background: var(--pp-blue-400);
  border-color: var(--pp-blue-500);
  color: #ffffff;
}

/* The shell is placed and dragged; the card inside scrolls; the variants button hangs off the shell. */

.pp-close-btn {
  flex-shrink: 0;
  width: 24px;
  height: 24px;
  border: none;
  background: none;
  color: var(--pp-text-subtle);
  font-size: 13px;
  line-height: 1;
  border-radius: var(--pp-radius-small);
  cursor: pointer;
}

.pp-close-btn:hover {
  background: var(--pp-bg-hover);
  color: var(--pp-text);
}

.pp-note {
  margin: 0 0 var(--pp-space-050);
  font-size: 11px;
  color: var(--pp-text-subtlest);
}

.pp-dots {
  width: var(--pp-space-150);
  height: var(--pp-space-150);
  border: 2px solid var(--pp-blue-a35);
  border-top-color: var(--pp-blue-400);
  border-radius: 50%;
  animation: pp-spin 0.8s linear infinite;
}

@keyframes pp-spin {
  to { transform: rotate(360deg); }
}

.pp-swatch {
  display: inline-block;
  width: 10px;
  height: 10px;
  border-radius: var(--pp-radius-small);
  border: 1px solid var(--pp-border-strong);
}

/* ---- Page panel (Colors, Fonts, Assets, System, Clone) ---- */

.pp-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 6px 12px;
  border: 1px solid var(--pp-border-strong);
  border-radius: var(--pp-radius-small);
  background: var(--pp-bg);
  color: var(--pp-text);
  font: inherit;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
}

.pp-btn:hover { background: var(--pp-bg-hover); }

.pp-btn:disabled { opacity: 0.5; cursor: default; }

.pp-btn-primary { background: var(--pp-blue-400); border-color: var(--pp-blue-400); color: #fff; }

.pp-btn-primary:hover { background: var(--pp-blue-500); }

.pp-btn-primary:disabled:hover { background: var(--pp-blue-400); }

.pp-btn-row { display: flex; flex-wrap: wrap; gap: var(--pp-space-100); }

.pp-chip {
  padding: 3px 10px;
  border: 1px solid var(--pp-border);
  border-radius: 999px;
  background: var(--pp-bg);
  color: var(--pp-text-subtle);
  font: inherit;
  font-size: 12px;
  cursor: pointer;
}

.pp-chip:hover { background: var(--pp-bg-hover); }

.pp-chip[aria-pressed="true"] { background: var(--pp-blue-a12); border-color: var(--pp-blue-a35); color: var(--pp-blue-400); font-weight: 600; }

.pp-chips { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: var(--pp-space-150); }

.pp-empty {
  padding: var(--pp-space-300) var(--pp-space-100);
  text-align: center;
  font-size: 12px;
  color: var(--pp-text-subtle);
}

.pp-status { margin: var(--pp-space-100) 0 0; font-size: 12px; color: var(--pp-text-subtle); }

.pp-status.pp-ok { color: var(--pp-green-400); }

.pp-status.pp-warn { color: var(--pp-amber-300); }

/* Palette */

.pp-pair {
  display: flex;
  align-items: center;
  gap: var(--pp-space-100);
  padding: 6px 0;
  border-bottom: 1px solid var(--pp-border);
  font-size: 12px;
}

.pp-pair:last-child { border-bottom: none; }

.pp-pair-sample {
  flex-shrink: 0;
  width: 40px;
  height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid var(--pp-border);
  border-radius: var(--pp-radius-small);
  font-weight: 700;
}

.pp-pair-info { flex: 1; min-width: 0; }

.pp-pair-hex { font: 11px/14px var(--pp-mono); color: var(--pp-text-subtle); }

.pp-pair-ratio { font-weight: 700; }

.pp-tag {
  display: inline-block;
  padding: 0 6px;
  border-radius: 999px;
  font-size: 10px;
  font-weight: 700;
  line-height: 16px;
}

.pp-tag-pass { background: var(--pp-green-bg); color: var(--pp-green-400); }

.pp-tag-fail { background: var(--pp-red-bg); color: var(--pp-red-400); }

/* Fonts */

/* Assets */

.pp-assets { display: grid; grid-template-columns: repeat(3, 1fr); gap: var(--pp-space-100); }

.pp-asset {
  position: relative;
  border: 1px solid var(--pp-border);
  border-radius: var(--pp-radius-small);
  overflow: hidden;
  background: var(--pp-bg);
}

.pp-asset-thumb {
  height: 84px;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: var(--pp-bg-subtle);
  background-image: linear-gradient(45deg, #EBECF0 25%, transparent 25%, transparent 75%, #EBECF0 75%), linear-gradient(45deg, #EBECF0 25%, transparent 25%, transparent 75%, #EBECF0 75%);
  background-size: 12px 12px;
  background-position: 0 0, 6px 6px;
  font-size: 11px;
  font-weight: 700;
  color: var(--pp-text-subtlest);
}

.pp-asset-thumb img { max-width: 100%; max-height: 100%; object-fit: contain; }

.pp-asset-meta { padding: 4px 6px; font-size: 10px; color: var(--pp-text-subtle); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.pp-asset-dl {
  position: absolute;
  top: 4px;
  right: 4px;
  width: 22px;
  height: 22px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  border: 1px solid var(--pp-border-strong);
  border-radius: var(--pp-radius-small);
  background: var(--pp-bg);
  color: var(--pp-text);
  cursor: pointer;
}

.pp-asset-dl:hover { background: var(--pp-blue-a12); color: var(--pp-blue-400); }

/* Design system */

.pp-scale { margin-bottom: var(--pp-space-150); }

.pp-scale-name { margin-bottom: 4px; font-size: 12px; font-weight: 700; text-transform: capitalize; }

.pp-scale-strip { display: grid; grid-template-columns: repeat(11, 1fr); border: 1px solid var(--pp-border); border-radius: var(--pp-radius-small); overflow: hidden; }

.pp-scale-step { height: 32px; border: none; padding: 0; cursor: pointer; }

.pp-scale-step:hover { outline: 2px solid var(--pp-text); outline-offset: -2px; }

.pp-code {
  max-height: 220px;
  margin: var(--pp-space-100) 0 0;
  padding: var(--pp-space-100) var(--pp-space-150);
  overflow: auto;
  background: var(--pp-bg-subtle);
  border: 1px solid var(--pp-border);
  border-radius: var(--pp-radius-small);
  font: 11px/16px var(--pp-mono);
  color: var(--pp-text);
  white-space: pre;
  user-select: text;
}

.pp-list { margin: var(--pp-space-100) 0 0; padding-left: 18px; font-size: 12px; color: var(--pp-text-subtle); }

/* ---- Designers first, developers second ---- */

.pp-audience {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--pp-space-100);
  margin: var(--pp-space-200) 0 var(--pp-space-050);
  padding: 6px var(--pp-space-100);
  border-radius: var(--pp-radius-small);
  background: var(--pp-bg-subtle);
  border: 1px solid var(--pp-border);
  font-size: 12px;
  font-weight: 700;
  color: var(--pp-text);
}

.pp-audience-hint { font-weight: 400; font-size: 11px; color: var(--pp-text-subtlest); text-align: right; }

.pp-btn-wide { flex: 1; }

.pp-status-ok { color: var(--pp-green-400); }

.pp-status-warn { color: var(--pp-amber-300); }

.pp-dev-actions { display: flex; flex-wrap: wrap; gap: var(--pp-space-100); padding: var(--pp-space-100) 0; }

/* Tailwind chips */

.pp-tw { display: flex; flex-wrap: wrap; gap: 4px; padding: var(--pp-space-050) 0 var(--pp-space-100); }

.pp-tw-chip {
  padding: 1px 6px;
  border: 1px solid var(--pp-border);
  border-radius: var(--pp-radius-small);
  background: var(--pp-bg-subtle);
  color: var(--pp-text);
  font: 11px/18px var(--pp-mono);
  cursor: pointer;
}

.pp-tw-chip:hover { background: var(--pp-blue-a12); border-color: var(--pp-blue-a35); color: var(--pp-blue-400); }

/* Exit from inspecting */

.pp-exit-pill {
  position: fixed;
  top: 16px;
  left: 50%;
  transform: translateX(-50%);
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 7px 10px 7px 12px;
  border: 1px solid var(--pp-border-strong);
  border-radius: 999px;
  background: var(--pp-bg);
  color: var(--pp-text);
  box-shadow: var(--pp-shadow-overlay);
  font: 600 12px/16px var(--pp-font);
  cursor: pointer;
  z-index: 4;
  pointer-events: auto;
}

.pp-exit-pill:hover { background: var(--pp-red-bg); border-color: var(--pp-red-400); color: var(--pp-red-400); }

.pp-exit-pill kbd { padding: 0 6px; border: 1px solid var(--pp-border); border-radius: 4px; background: var(--pp-bg-subtle); color: var(--pp-text-subtle); font: 10px/16px var(--pp-mono); }

/* Alt-measuring */

.pixelpeek-measure-box { position: fixed; pointer-events: none; box-sizing: border-box; border: 1px dashed #E5484D; background: rgba(229, 72, 77, 0.06); z-index: 1; }

.pixelpeek-measure-line { position: fixed; pointer-events: none; background: #E5484D; z-index: 2; }

.pixelpeek-measure-label { position: fixed; pointer-events: none; transform: translate(-50%, -50%); padding: 0 5px; border-radius: 3px; background: #E5484D; color: #fff; font: 600 11px/16px var(--pp-font); z-index: 2; }

/* Saved library */

.pp-saved { padding: var(--pp-space-150); margin-bottom: var(--pp-space-100); border: 1px solid var(--pp-border); border-radius: var(--pp-radius-small); }

.pp-saved-head { display: flex; justify-content: space-between; gap: var(--pp-space-100); font-size: 13px; }

.pp-saved-head b { font-family: var(--pp-mono); font-size: 12px; color: var(--pp-blue-400); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.pp-saved-head span, .pp-saved-meta { font-size: 11px; color: var(--pp-text-subtlest); }

.pp-saved-meta { display: flex; align-items: center; gap: 4px; margin-top: 2px; }

.pp-saved-text { margin-top: 4px; font-size: 12px; color: var(--pp-text-subtle); }

.pp-asset-sub { padding-top: 0; color: var(--pp-text-subtlest); }

/* ================================================================================================
   The overlay: one panel hovering over the page, on the right. It is position:fixed, so the page
   keeps its own width and layout.
   ================================================================================================ */

.pp-ov {
  position: fixed;
  top: 12px;
  right: 12px;
  bottom: 12px;
  width: 400px;
  max-width: calc(100vw - 24px);
  display: flex;
  flex-direction: column;
  background: var(--pp-bg);
  color: var(--pp-text);
  border: 1px solid var(--pp-border);
  border-radius: 14px;
  box-shadow: var(--pp-shadow-overlay);
  font: var(--pp-font-size-body)/var(--pp-line-height-body) var(--pp-font);
  z-index: 3;
  pointer-events: auto;
  overflow: hidden;
}

.pp-ov-top { flex-shrink: 0; padding: 10px 12px 0; border-bottom: 1px solid var(--pp-border); background: var(--pp-bg); }

.pp-ov-icons { display: flex; justify-content: flex-end; gap: 4px; }

.pp-ov-icon {
  width: 34px;
  height: 34px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  border: none;
  border-radius: 8px;
  background: none;
  color: var(--pp-text);
  cursor: pointer;
}

.pp-ov-icon:hover { background: var(--pp-bg-hover); }

.pp-ov-icon[aria-pressed="true"] { background: var(--pp-blue-a12); color: var(--pp-blue-400); }

.pp-ov-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 10px 2px 8px; }

.pp-ov-title { min-width: 0; display: flex; align-items: baseline; gap: 8px; }

.pp-ov-title b { font: 600 13px/18px var(--pp-mono); color: var(--pp-blue-400); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.pp-ov-title span { font-size: 11px; color: var(--pp-text-subtlest); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

.pp-ov-tabs { display: flex; gap: 4px; padding: 0 0 10px; }

.pp-ov-tab {
  flex: 1;
  padding: 6px 4px;
  border: none;
  border-radius: 999px;
  background: none;
  color: var(--pp-text-subtle);
  font: 600 12px/16px var(--pp-font);
  white-space: nowrap;
  cursor: pointer;
}

.pp-ov-tab:hover { background: var(--pp-bg-hover); color: var(--pp-text); }

.pp-ov-tab[aria-selected="true"] { background: var(--pp-text); color: #fff; }

.pp-ov-body { flex: 1; min-height: 0; overflow-y: auto; padding: 14px 14px 20px; background: var(--pp-bg); }

.pp-ov-body::-webkit-scrollbar { width: 8px; }

.pp-ov-body::-webkit-scrollbar-track { background: transparent; }

.pp-ov-body::-webkit-scrollbar-thumb { background: var(--pp-border-strong); border-radius: 4px; }

.pp-ov-foot {
  flex-shrink: 0;
  display: flex;
  justify-content: space-between;
  padding: 8px 14px;
  border-top: 1px solid var(--pp-border);
  background: var(--pp-bg-subtle);
  font-size: 11px;
  color: var(--pp-text-subtlest);
}

.pp-toast {
  position: absolute;
  left: 50%;
  bottom: 44px;
  transform: translate(-50%, 8px);
  padding: 6px 12px;
  border-radius: 999px;
  background: var(--pp-text);
  color: #fff;
  font-size: 12px;
  font-weight: 600;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.15s, transform 0.15s;
}

.pp-toast-on { opacity: 1; transform: translate(-50%, 0); }

.pp-close-btn svg { display: block; margin: auto; }

/* Style groups: Colors, Typography, Effect, Animation, Layout guide */

.pp-btn[aria-pressed="true"] { background: var(--pp-blue-a12); border-color: var(--pp-blue-a35); color: var(--pp-blue-400); }

.pp-btn-dark { background: #1D2125; border-color: #1D2125; color: #fff; }

.pp-btn-dark:hover { background: #2C333A; }

.pp-btn-wide { width: 100%; }

.pp-dev-actions { display: flex; flex-wrap: wrap; gap: var(--pp-space-100); padding: var(--pp-space-100) 0; }

.pp-status-ok { color: var(--pp-green-400); }

/* Box model */

.pp-boxmodel { margin: 8px 0; font: 10px/14px var(--pp-mono); color: var(--pp-text-subtle); }

.pp-bm { position: relative; padding: 18px 26px; border: 1px dashed var(--pp-border-strong); border-radius: 4px; text-align: center; }

.pp-bm-margin { background: #FFF0E6; }

.pp-bm-border { background: #FFE9A8; border-style: solid; }

.pp-bm-padding { background: #DFF5E7; }

.pp-bm-content { padding: 8px; background: #CFE3FF; border-style: solid; color: var(--pp-text); }

.pp-bm-name { position: absolute; top: 1px; left: 5px; font-size: 9px; text-transform: uppercase; opacity: 0.7; }

.pp-bm-t, .pp-bm-b { position: absolute; left: 50%; transform: translateX(-50%); }

.pp-bm-t { top: 2px; }

.pp-bm-b { bottom: 2px; }

.pp-bm-l, .pp-bm-r { position: absolute; top: 50%; transform: translateY(-50%); }

.pp-bm-l { left: 6px; }

.pp-bm-r { right: 6px; }

/* Layout guides drawn on the page */

.pp-guides { position: fixed; inset: 0; pointer-events: none; z-index: 1; }

.pp-guide { position: fixed; box-sizing: border-box; border-style: solid; border-color: transparent; }

.pp-guide-margin { border-color: rgba(255, 153, 51, 0.38); }

.pp-guide-padding { border-color: rgba(52, 168, 83, 0.38); }

.pp-guide-content { border: 1px dashed rgba(12, 102, 228, 0.9); background: rgba(12, 102, 228, 0.08); }

.pp-guide-label { position: fixed; transform: translate(-50%, -50%); padding: 0 4px; border-radius: 3px; font: 600 10px/14px var(--pp-font); color: #fff; }

.pp-guide-label-margin { background: #E07B12; }

.pp-guide-label-padding { background: #2A8F47; }

/* Design system components */

.pp-comp { margin-bottom: 8px; border: 1px solid var(--pp-border); border-radius: var(--pp-radius-small); overflow: hidden; }

.pp-comp-preview { display: flex; align-items: center; padding: 14px; background: var(--pp-bg-subtle); overflow: hidden; }

.pp-comp-preview > span { max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.pp-comp-meta { display: flex; align-items: center; justify-content: space-between; padding: 6px 10px; font-size: 11px; color: var(--pp-text-subtle); }

/* Account */

.pp-account { display: flex; flex-direction: column; align-items: center; gap: 8px; padding: 28px 8px; text-align: center; }

.pp-account-avatar { width: 56px; height: 56px; display: flex; align-items: center; justify-content: center; border-radius: 50%; background: var(--pp-bg-hover); color: var(--pp-text-subtlest); font-size: 22px; font-weight: 700; }

/* Device list */

.pp-dev-search input {
  width: 100%;
  box-sizing: border-box;
  padding: 9px 12px;
  border: 1px solid var(--pp-border-strong);
  border-radius: 10px;
  background: var(--pp-bg);
  color: var(--pp-text);
  font: inherit;
}

.pp-dev-search input:focus { outline: 2px solid var(--pp-blue-a35); border-color: var(--pp-blue-400); }

.pp-dev-groups { margin-top: 10px; background: var(--pp-bg-subtle); border-radius: 10px; padding: 4px 0; }

.pp-dev-cat {
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  padding: 10px 12px;
  border: none;
  background: none;
  color: var(--pp-text-subtle);
  font: 700 12px/16px var(--pp-font);
  letter-spacing: 0.04em;
  cursor: pointer;
}

.pp-dev-cat:hover { color: var(--pp-text); }

.pp-dev-cat-name, .pp-dev-cat-count { display: inline-flex; align-items: center; gap: 8px; }

.pp-dev-cat-count { font-weight: 400; color: var(--pp-text-subtlest); }

.pp-dev-cat[aria-expanded="true"] .pp-dev-cat-count svg { transform: rotate(90deg); }

.pp-dev-list { padding: 0 6px 6px; }

.pp-dev-row {
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  padding: 8px 10px;
  border: none;
  border-radius: 8px;
  background: none;
  color: var(--pp-text);
  font: 13px/18px var(--pp-font);
  text-align: left;
  cursor: pointer;
}

.pp-dev-row:hover { background: var(--pp-bg); box-shadow: inset 0 0 0 1px var(--pp-border); }

.pp-dev-size { font: 11px/16px var(--pp-mono); color: var(--pp-text-subtlest); }

/* ================================================================================================
   Responsive device preview
   ================================================================================================ */

.pp-dp {
  position: fixed;
  inset: 0;
  display: none;
  flex-direction: column;
  background: rgba(15, 20, 32, 0.86);
  backdrop-filter: blur(3px);
  z-index: 5;
  pointer-events: auto;
  font: var(--pp-font-size-body-small)/var(--pp-line-height-body-small) var(--pp-font);
  color: #fff;
}

.pp-dp-bar { display: flex; align-items: center; flex-wrap: wrap; gap: 10px; padding: 10px 16px; background: rgba(0, 0, 0, 0.35); }

.pp-dp-title { display: flex; align-items: baseline; gap: 8px; margin-right: auto; }

.pp-dp-title b { font-size: 14px; }

.pp-dp-title span, .pp-dp-scale { color: rgba(255, 255, 255, 0.65); font-family: var(--pp-mono); }

.pp-dp-bar .pp-btn { background: rgba(255, 255, 255, 0.1); border-color: rgba(255, 255, 255, 0.25); color: #fff; }

.pp-dp-bar .pp-btn:hover { background: rgba(255, 255, 255, 0.2); }

.pp-dp-bar kbd { margin-left: 4px; padding: 0 5px; border: 1px solid rgba(255, 255, 255, 0.35); border-radius: 4px; font: 10px/14px var(--pp-mono); }

.pp-dp-size { display: flex; align-items: center; gap: 6px; }

.pp-dp-size input { width: 70px; padding: 4px 6px; border: 1px solid rgba(255, 255, 255, 0.3); border-radius: 6px; background: rgba(255, 255, 255, 0.1); color: #fff; font: 12px var(--pp-mono); }

.pp-dp-presets { display: flex; gap: 4px; }

.pp-dp-presets .pp-chip { background: rgba(255, 255, 255, 0.08); border-color: rgba(255, 255, 255, 0.2); color: #fff; padding: 2px 8px; }

.pp-dp-stage { flex: 1; min-height: 0; display: flex; align-items: center; justify-content: center; overflow: hidden; }

.pp-dp-stage > .pp-dev { transform-origin: center center; flex-shrink: 0; }

/* The mockup. Its size and bezel thickness come in as custom properties from the preview code. */

.pp-dev { position: relative; box-sizing: border-box; background: #14171C; border-radius: var(--r); box-shadow: 0 0 0 2px #3A3F47, 0 24px 60px rgba(0, 0, 0, 0.5); }

.pp-dev-screen {
  position: absolute;
  left: var(--bl);
  top: var(--bt);
  width: var(--sw);
  height: var(--sh);
  overflow: hidden;
  border-radius: max(0px, calc(var(--r) - 12px));
  background: #fff;
}

.pp-dp-frame { display: block; width: 100%; height: 100%; border: 0; background: #fff; }

.pp-dp-blocked {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 10px;
  padding: 24px;
  background: #fff;
  color: var(--pp-text);
  text-align: center;
}

.pp-dp-blocked[hidden] { display: none; }

.pp-dp-blocked p { margin: 0; color: var(--pp-text-subtle); }

.pp-dev-deco { position: absolute; display: none; pointer-events: none; }

/* Phones with a Dynamic Island, a notch or a punch-hole camera */

.pp-dev-island .pp-dev-a { display: block; top: calc(var(--bt) + 11px); left: 50%; width: 118px; height: 34px; margin-left: -59px; border-radius: 20px; background: #000; z-index: 2; }

.pp-dev-notch .pp-dev-a { display: block; top: var(--bt); left: 50%; width: 160px; height: 30px; margin-left: -80px; border-radius: 0 0 20px 20px; background: #14171C; z-index: 2; }

.pp-dev-punch .pp-dev-a { display: block; top: calc(var(--bt) + 14px); left: 50%; width: 18px; height: 18px; margin-left: -9px; border-radius: 50%; background: #000; z-index: 2; }

.pp-dev-fold .pp-dev-a { display: block; top: calc(var(--bt) + 14px); left: 50%; width: 16px; height: 16px; margin-left: -8px; border-radius: 50%; background: #000; z-index: 2; }

.pp-dev-island .pp-dev-b, .pp-dev-notch .pp-dev-b, .pp-dev-punch .pp-dev-b, .pp-dev-fold .pp-dev-b { display: block; bottom: calc(var(--bb) + 8px); left: 50%; width: 134px; height: 5px; margin-left: -67px; border-radius: 3px; background: rgba(0, 0, 0, 0.55); z-index: 2; }

/* iPhone SE: forehead speaker and a home button */

.pp-dev-home .pp-dev-a { display: block; top: 28px; left: 50%; width: 60px; height: 6px; margin-left: -30px; border-radius: 3px; background: #2B2F36; }

.pp-dev-home .pp-dev-b { display: block; bottom: 17px; left: 50%; width: 48px; height: 48px; margin-left: -24px; border-radius: 50%; border: 2px solid #3A3F47; }

.pp-dev-tablet .pp-dev-a { display: block; top: 8px; left: 50%; width: 8px; height: 8px; margin-left: -4px; border-radius: 50%; background: #2B2F36; }

/* Laptop: the lid, then a base under it */

.pp-dev-laptop { box-shadow: 0 0 0 2px #3A3F47; margin-bottom: 28px; }

.pp-dev-laptop .pp-dev-a { display: block; left: -6%; right: -6%; bottom: -14px; height: 14px; border-radius: 0 0 18px 18px; background: linear-gradient(#C9CDD3, #9EA3AB); box-shadow: 0 18px 30px rgba(0, 0, 0, 0.45); }

.pp-dev-laptop .pp-dev-b { display: block; left: 50%; bottom: -14px; width: 110px; height: 6px; margin-left: -55px; border-radius: 0 0 8px 8px; background: #8A8F97; }

/* Monitor: a chin and a stand */

.pp-dev-monitor { margin-bottom: 64px; }

.pp-dev-monitor .pp-dev-a { display: block; left: 50%; bottom: -46px; width: 70px; height: 46px; margin-left: -35px; background: linear-gradient(90deg, #8A8F97, #C9CDD3, #8A8F97); }

.pp-dev-monitor .pp-dev-b { display: block; left: 50%; bottom: -56px; width: 190px; height: 10px; margin-left: -95px; border-radius: 6px; background: linear-gradient(#C9CDD3, #8A8F97); }

/* Watch: a crown and two bands */

.pp-dev-watch { margin: 80px 0; }

.pp-dev-watch .pp-dev-a { display: block; right: -9px; top: 22%; width: 9px; height: 36px; border-radius: 0 5px 5px 0; background: #3A3F47; }

.pp-dev-watch .pp-dev-b { display: block; left: 18%; right: 18%; top: -76px; height: 80px; border-radius: 12px 12px 0 0; background: #23272E; z-index: -1; }

.pp-dev-watch .pp-dev-c { display: block; left: 18%; right: 18%; bottom: -76px; height: 80px; border-radius: 0 0 12px 12px; background: #23272E; z-index: -1; }

.pp-dev-plain { background: #fff; box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.35); }

.pp-dev-plain .pp-dev-screen { border-radius: 10px; }

.pp-landscape.pp-dev-island .pp-dev-a, .pp-landscape.pp-dev-notch .pp-dev-a, .pp-landscape.pp-dev-punch .pp-dev-a,
.pp-landscape.pp-dev-island .pp-dev-b, .pp-landscape.pp-dev-notch .pp-dev-b, .pp-landscape.pp-dev-punch .pp-dev-b { display: none; }

@keyframes pp-ov-open { from { opacity: 0.4; transform: translateY(-6px); } to { opacity: 1; transform: none; } }

.pp-ov:not(.pp-ov-collapsed) { animation: pp-ov-open 0.18s ease-out; }

/* While picking an element nothing of the panel is shown: the tools live in the floating pill. */
.pp-ov-collapsed { display: none; }

.pp-ov-nav { flex-shrink: 0; padding: 4px 12px 0; background: var(--pp-bg-subtle); border-bottom: 1px solid var(--pp-border); }

.pp-ov-head { padding: 8px 2px 8px; }

.pp-ov-tabs { padding: 0 0 10px; }

.pp-ov-body { background: var(--pp-bg); }


/* ---- Dock: one click from any tool to any other ---- */

.pp-dock {
  position: fixed;
  left: 50%;
  bottom: 18px;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  gap: 2px;
  max-width: calc(100vw - 24px);
  padding: 4px;
  overflow-x: auto;
  background: var(--pp-bg);
  border: 1px solid var(--pp-border);
  border-radius: 12px;
  box-shadow: var(--pp-shadow-overlay);
  font: 600 12px/16px var(--pp-font);
  color: var(--pp-text);
  z-index: 4;
  pointer-events: auto;
  user-select: none;
}

.pp-dock-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 10px;
  border: none;
  border-radius: 8px;
  background: none;
  color: var(--pp-text-subtle);
  font: inherit;
  white-space: nowrap;
  cursor: pointer;
}

.pp-dock-btn:hover { background: var(--pp-bg-hover); color: var(--pp-text); }

.pp-dock-btn[aria-pressed="true"] { background: var(--pp-blue-a12); color: var(--pp-blue-400); }

.pp-dock-btn svg { flex-shrink: 0; }

.pp-dock-sep { width: 1px; height: 20px; margin: 0 4px; background: var(--pp-border); flex-shrink: 0; }

.pp-dock-close { padding: 6px 8px; }

.pp-dock-close:hover { background: var(--pp-red-bg); color: var(--pp-red-400); }

/* ---- Hover card: the basics of whatever is under the pointer ---- */

.pp-hover {
  position: fixed;
  width: 250px;
  padding: 8px 10px 6px;
  background: var(--pp-bg);
  color: var(--pp-text);
  border: 1px solid var(--pp-border-strong);
  border-radius: 10px;
  box-shadow: var(--pp-shadow-overlay);
  font: 12px/18px var(--pp-font);
  pointer-events: none;
  z-index: 2;
}

.pp-hover-head { display: flex; justify-content: space-between; gap: 8px; padding-bottom: 4px; margin-bottom: 4px; border-bottom: 1px solid var(--pp-border); }

.pp-hover-head b { font: 600 12px/18px var(--pp-mono); color: var(--pp-blue-400); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.pp-hover-head span { color: var(--pp-text-subtlest); white-space: nowrap; }

.pp-hover-row { display: flex; justify-content: space-between; gap: 10px; }

.pp-hover-row > span:first-child { color: var(--pp-text-subtle); }

.pp-hover-row > span:last-child { display: inline-flex; align-items: center; gap: 5px; text-align: right; font: 11px/18px var(--pp-mono); }

.pp-hover-foot { margin-top: 4px; padding-top: 4px; border-top: 1px solid var(--pp-border); font-size: 11px; color: var(--pp-text-subtlest); }

.pp-hv-ok { color: var(--pp-green-400); font-weight: 700; }

.pp-hv-bad { color: var(--pp-red-400); font-weight: 700; }

/* Leave room for the dock so the two never overlap. */

.pp-ov { bottom: 72px; }

.pp-ov-collapsed { bottom: auto; }

/* ================================================================================================
   Cards: every group of information is a collapsible card with an icon.
   ================================================================================================ */

.pp-card { margin-bottom: 10px; border: 1px solid var(--pp-border); border-radius: 10px; background: var(--pp-bg); overflow: hidden; }

.pp-card-head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 9px 10px 9px 12px;
  background: var(--pp-bg-subtle);
  cursor: pointer;
  user-select: none;
}

.pp-card-head:hover { background: var(--pp-bg-hover); }
.pp-card-open > .pp-card-head { border-bottom: 1px solid var(--pp-border); }
.pp-card-ico { display: inline-flex; color: var(--pp-blue-400); }
.pp-card-head h3 { flex: 1; min-width: 0; margin: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 13px; font-weight: 700; }
.pp-card-meta { padding: 0 7px; border-radius: 999px; background: var(--pp-bg-hover); color: var(--pp-text-subtle); font-size: 11px; line-height: 18px; }
.pp-card-chev { display: inline-flex; color: var(--pp-text-subtlest); transition: transform 0.15s; }
.pp-card-open > .pp-card-head .pp-card-chev { transform: rotate(90deg); }
.pp-card-body { padding: 12px; }

.pp-card-copy {
  padding: 1px 8px;
  border: 1px solid var(--pp-border);
  border-radius: 999px;
  background: var(--pp-bg);
  color: var(--pp-text-subtle);
  font: 600 11px/18px var(--pp-font);
  white-space: nowrap;
  cursor: pointer;
}

.pp-card-copy:hover { background: var(--pp-blue-a12); border-color: var(--pp-blue-a35); color: var(--pp-blue-400); }
.pp-btn-sm { padding: 1px 8px; font-size: 11px; line-height: 18px; }

.pp-sub { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin: 12px 0 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: var(--pp-text-subtle); }

/* Label + value chips: a click copies. Only values worth pasting get the copy affordance. */
.pp-cv-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }

.pp-cv {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 1px;
  min-width: 0;
  padding: 6px 24px 6px 9px;
  border: 1px solid var(--pp-border);
  border-radius: 8px;
  background: var(--pp-bg);
  color: var(--pp-text);
  font: inherit;
  text-align: left;
  cursor: pointer;
}

.pp-cv:hover { border-color: var(--pp-blue-400); background: var(--pp-blue-a12); }
.pp-cv-off { cursor: default; background: var(--pp-bg-subtle); }
.pp-cv-off:hover { border-color: var(--pp-border); background: var(--pp-bg-subtle); }
.pp-cv-k { font-size: 10px; line-height: 14px; text-transform: uppercase; letter-spacing: 0.04em; color: var(--pp-text-subtlest); }
.pp-cv-v { display: inline-flex; align-items: center; gap: 5px; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font: 600 12px/18px var(--pp-mono); }
.pp-cv-i { position: absolute; top: 6px; right: 8px; opacity: 0; color: var(--pp-blue-400); font-size: 12px; transition: opacity 0.1s; }
.pp-cv:hover .pp-cv-i, .pp-fam:hover .pp-cv-i { opacity: 1; }

/* Colour squares */
.pp-squares { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; }
.pp-sq { display: flex; flex-direction: column; gap: 3px; min-width: 0; padding: 0; border: none; background: none; font: inherit; text-align: left; cursor: pointer; }
.pp-sq-fill { position: relative; display: block; aspect-ratio: 1; border: 1px solid var(--pp-border-strong); border-radius: 8px; overflow: hidden; }
.pp-sq-copy { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; background: rgba(23, 43, 77, 0.55); color: #fff; font: 700 11px/16px var(--pp-font); opacity: 0; transition: opacity 0.12s; }
.pp-sq:hover .pp-sq-copy, .pp-sq:focus-visible .pp-sq-copy { opacity: 1; }
.pp-sq-hex { font: 600 10px/14px var(--pp-mono); color: var(--pp-text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.pp-sq-sub { font-size: 10px; line-height: 12px; color: var(--pp-text-subtlest); text-transform: capitalize; }

.pp-grad { position: relative; display: block; width: 100%; height: 34px; margin-top: 10px; border: 1px solid var(--pp-border-strong); border-radius: 8px; cursor: pointer; }
.pp-grad span { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; border-radius: 7px; background: rgba(23, 43, 77, 0.55); color: #fff; font: 700 11px/16px var(--pp-font); opacity: 0; transition: opacity 0.12s; }
.pp-grad:hover span { opacity: 1; }

.pp-contrast { display: flex; align-items: center; flex-wrap: wrap; gap: 6px; margin-top: 10px; }
.pp-contrast-ratio { font: 700 13px/18px var(--pp-mono); }

/* Typography */
.pp-fam { position: relative; display: flex; align-items: center; gap: 12px; width: 100%; box-sizing: border-box; margin-bottom: 8px; padding: 8px 28px 8px 10px; border: 1px solid var(--pp-border); border-radius: 8px; background: var(--pp-bg); color: var(--pp-text); font: inherit; text-align: left; cursor: pointer; }
.pp-fam:hover { border-color: var(--pp-blue-400); background: var(--pp-blue-a12); }
.pp-fam-static { cursor: default; padding-right: 10px; }
.pp-fam-static:hover { border-color: var(--pp-border); background: var(--pp-bg); }
.pp-fam-sample { flex-shrink: 0; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; padding: 0; border: none; border-radius: 8px; background: var(--pp-bg-hover); color: var(--pp-text); font-size: 24px; line-height: 1; cursor: pointer; }
.pp-fam-info { display: flex; flex-direction: column; min-width: 0; }
.pp-fam-info b { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 13px; }
.pp-fam-info span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 11px; color: var(--pp-text-subtlest); }
.pp-fam-info a { color: var(--pp-blue-400); }

/* Code blocks you can click to copy */
.pp-code-copy { display: block; width: 100%; margin-top: 8px; padding: 0; border: none; background: none; text-align: left; cursor: pointer; }
.pp-code-copy:hover .pp-code { border-color: var(--pp-blue-400); }
.pp-code-copy .pp-code { margin: 0; }

.pp-hover-foot kbd { padding: 0 4px; border: 1px solid var(--pp-border-strong); border-radius: 3px; background: var(--pp-bg-subtle); font: 600 10px/14px var(--pp-mono); color: var(--pp-text-subtle); }
.pp-hover-flash { color: var(--pp-green-400); font-weight: 700; }

.pp-ov-head-btns { display: flex; align-items: center; gap: 2px; }
.pp-ov-head-btns .pp-close-btn[aria-pressed="true"] { background: var(--pp-blue-a12); color: var(--pp-blue-400); }

/* ================================================================================================
   The floating tool pill: frosted glass, a dot at rest, a vertical stack on hover. Draggable.
   ================================================================================================ */

.pp-pill { position: fixed; width: 40px; height: 40px; z-index: 5; pointer-events: auto; font: 600 12px/16px var(--pp-font); }

.pp-pill-card {
  position: absolute;
  left: 0;
  top: 0;
  width: 40px;
  height: 40px;
  display: flex;
  flex-direction: column;
  align-items: center;
  box-sizing: border-box;
  overflow: hidden;
  border: 1px solid rgba(9, 30, 66, 0.14);
  border-radius: 20px;
  background: rgba(255, 255, 255, 0.72);
  -webkit-backdrop-filter: blur(14px) saturate(1.6);
  backdrop-filter: blur(14px) saturate(1.6);
  box-shadow: 0 6px 20px rgba(9, 30, 66, 0.18), 0 0 0 3px rgba(12, 102, 228, 0.12);
  transition: height 0.18s ease, box-shadow 0.18s ease;
}

.pp-pill-up .pp-pill-card { top: auto; bottom: 0; flex-direction: column-reverse; }
.pp-pill-open { height: 192px; box-shadow: 0 10px 28px rgba(9, 30, 66, 0.22), 0 0 0 3px rgba(12, 102, 228, 0.2); }
.pp-pill-dragging .pp-pill-card { box-shadow: 0 12px 32px rgba(9, 30, 66, 0.28), 0 0 0 3px rgba(12, 102, 228, 0.35); }

.pp-pill-mark, .pp-pill-btn {
  position: relative;
  flex-shrink: 0;
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 1px 0;
  padding: 0;
  border: none;
  border-radius: 50%;
  background: none;
  color: var(--pp-text);
  cursor: pointer;
}

.pp-pill-mark { color: var(--pp-blue-400); cursor: grab; touch-action: none; }
.pp-pill-dragging .pp-pill-mark { cursor: grabbing; }
.pp-pill-btn { opacity: 0; transition: opacity 0.12s 0.04s, background 0.12s; }
.pp-pill-open .pp-pill-btn { opacity: 1; }
.pp-pill-btn:hover, .pp-pill-btn:focus-visible { background: rgba(9, 30, 66, 0.08); }
.pp-pill-btn[aria-pressed="true"] { background: var(--pp-blue-a12); color: var(--pp-blue-400); }
.pp-pill-ico { display: inline-flex; }

.pp-pill-tip, .pp-pill-note {
  position: absolute;
  top: 50%;
  left: calc(100% + 10px);
  transform: translateY(-50%);
  padding: 3px 8px;
  border-radius: 6px;
  background: #1D2125;
  color: #fff;
  font: 600 11px/16px var(--pp-font);
  white-space: nowrap;
  opacity: 0;
  pointer-events: none;
}

.pp-pill-btn:hover .pp-pill-tip, .pp-pill-btn:focus-visible .pp-pill-tip { opacity: 1; }
.pp-pill-left .pp-pill-tip, .pp-pill-left .pp-pill-note { left: auto; right: calc(100% + 10px); }
.pp-pill-note { transition: opacity 0.15s; }
.pp-pill-note-on { opacity: 1; }

@media (prefers-reduced-motion: reduce) {
  .pp-pill-card, .pp-pill-btn, .pp-pill-note { transition: none; }
}

.pp-pill-mark img { display: block; width: 28px; height: 28px; border-radius: 8px; pointer-events: none; user-select: none; }

/* The tools in the panel's top row (shown instead of the floating pill once something is selected). */
.pp-ov-tools { display: flex; gap: 4px; padding: 8px 0 2px; }
.pp-ov-tool { flex: 1; display: flex; align-items: center; justify-content: center; gap: 5px; min-width: 0; padding: 6px 4px; border: 1px solid var(--pp-border); border-radius: 8px; background: var(--pp-bg); color: var(--pp-text-subtle); font: 600 11px/16px var(--pp-font); cursor: pointer; }
.pp-ov-tool:hover { background: var(--pp-bg-hover); color: var(--pp-text); }
.pp-ov-tool[aria-pressed="true"] { background: var(--pp-blue-a12); border-color: var(--pp-blue-a35); color: var(--pp-blue-400); }
.pp-ov-tool span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.pp-ov-tool svg { flex-shrink: 0; }

.pp-sq-sub { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

/* Design system: declared variables */
.pp-toks { display: flex; flex-direction: column; gap: 4px; margin-bottom: 6px; }
.pp-tok { display: flex; align-items: center; gap: 8px; width: 100%; box-sizing: border-box; padding: 5px 8px; border: 1px solid var(--pp-border); border-radius: 8px; background: var(--pp-bg); color: var(--pp-text); font: inherit; text-align: left; cursor: pointer; }
.pp-tok:hover { border-color: var(--pp-blue-400); background: var(--pp-blue-a12); }
.pp-tok-sw { flex-shrink: 0; width: 18px; height: 18px; border: 1px solid var(--pp-border-strong); border-radius: 5px; }
.pp-tok-none { background: repeating-linear-gradient(45deg, var(--pp-bg-subtle), var(--pp-bg-subtle) 3px, var(--pp-bg-hover) 3px, var(--pp-bg-hover) 6px); }
.pp-tok-main { display: flex; flex-direction: column; flex: 1; min-width: 0; }
.pp-tok-main b { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font: 600 12px/16px var(--pp-mono); }
.pp-tok-main span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font: 11px/14px var(--pp-mono); color: var(--pp-text-subtlest); }
.pp-tok-dark { display: inline-flex; align-items: center; gap: 4px; flex-shrink: 0; }
.pp-tok-dark em { font-style: normal; font-size: 10px; color: var(--pp-text-subtlest); text-transform: uppercase; letter-spacing: 0.04em; }

/* Effects */
.pp-fx { display: flex; align-items: center; gap: 12px; width: 100%; box-sizing: border-box; margin-bottom: 8px; padding: 8px 10px; border: 1px solid var(--pp-border); border-radius: 8px; background: var(--pp-bg); color: var(--pp-text); font: inherit; text-align: left; cursor: pointer; }
.pp-fx:hover { border-color: var(--pp-blue-400); background: var(--pp-blue-a12); }
.pp-fx-box { flex-shrink: 0; width: 40px; height: 40px; border-radius: 8px; background: #fff; border: 1px solid var(--pp-border); }

/* Components: the real values next to each preview */
.pp-comp-details { display: flex; flex-wrap: wrap; gap: 4px 6px; padding: 8px 0 2px; }
.pp-comp-details > span { display: inline-flex; align-items: center; gap: 4px; padding: 1px 6px; border: 1px solid var(--pp-border); border-radius: 999px; font: 11px/16px var(--pp-mono); color: var(--pp-text); max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.pp-comp-details i { font-style: normal; font-family: var(--pp-font); font-size: 10px; text-transform: uppercase; letter-spacing: 0.04em; color: var(--pp-text-subtlest); }

/* Tool row: icon-only buttons with a tooltip, and a handle to move the panel. */
.pp-ov-nav { position: relative; z-index: 2; }
.pp-ov-tools { display: flex; align-items: center; gap: 6px; padding: 8px 0 4px; cursor: grab; touch-action: none; }
.pp-ov-dragging .pp-ov-tools { cursor: grabbing; }
.pp-ov-dragging { user-select: none; box-shadow: 0 16px 40px rgba(9, 30, 66, 0.3); }
.pp-ov-grip { display: inline-flex; align-items: center; padding: 0 4px 0 2px; color: var(--pp-text-subtlest); }
.pp-ov-tools .pp-ov-tool { position: relative; flex: 0 0 auto; width: 40px; height: 34px; padding: 0; }
/* The tools sit on the right of the row; the grip stays on the left. */
.pp-ov-tools .pp-ov-tool:first-of-type { margin-left: auto; }
`;var R="pixelpeek-host";function He(){let o=document.getElementById(R);o&&o.remove();let t=document.createElement("div");t.id=R,t.style.position="fixed",t.style.top="0",t.style.left="0",t.style.width="0",t.style.height="0",t.style.zIndex="2147483647";let e=t.attachShadow({mode:"closed"}),n=document.createElement("style");return n.textContent=De,e.appendChild(n),document.documentElement.appendChild(t),{host:t,root:e}}function Be(){document.getElementById(R)?.remove()}var ae=new Set(["HTML","BODY"]),Lt=class{constructor(t,e){this.hovered=null;this.locked=null;this.rafPending=!1;this.lastMouseEvent=null;this.scrollRafPending=!1;this.outsideClickCount=0;this.measureEls=[];this.enabled=!0;this.scrolling=!1;this.scrollTimer=0;this.root=t,this.callbacks=e,this.outline=document.createElement("div"),this.outline.className="pixelpeek-outline",this.outline.style.display="none",this.chip=document.createElement("div"),this.chip.className="pixelpeek-chip",this.chip.style.display="none",this.root.appendChild(this.outline),this.root.appendChild(this.chip),this.onMouseMove=this.onMouseMove.bind(this),this.onClick=this.onClick.bind(this),this.onKeyDown=this.onKeyDown.bind(this),this.onScrollOrResize=this.onScrollOrResize.bind(this),this.onKeyUp=this.onKeyUp.bind(this),window.addEventListener("mousemove",this.onMouseMove,!0),window.addEventListener("click",this.onClick,!0),document.addEventListener("keydown",this.onKeyDown,!0),document.addEventListener("keyup",this.onKeyUp,!0),document.addEventListener("scroll",this.onScrollOrResize,!0),window.addEventListener("resize",this.onScrollOrResize)}destroy(){window.removeEventListener("mousemove",this.onMouseMove,!0),window.removeEventListener("click",this.onClick,!0),document.removeEventListener("keydown",this.onKeyDown,!0),document.removeEventListener("keyup",this.onKeyUp,!0),clearTimeout(this.scrollTimer),this.clearMeasure(),document.removeEventListener("scroll",this.onScrollOrResize,!0),window.removeEventListener("resize",this.onScrollOrResize),this.outline.remove(),this.chip.remove()}closeExtension(){this.callbacks.onDeactivate()}release(){this.locked&&this.unlock()}setEnabled(t){this.enabled=t,t||(this.hovered=null,this.callbacks.onHover?.(null),this.locked&&this.unlock(),this.outline.style.display="none",this.chip.style.display="none",this.clearMeasure())}refresh(){this.locked&&this.drawOutline(this.locked,!0)}isOwnElement(t){return t?.id===R}onMouseMove(t){if(this.enabled&&!this.scrolling){if(this.locked){t.altKey?this.measureTo(t.clientX,t.clientY):this.clearMeasure();return}this.lastMouseEvent=t,!this.rafPending&&(this.rafPending=!0,requestAnimationFrame(()=>{if(this.rafPending=!1,!this.lastMouseEvent)return;let e=document.elementFromPoint(this.lastMouseEvent.clientX,this.lastMouseEvent.clientY);e&&!this.isOwnElement(e)&&!ae.has(e.tagName)&&this.setHovered(e)}))}}onClick(t){if(!this.enabled)return;let e=t.target;if(this.locked){if(this.isOwnElement(e)){this.outsideClickCount=0;return}if(e===this.locked||this.locked.contains(e)){this.outsideClickCount=0;return}this.outsideClickCount++,this.outsideClickCount===1?this.pulsePanel():(this.outsideClickCount=0,this.unlock());return}this.isOwnElement(e)||this.hovered&&(t.preventDefault(),t.stopPropagation(),this.lock(this.hovered))}pulsePanel(){this.callbacks.onOutsideClick?.()}onScrollOrResize(){this.scrolling||(this.scrolling=!0,this.callbacks.onScrolling?.(!0)),clearTimeout(this.scrollTimer),this.scrollTimer=window.setTimeout(()=>{this.scrolling=!1,this.callbacks.onScrolling?.(!1)},180),!this.scrollRafPending&&(this.scrollRafPending=!0,requestAnimationFrame(()=>{this.scrollRafPending=!1;let t=this.locked??this.hovered;t&&this.enabled&&this.drawOutline(t,!!this.locked)}))}onKeyDown(t){if(t.key==="Escape"){t.preventDefault(),t.stopPropagation(),this.callbacks.onEscape?.()||this.closeExtension();return}if(!this.locked&&this.enabled&&this.hovered&&!t.ctrlKey&&!t.metaKey&&!t.altKey&&!this.isOwnElement(t.target)){let e=t.key.toLowerCase()==="f"?"figma":t.key.toLowerCase()==="s"?"save":null;if(e){t.preventDefault(),t.stopPropagation(),this.callbacks.onHoverKey?.(e,this.hovered);return}}if(!(!this.locked||!this.enabled))switch(t.key){case"ArrowUp":{let e=this.locked.parentElement;e&&!ae.has(e.tagName)&&(t.preventDefault(),t.stopPropagation(),this.lock(e));return}case"ArrowDown":{let e=this.locked.children[0];e&&(t.preventDefault(),t.stopPropagation(),this.lock(e));return}case"ArrowLeft":{let e=this.locked.previousElementSibling;e&&(t.preventDefault(),t.stopPropagation(),this.lock(e));return}case"ArrowRight":{let e=this.locked.nextElementSibling;e&&(t.preventDefault(),t.stopPropagation(),this.lock(e));return}}}onKeyUp(t){t.key==="Alt"&&this.clearMeasure()}clearMeasure(){for(let t of this.measureEls)t.remove();this.measureEls=[]}measureTo(t,e){this.clearMeasure();let n=this.locked,i=document.elementFromPoint(t,e);if(!n||!i||this.isOwnElement(i)||i===n||ae.has(i.tagName))return;let r=n.getBoundingClientRect(),s=i.getBoundingClientRect(),p=document.createElement("div");p.className="pixelpeek-measure-box",Object.assign(p.style,{top:`${s.top}px`,left:`${s.left}px`,width:`${s.width}px`,height:`${s.height}px`}),this.root.appendChild(p),this.measureEls.push(p);let a=(m,v,u,g,y)=>{if(y<=0)return;let $=v===g,k=document.createElement("div");k.className="pixelpeek-measure-line",Object.assign(k.style,$?{left:`${Math.min(m,u)}px`,top:`${v}px`,width:`${Math.abs(u-m)}px`,height:"1px"}:{left:`${m}px`,top:`${Math.min(v,g)}px`,width:"1px",height:`${Math.abs(g-v)}px`});let I=document.createElement("div");I.className="pixelpeek-measure-label",I.textContent=`${Math.round(y)}`,Object.assign(I.style,{left:`${(m+u)/2}px`,top:`${(v+g)/2}px`}),this.root.append(k,I),this.measureEls.push(k,I)},l=(Math.max(r.top,s.top)+Math.min(r.bottom,s.bottom))/2,c=(Math.max(r.left,s.left)+Math.min(r.right,s.right))/2,d=Math.max(r.top,s.top)<Math.min(r.bottom,s.bottom)?l:(r.top+r.bottom)/2,h=Math.max(r.left,s.left)<Math.min(r.right,s.right)?c:(r.left+r.right)/2;s.left>=r.right?a(r.right,d,s.left,d,s.left-r.right):r.left>=s.right?a(s.right,d,r.left,d,r.left-s.right):(a(Math.min(r.left,s.left),d,Math.max(r.left,s.left),d,Math.abs(r.left-s.left)),a(Math.min(r.right,s.right),d,Math.max(r.right,s.right),d,Math.abs(r.right-s.right))),s.top>=r.bottom?a(h,r.bottom,h,s.top,s.top-r.bottom):r.top>=s.bottom?a(h,s.bottom,h,r.top,r.top-s.bottom):(a(h,Math.min(r.top,s.top),h,Math.max(r.top,s.top),Math.abs(r.top-s.top)),a(h,Math.min(r.bottom,s.bottom),h,Math.max(r.bottom,s.bottom),Math.abs(r.bottom-s.bottom)))}setHovered(t){this.hovered=t,this.callbacks.onHover?.(t),this.drawOutline(t,!1)}lock(t){this.locked=t,this.hovered=t,this.callbacks.onHover?.(null),this.outsideClickCount=0,this.drawOutline(t,!0),this.callbacks.onLock(t)}unlock(){this.locked=null,this.hovered=null,this.callbacks.onHover?.(null),this.clearMeasure(),this.outline.style.display="none",this.chip.style.display="none",this.callbacks.onUnlock()}drawOutline(t,e){let n=t.getBoundingClientRect();this.outline.style.display="block",this.outline.className="pixelpeek-outline"+(e?" locked":""),this.outline.style.top=`${n.top}px`,this.outline.style.left=`${n.left}px`,this.outline.style.width=`${n.width}px`,this.outline.style.height=`${n.height}px`,this.chip.style.display="block",this.chip.className="pixelpeek-chip"+(e?" locked":""),this.chip.textContent=`${t.tagName.toLowerCase()} \xB7 ${Math.round(n.width)} \xD7 ${Math.round(n.height)}`;let i=n.top>20?n.top-20:n.bottom+4;this.chip.style.top=`${i}px`,this.chip.style.left=`${n.left}px`}};var q;function hn(o){if(q===void 0&&(q=document.createElement("canvas").getContext("2d",{willReadFrequently:!0})),!q||(q.clearRect(0,0,1,1),q.fillStyle="#010203",q.fillStyle=o,q.fillStyle==="#010203"))return null;q.fillRect(0,0,1,1);let[t,e,n,i]=q.getImageData(0,0,1,1).data;return{r:t,g:e,b:n,a:i/255}}function P(o){let t=o.trim().toLowerCase();if(!t)return null;if(t==="transparent")return{r:0,g:0,b:0,a:0};let e=t.match(/^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)$/);if(e){let i=e[4]===void 0?1:e[4].endsWith("%")?parseFloat(e[4])/100:parseFloat(e[4]);return{r:+e[1],g:+e[2],b:+e[3],a:i}}let n=t.match(/^#([0-9a-f]{3,8})$/);if(n){let i=n[1];if((i.length===3||i.length===4)&&(i=[...i].map(r=>r+r).join("")),i.length===6||i.length===8)return{r:parseInt(i.slice(0,2),16),g:parseInt(i.slice(2,4),16),b:parseInt(i.slice(4,6),16),a:i.length===8?parseInt(i.slice(6,8),16)/255:1}}return hn(t)}var Rt=o=>Math.max(0,Math.min(255,Math.round(o))).toString(16).padStart(2,"0");function F({r:o,g:t,b:e,a:n}){return`#${Rt(o)}${Rt(t)}${Rt(e)}${n<1?Rt(n*255):""}`.toUpperCase()}function Ne({h:o,s:t,l:e}){let n=(1-Math.abs(2*e-1))*t,i=n*(1-Math.abs(o/60%2-1)),r=e-n/2,[s,p,a]=o<60?[n,i,0]:o<120?[i,n,0]:o<180?[0,n,i]:o<240?[0,i,n]:o<300?[i,0,n]:[n,0,i];return{r:(s+r)*255,g:(p+r)*255,b:(a+r)*255,a:1}}function Pt(o,t){let e=o.a+t.a*(1-o.a);if(e===0)return{r:0,g:0,b:0,a:0};let n=(i,r)=>(i*o.a+r*t.a*(1-o.a))/e;return{r:n(o.r,t.r),g:n(o.g,t.g),b:n(o.b,t.b),a:e}}function Oe({r:o,g:t,b:e}){let n=i=>{let r=i/255;return r<=.03928?r/12.92:((r+.055)/1.055)**2.4};return .2126*n(o)+.7152*n(t)+.0722*n(e)}function je(o,t){let e=Oe(o),n=Oe(t);return(Math.max(e,n)+.05)/(Math.min(e,n)+.05)}var gn={r:255,g:255,b:255,a:1},mn=/(rgba?\([^)]+\)|hsla?\([^)]+\)|#[0-9a-fA-F]{3,8}\b)/g;function Ve(o,t){if(!o.includes("gradient("))return[];let e=[];for(let n of o.matchAll(mn)){let i=P(n[1]);i&&i.a>0&&e.push(i.a<1?Pt(i,t):i)}return e}function It(o,t=new WeakMap){let e=t.get(o);if(e)return e;let n=getComputedStyle(o),i=P(n.backgroundColor),r=n.backgroundImage!=="none",s=o.parentElement,p=r&&n.backgroundImage.includes("url("),a;if(i&&i.a>=1){let l=r&&!p?Ve(n.backgroundImage,i):[];a=l.length?{color:l[0],stops:l,onImage:!1}:{color:i,onImage:p}}else{let l=s?It(s,t):{color:gn,onImage:!1},c=i&&i.a>0?Pt(i,l.color):l.color,d=r&&!p?Ve(n.backgroundImage,c):[];a=d.length?{color:d[0],stops:d,onImage:l.onImage}:{color:c,onImage:p||l.onImage,stops:l.stops}}return t.set(o,a),a}function fn(o,t){return o>=24||o>=18.66&&t>=700}function pe(o,t,e,n){let i=t.stops&&t.stops.length?t.stops:[t.color],r=i[0],s=1/0,p=o;for(let l of i){let c=o.a<1?Pt(o,l):o,d=je(c,l);d<s&&(s=d,r=l,p=c)}let a=fn(e,n);return{ratio:s,gradient:i.length>1,fg:F({...p,a:1}),bg:F({...r,a:1}),large:a,aa:s>=(a?3:4.5),aaa:s>=(a?4.5:7),onImage:t.onImage}}var bn=new Set(["INPUT","BUTTON","TEXTAREA","SELECT"]);function ot(o){if(bn.has(o.tagName))return!0;for(let t of Array.from(o.childNodes))if(t.nodeType===Node.TEXT_NODE&&t.textContent?.trim())return!0;return!1}function zt(o,t,e){if(!ot(o))return;let n=P(t.color);if(!(!n||n.a===0))return pe(n,It(o,e),parseFloat(t.fontSize)||16,parseInt(t.fontWeight,10)||400)}var vn=3e3,xn=new Set(["SCRIPT","STYLE","NOSCRIPT","LINK","META","TEMPLATE","BR","WBR"]),yn=new Set(["path","circle","rect","ellipse","polygon","polyline","line","g","text","use"]),wn=/(rgba?\([^)]+\)|hsla?\([^)]+\)|#[0-9a-fA-F]{3,8}\b)/g;function Ue(o){let t=new Map,e=(i,r,s)=>{let p=P(i);if(!p||p.a===0)return;let a=F(p),l=t.get(a)??{count:0,roles:new Set,own:!1};l.count++,l.roles.add(r),l.own=l.own||s,t.set(a,l)},n=[o,...Array.from(o.querySelectorAll("*")).slice(0,vn)];for(let i of n){if(xn.has(i.tagName)||i.id===R)continue;let r=getComputedStyle(i);if(r.display==="none")continue;let s=i===o;if(i instanceof SVGElement&&yn.has(i.tagName.toLowerCase())){r.fill!=="none"&&e(r.fill,"icon",s),r.stroke!=="none"&&e(r.stroke,"icon",s);continue}e(r.backgroundColor,"background",s);let a=new Set;for(let l of["top","right","bottom","left"])parseFloat(r.getPropertyValue(`border-${l}-width`))>0&&r.getPropertyValue(`border-${l}-style`)!=="none"&&a.add(r.getPropertyValue(`border-${l}-color`));if(a.forEach(l=>e(l,"border",s)),r.backgroundImage.includes("gradient("))for(let l of r.backgroundImage.matchAll(wn))e(l[1],"gradient",s);ot(i)&&e(r.color,"text",s)}return Array.from(t,([i,r])=>({hex:i,count:r.count,roles:Array.from(r.roles),own:r.own})).sort((i,r)=>Number(r.own)-Number(i.own)||r.count-i.count)}function nt(o,t=","){let e=[],n=0,i="";for(let r of o)r==="("&&n++,r===")"&&n--,r===t&&n===0?(e.push(i),i=""):i+=r;return i.trim()&&e.push(i),e.map(r=>r.trim())}var xt=/rgba?\([^)]*\)|#[0-9a-fA-F]{3,8}\b/;function z(o){let t=o.match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)/);if(!t)return o;let e=i=>Math.round(i).toString(16).padStart(2,"0"),n=`#${e(+t[1])}${e(+t[2])}${e(+t[3])}`;if(t[4]!==void 0){let i=t[4].endsWith("%")?parseFloat(t[4])/100:parseFloat(t[4]);i<1&&(n+=e(i*255))}return n.toUpperCase()}function le(o){return o!==""&&o!=="transparent"&&o!=="rgba(0, 0, 0, 0)"}function ct(o){return!o||o==="none"?[]:nt(o).map(t=>{let e=/\binset\b/.test(t),n=t.match(xt),i=n?n[0]:"",s=(t.replace(i,"").replace(/\binset\b/,"").match(/-?\d*\.?\d+(?:px)?/g)??[]).map(d=>d.endsWith("px")?d:`${d}px`),[p="0px",a="0px",l="0px",c="0px"]=s;return{type:e?"Inner":"Drop",x:p,y:a,blur:l,spread:c,color:i?z(i):"transparent"}})}var $n={"to top":0,"to right":90,"to bottom":180,"to left":270,"to top right":45,"to right top":45,"to bottom right":135,"to right bottom":135,"to bottom left":225,"to left bottom":225,"to top left":315,"to left top":315};function yt(o){return`${Math.round(o*100)/100}deg`}function kn(o){let t=$n[o.trim()];if(t!==void 0)return yt(t);let e=o.match(/^(-?[\d.]+)(deg|turn|rad|grad)$/);if(!e)return o;let n=parseFloat(e[1]);switch(e[2]){case"turn":return yt(n*360);case"rad":return yt(n*180/Math.PI);case"grad":return yt(n*.9);default:return yt(n)}}function Sn(o){let t=o.match(/^(repeating-)?(linear|radial|conic)-gradient\((.*)\)$/s);if(!t||t[1]||t[2]==="conic")return{type:"Other",stops:[],raw:o};let e=t[2]==="linear"?"Linear":"Radial",n=nt(t[3]),i;if(n.length&&!xt.test(n[0])){let s=n.shift();e==="Linear"&&(i=kn(s))}else e==="Linear"&&(i="180deg");let r=n.map(s=>{let p=s.match(xt);if(!p)return{color:s};let a=s.replace(p[0],"").trim();return{color:z(p[0]),position:a||void 0}});return{type:e,angle:i,stops:r,raw:o}}function dt(o){return!o||o==="none"?[]:nt(o).filter(t=>t.includes("gradient(")).map(Sn)}var E=o=>parseFloat(o)||0,ut=o=>String(Math.round(o*100)/100),K=o=>`[${ut(o)}px]`;function V(o){return o===1?"px":o%4===0&&o<=384||o%2===0&&o<16?ut(o/4):K(o)}var Cn=o=>o.replace(/\s+/g,"_"),Ge={12:"xs",14:"sm",16:"base",18:"lg",20:"xl",24:"2xl",30:"3xl",36:"4xl",48:"5xl",60:"6xl",72:"7xl",96:"8xl",128:"9xl"},We={100:"thin",200:"extralight",300:"light",400:"normal",500:"medium",600:"semibold",700:"bold",800:"extrabold",900:"black"},qe={1:"none","1.25":"tight","1.375":"snug","1.5":"normal","1.625":"relaxed",2:"loose"},Ke={"-0.05":"tighter","-0.025":"tight","0.025":"wide","0.05":"wider","0.1":"widest"},En={2:"sm",4:"",6:"md",8:"lg",12:"xl",16:"2xl",24:"3xl"},Tn={"flex-start":"start",start:"start",center:"center","flex-end":"end",end:"end","space-between":"between","space-around":"around","space-evenly":"evenly"},Mn={"flex-start":"start",start:"start",center:"center","flex-end":"end",end:"end",baseline:"baseline",stretch:"stretch"},An=new Set([0,10,20,30,40,50]);function Ln(o){let t=(o.split(",")[0]??"").trim().replace(/^["']|["']$/g,"");return t?/mono|courier|consolas|menlo/i.test(t)?"font-mono":/^(serif|georgia|times)/i.test(t)?"font-serif":/^(ui-sans-serif|system-ui|-apple-system|blinkmacsystemfont|sans-serif|segoe ui|helvetica|arial)/i.test(t)?"font-sans":`font-[${t.replace(/\s+/g,"_")}]`:""}function Ye(o,t,e,n,i){if(!t&&!e&&!n&&!i)return[];if(t===e&&e===n&&n===i)return[`${o}-${V(t)}`];let r=[];return i===e&&i?r.push(`${o}x-${V(i)}`):(i&&r.push(`${o}l-${V(i)}`),e&&r.push(`${o}r-${V(e)}`)),t===n&&t?r.push(`${o}y-${V(t)}`):(t&&r.push(`${o}t-${V(t)}`),n&&r.push(`${o}b-${V(n)}`)),r}function Ze(o,t){if(t>=9999)return`${o}-full`;let e=En[t];return e!==void 0?e?`${o}-${e}`:o:`${o}-${K(t)}`}function Rn(o){if(!o)return 0;let t=getComputedStyle(o);return o.getBoundingClientRect().width-E(t.paddingLeft)-E(t.paddingRight)-E(t.borderLeftWidth)-E(t.borderRightWidth)}function Ft(o,t){let e=[],n=o.getBoundingClientRect();if(t.display!=="inline"&&e.push(t.display==="none"?"hidden":t.display==="inline-block"?"inline-block":t.display),t.position!=="static"&&e.push(t.position),t.position!=="static"&&t.position!=="relative")for(let x of["top","right","bottom","left"]){let S=t[x];S&&S!=="auto"&&e.push(E(S)===0?`${x}-0`:`${x}-${K(E(S))}`)}let i=parseInt(t.zIndex,10);if(!Number.isNaN(i)&&i!==0&&e.push(An.has(i)?`z-${i}`:`z-[${i}]`),t.display.includes("flex")){t.flexDirection==="column"?e.push("flex-col"):t.flexDirection==="row-reverse"?e.push("flex-row-reverse"):t.flexDirection==="column-reverse"&&e.push("flex-col-reverse"),t.flexWrap==="wrap"&&e.push("flex-wrap");let x=Tn[t.justifyContent];x&&x!=="start"&&e.push(`justify-${x}`);let S=Mn[t.alignItems];S&&S!=="stretch"&&e.push(`items-${S}`)}if(t.display.includes("flex")||t.display.includes("grid")){let x=E(t.columnGap),S=E(t.rowGap);x&&x===S?e.push(`gap-${V(x)}`):(x&&e.push(`gap-x-${V(x)}`),S&&e.push(`gap-y-${V(S)}`))}let r=o.parentElement,s=r&&Math.abs(n.width-Rn(r))<1.5&&t.display!=="inline",p=["IMG","VIDEO","CANVAS","IFRAME"].includes(o.tagName)||o instanceof SVGElement,a=["INPUT","SELECT","TEXTAREA"].includes(o.tagName),l=o.children.length>0||!!(o.textContent??"").trim();n.width&&(s?e.push("w-full"):(p||a||!l)&&e.push(`w-${K(n.width)}`)),n.height&&(p||!l&&t.display!=="inline")&&e.push(`h-${K(n.height)}`),e.push(...Ye("m",E(t.marginTop),E(t.marginRight),E(t.marginBottom),E(t.marginLeft))),e.push(...Ye("p",E(t.paddingTop),E(t.paddingRight),E(t.paddingBottom),E(t.paddingLeft)));let c=ot(o),d=c?Ln(t.fontFamily):"";d&&e.push(d);let h=c?E(t.fontSize):0;h&&e.push(Ge[h]?`text-${Ge[h]}`:`text-${K(h)}`);let m=c?parseInt(t.fontWeight,10):0;if(m&&m!==400&&e.push(We[m]?`font-${We[m]}`:`font-[${m}]`),c&&t.fontStyle==="italic"&&e.push("italic"),t.lineHeight!=="normal"&&h){let x=ut(E(t.lineHeight)/h);e.push(qe[x]?`leading-${qe[x]}`:`leading-${K(E(t.lineHeight))}`)}if(t.letterSpacing!=="normal"&&E(t.letterSpacing)&&h){let x=ut(Math.round(E(t.letterSpacing)/h*1e3)/1e3);e.push(Ke[x]?`tracking-${Ke[x]}`:`tracking-${K(E(t.letterSpacing))}`)}c&&!["start","left"].includes(t.textAlign)&&e.push(`text-${t.textAlign}`),c&&t.textTransform!=="none"&&e.push(t.textTransform==="capitalize"?"capitalize":t.textTransform),c&&t.textDecorationLine.includes("underline")&&e.push("underline"),c&&t.textDecorationLine.includes("line-through")&&e.push("line-through"),t.whiteSpace==="nowrap"&&e.push("whitespace-nowrap"),t.textOverflow==="ellipsis"&&t.whiteSpace==="nowrap"&&t.overflow!=="visible"&&e.push("truncate"),c&&e.push(`text-[${z(t.color)}]`);let v=z(t.backgroundColor);t.backgroundColor!=="rgba(0, 0, 0, 0)"&&t.backgroundColor!=="transparent"&&e.push(`bg-[${v}]`);let u=dt(t.backgroundImage);u.length&&e.push(`bg-[${Cn(u.map(x=>x.raw).join(","))}]`);let g=["Top","Right","Bottom","Left"].map(x=>t.getPropertyValue(`border-${x.toLowerCase()}-style`)==="none"?0:E(t.getPropertyValue(`border-${x.toLowerCase()}-width`))),[y,$,k,I]=g,N=x=>x===1||x>0&&x<1?"":x===0?"-0":[2,4,8].includes(x)?`-${x}`:`-${K(x)}`;if(y||$||k||I){y===$&&$===k&&k===I?e.push(`border${N(y)}`):(y&&e.push(`border-t${N(y)}`),$&&e.push(`border-r${N($)}`),k&&e.push(`border-b${N(k)}`),I&&e.push(`border-l${N(I)}`)),(t.borderTopStyle==="dashed"||t.borderTopStyle==="dotted")&&e.push(`border-${t.borderTopStyle}`);let x=g.findIndex(tt=>tt>0),S=t.getPropertyValue(`border-${["top","right","bottom","left"][x]}-color`);e.push(`border-[${z(S)}]`)}let G=[E(t.borderTopLeftRadius),E(t.borderTopRightRadius),E(t.borderBottomRightRadius),E(t.borderBottomLeftRadius)];if(G.some(Boolean))if(G.every(x=>x===G[0])){let x=t.borderTopLeftRadius.endsWith("%")&&E(t.borderTopLeftRadius)>=50;e.push(Ze("rounded",x?9999:G[0]))}else["tl","tr","br","bl"].forEach((x,S)=>{G[S]&&e.push(Ze(`rounded-${x}`,G[S]))});let lt=ct(t.boxShadow);lt.length&&e.push(`shadow-[${lt.map(x=>`${x.type==="Inner"?"inset_":""}${x.x}_${x.y}_${x.blur}${x.spread!=="0px"?`_${x.spread}`:""}_${x.color}`).join(",")}]`);let W=parseFloat(t.opacity);return W<1&&e.push(Math.round(W*100)%5===0?`opacity-${Math.round(W*100)}`:`opacity-[${ut(W)}]`),t.overflow!=="visible"&&e.push(`overflow-${t.overflow==="clip"?"clip":t.overflow}`),t.objectFit!=="fill"&&o.tagName==="IMG"&&e.push(`object-${t.objectFit}`),e.filter(Boolean)}var Dt=new Map,ce=new Map;function Xe(o){try{return o.cssRules,!0}catch{return!1}}function Je(o){return[...Array.from(o.styleSheets),...o.adoptedStyleSheets??[]]}async function Pn(o,t){let e=new AbortController,n=setTimeout(()=>e.abort(),8e3);try{let i=await fetch(t,{mode:"cors",credentials:"omit",signal:e.signal});if(!i.ok)throw new Error(`HTTP ${i.status}`);let r=await i.text();if(r.length>8e6)throw new Error("too large");let s=new CSSStyleSheet({media:o.media.mediaText});await s.replace(r),Dt.set(t,s)}catch{Dt.set(t,null)}finally{clearTimeout(n)}}function ht(o){let t=[];for(let e of Je(o)){let n=e.href;if(!n||!/^https?:/.test(n)||Xe(e)||Dt.has(n))continue;let i=ce.get(n);i||(i=Pn(e,n).finally(()=>ce.delete(n)),ce.set(n,i)),t.push(i)}return Promise.all(t).then(()=>{})}function Y(o){let t=[],e=0;for(let n of Je(o)){if(Xe(n)){t.push(n);continue}let i=n.href?Dt.get(n.href):null;i?t.push(i):e++}return{sheets:t,unreadable:e}}var j=o=>nt(o).map(t=>t.trim()),U=(o,t)=>o[t%o.length]??"",de=new Map;function Qe(o,t,e=0){if(e>6)return null;for(let n of Array.from(t))try{if(n instanceof CSSKeyframesRule&&n.name===o)return{name:o,steps:Array.from(n.cssRules).map(r=>{let s=r;return{offset:s.keyText,css:s.style.cssText.trim()}})};let i=n.cssRules;if(i&&(n instanceof CSSMediaRule||n instanceof CSSSupportsRule)){let r=Qe(o,i,e+1);if(r)return r}}catch{}return null}function In(o){if(de.has(o))return de.get(o)??null;let t=null;for(let e of Y(document).sheets){try{t=Qe(o,e.cssRules)}catch{continue}if(t)break}return t&&de.set(o,t),t}function _e(o){let t=[],e=j(o.transitionProperty),n=j(o.transitionDuration),i=j(o.transitionTimingFunction),r=j(o.transitionDelay);e.forEach((l,c)=>{let d=U(n,c);l==="none"||parseFloat(d)===0&&parseFloat(U(r,c))===0||t.push({property:l,duration:d,easing:U(i,c),delay:U(r,c)})});let s=[],p=[];if(j(o.animationName).forEach((l,c)=>{if(l==="none")return;s.push({name:l,duration:U(j(o.animationDuration),c),easing:U(j(o.animationTimingFunction),c),delay:U(j(o.animationDelay),c),iterations:U(j(o.animationIterationCount),c),direction:U(j(o.animationDirection),c),fill:U(j(o.animationFillMode),c)});let d=In(l);d&&p.push(d)}),!(!t.length&&!s.length))return{transitions:t,animations:s,keyframes:p}}var Z=o=>parseFloat(o)||0;function zn(o){return/flex|grid/.test(o.display)}function oo(o){if(!o||o==="none")return;let t=o.match(/matrix(?:3d)?\(([^)]+)\)/);if(!t)return;let[e,n]=t[1].split(",").map(r=>parseFloat(r)),i=Math.round(Math.atan2(n,e)*180/Math.PI*100)/100;return i===0?void 0:`${i}deg`}function to(o){return o==="center"?"center":/end|right/.test(o)&&!o.startsWith("space")?"end":"start"}function eo(o){return o==="center"?"center":o==="baseline"||o==="first baseline"||o==="last baseline"?"baseline":/end/.test(o)?"end":o==="normal"||o==="stretch"?"stretch":"start"}function ue(o,t){let e={start:"Top",center:"Center",end:"Bottom"}[t],n={start:"left",center:"center",end:"right"}[o];return e==="Center"&&n==="center"?"Center":e==="Center"?`Center ${n}`:`${e} ${n}`}function no(o){if(!zn(o))return;let t={top:Z(o.paddingTop),right:Z(o.paddingRight),bottom:Z(o.paddingBottom),left:Z(o.paddingLeft)},e=o.gap==="normal"?"0px":o.gap,n=/grid/.test(o.display),i=o.justifyContent,r=i.startsWith("space-")?`Space ${i.replace("space-","")}`:"Packed";if(n){let d=eo(o.alignItems),h=to(o.justifyItems==="normal"?"start":o.justifyItems);return{direction:"Grid",gap:e,align:ue(h,d==="stretch"||d==="baseline"?"start":d),distribute:"Packed",padding:t}}let s=o.flexDirection.startsWith("row"),p=to(i),a=eo(o.alignItems),l=a==="stretch"||a==="baseline"?"start":a,c=s?ue(p,l):ue(l,p);return{direction:s?"Horizontal":"Vertical",gap:e,align:a==="stretch"?`${c} (children stretch)`:c,distribute:r,padding:t}}var Fn=new Set(["img","video","canvas","svg","iframe","input","textarea","select"]);function io(o,t,e,n){let i=o.tagName.toLowerCase(),r=o.style,s=n!==null&&/flex/.test(n.display),p=s&&n.flexDirection.startsWith("row"),a=Z(t.flexGrow),l=t.alignSelf==="auto"?n?.alignItems??"normal":t.alignSelf,c=l==="normal"||l==="stretch",d=/^(inline|inline-block|inline-flex|inline-grid|table-cell)$/.test(t.display),h=!e||!n?0:e.getBoundingClientRect().width-Z(n.paddingLeft)-Z(n.paddingRight)-Z(n.borderLeftWidth)-Z(n.borderRightWidth),m=o.getBoundingClientRect().width,v=u=>{let g=u==="width"?r.width:r.height;return g?g.endsWith("%")&&parseFloat(g)>=99?"Fill":"Fixed":Fn.has(i)?"Fixed":s?u==="width"===p?a>0?"Fill":t.flexBasis==="auto"?"Hug":"Fixed":c?"Fill":"Hug":d?"Hug":u==="width"?Math.abs(m-h)<=1?"Fill":"Fixed":"Hug"};return{width:v("width"),height:v("height")}}var Dn=0,X=o=>parseFloat(o)||0;function he(o,t){let e=t==="border"?"-width":"";return{top:X(o.getPropertyValue(`${t}-top${e}`)),right:X(o.getPropertyValue(`${t}-right${e}`)),bottom:X(o.getPropertyValue(`${t}-bottom${e}`)),left:X(o.getPropertyValue(`${t}-left${e}`))}}function so(o){if(o.id)return`#${o.id}`;let t=Array.from(o.classList).slice(0,2).join(".");return t?`${o.tagName.toLowerCase()}.${t}`:o.tagName.toLowerCase()}function Hn(o){let t=[],e=o;for(;e&&e.tagName!=="HTML";)t.unshift(so(e)),e=e.parentElement;return t}function Bn(o){if(o%100>=11&&o%100<=13)return"th";switch(o%10){case 1:return"st";case 2:return"nd";case 3:return"rd";default:return"th"}}function On(o,t){let e=Array.from(t.children),n=e.indexOf(o)+1;return`${n}${Bn(n)} of ${e.length}`}function ro(o,t,e){let n=o.getBoundingClientRect(),i=t.getBoundingClientRect(),r=e==="vertical"?i.top-n.bottom:i.left-n.right;return`${Math.round(r)}px`}var Nn=new Set(["p","h1","h2","h3","h4","h5","h6","li","blockquote"]);function jn(o){let t=o.getPropertyValue("-webkit-line-clamp");return t&&t!=="none"?`${t} lines, then ellipsis`:o.textOverflow==="ellipsis"&&o.whiteSpace==="nowrap"&&o.overflow!=="visible"?"single line, ellipsis":"none"}var Vn=o=>{let t=parseFloat(o);return t>0&&t<1?"1px":o};function Ht(o,t){let e=t[0].toUpperCase()+t.slice(1),n=i=>o.getPropertyValue(`border-${t}-${i}`)||o.getPropertyValue(`border${e}${i}`);return{width:Vn(n("width")),style:n("style"),color:z(n("color"))}}var Un=[["font-family",[]],["font-size",[]],["font-weight",[]],["line-height",["normal"]],["letter-spacing",["normal"]],["text-align",[]],["text-decoration-line",["none"]],["text-transform",["none"]],["color",[]],["background-color",["rgba(0, 0, 0, 0)"]],["background-image",["none"]],["border-top",[]],["border-right",[]],["border-bottom",[]],["border-left",[]],["border-radius",["0px"]],["box-shadow",["none"]],["opacity",["1"]],["margin",["0px"]],["padding",["0px"]],["width",[]],["height",[]],["position",["static"]],["display",[]],["transform",["none"]],["overflow",["visible"]],["z-index",["auto"]]];function Gn(o){let t=[];for(let[e,n]of Un){let i=o.getPropertyValue(e).trim();!i||n.includes(i)||e.startsWith("border-")&&e!=="border-radius"&&i.startsWith("0px none")||t.push(`${e}: ${e.startsWith("border-")&&e!=="border-radius"?i.replace(/^0\.\d+px/,"1px"):i};`)}return t}function Wn(o){let t=Array.from(o.childNodes).filter(e=>e.nodeType===Node.TEXT_NODE).map(e=>e.textContent??"").join(" ").replace(/\s+/g," ").trim();return t?t.slice(0,120):void 0}function ge(o){let t=getComputedStyle(o),e=o.getBoundingClientRect(),n=o.parentElement,i=n?getComputedStyle(n):null,r=o instanceof SVGElement&&t.stroke!=="none"&&parseFloat(t.strokeWidth)>0?{width:`${Math.round(parseFloat(t.strokeWidth)*100)/100}px`,style:"solid",color:z(t.stroke)}:null,s=r?{top:r,right:r,bottom:r,left:r}:{top:Ht(t,"top"),right:Ht(t,"right"),bottom:Ht(t,"bottom"),left:Ht(t,"left")},p=Object.values(s).some(g=>X(g.width)>0&&g.style!=="none"),a=Object.values(s).find(g=>X(g.width)>0&&g.style!=="none"),l=[];le(t.backgroundColor)&&l.push({role:"background",value:t.backgroundColor}),le(t.color)&&l.push({role:"text",value:t.color}),a&&l.push({role:"border",value:a.color});let c;n&&i&&(c={display:i.display,direction:i.display.includes("flex")?i.flexDirection:void 0,gap:/flex|grid/.test(i.display)?i.gap:void 0,childIndex:On(o,n)});let d,h=o.previousElementSibling,m=o.nextElementSibling;if(h||m){let g=c?.direction?.startsWith("row")?"horizontal":"vertical";d={previous:h?ro(h,o,g):void 0,next:m?ro(o,m,g):void 0}}let v=n?.getBoundingClientRect(),u={x:Math.round((e.left-(v?.left??0)-(i?X(i.borderLeftWidth):0))*10)/10,y:Math.round((e.top-(v?.top??0)-(i?X(i.borderTopWidth):0))*10)/10};return{id:`pp-${Dn++}`,selector:so(o),tagName:o.tagName.toLowerCase(),domPath:Hn(o),text:Wn(o),layout:{typography:{fontFamily:t.fontFamily,fontSize:t.fontSize,lineHeight:t.lineHeight,fontWeight:t.fontWeight,color:t.color,letterSpacing:t.letterSpacing,textAlign:t.textAlign,textDecoration:t.textDecorationLine,textTransform:t.textTransform,truncation:jn(t),paragraphSpacing:Nn.has(o.tagName.toLowerCase())&&X(t.marginBottom)>0?t.marginBottom:void 0},colors:l,palette:Ue(o),contrast:zt(o,t),fills:dt(t.backgroundImage),stroke:p?s:void 0,cornerRadius:{topLeft:t.borderTopLeftRadius,topRight:t.borderTopRightRadius,bottomRight:t.borderBottomRightRadius,bottomLeft:t.borderBottomLeftRadius},effects:{opacity:t.opacity!=="1"?t.opacity:void 0,shadows:ct(t.boxShadow)},boxModel:{margin:he(t,"margin"),border:he(t,"border"),padding:he(t,"padding"),content:{width:Math.round(e.width),height:Math.round(e.height)}},position:t.position,offset:u,rotation:oo(t.transform),display:t.display,parentContext:c,autoLayout:i?no(i):void 0,resize:io(o,t,n,i),siblingSpacing:d,animation:_e(t),tailwind:Ft(o,t),rawCss:Gn(t)}}}function H(o){return o.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}async function wt(o){await navigator.clipboard.writeText(o)}var qn=(()=>{let o=new Uint32Array(256);for(let t=0;t<256;t++){let e=t;for(let n=0;n<8;n++)e=e&1?3988292384^e>>>1:e>>>1;o[t]=e>>>0}return o})();function Kn(o){let t=4294967295;for(let e=0;e<o.length;e++)t=qn[(t^o[e])&255]^t>>>8;return(t^4294967295)>>>0}function Yn(o){return{time:o.getHours()<<11|o.getMinutes()<<5|o.getSeconds()>>1,day:Math.max(o.getFullYear(),1980)-1980<<9|o.getMonth()+1<<5|o.getDate()}}function ao(o){let t=new TextEncoder,{time:e,day:n}=Yn(new Date),i=[],r=[],s=0,p=0;for(let l of o){let c=t.encode(l.name),d=Kn(l.data),h=l.data.length,m=new DataView(new ArrayBuffer(30));m.setUint32(0,67324752,!0),m.setUint16(4,20,!0),m.setUint16(6,2048,!0),m.setUint16(8,0,!0),m.setUint16(10,e,!0),m.setUint16(12,n,!0),m.setUint32(14,d,!0),m.setUint32(18,h,!0),m.setUint32(22,h,!0),m.setUint16(26,c.length,!0),i.push(m.buffer,c,l.data);let v=new DataView(new ArrayBuffer(46));v.setUint32(0,33639248,!0),v.setUint16(4,20,!0),v.setUint16(6,20,!0),v.setUint16(8,2048,!0),v.setUint16(10,0,!0),v.setUint16(12,e,!0),v.setUint16(14,n,!0),v.setUint32(16,d,!0),v.setUint32(20,h,!0),v.setUint32(24,h,!0),v.setUint16(28,c.length,!0),v.setUint32(42,s,!0),r.push(v.buffer,c),p+=46+c.length,s+=30+c.length+h}let a=new DataView(new ArrayBuffer(22));return a.setUint32(0,101010256,!0),a.setUint16(8,o.length,!0),a.setUint16(10,o.length,!0),a.setUint32(12,p,!0),a.setUint32(16,s,!0),new Blob([...i,...r,a.buffer],{type:"application/zip"})}function me(o,t){let e=URL.createObjectURL(o),n=document.createElement("a");n.href=e,n.download=t,n.rel="noopener",n.click(),setTimeout(()=>URL.revokeObjectURL(e),1e4)}function Bt(o,t,e="text/plain"){me(new Blob([o],{type:`${e};charset=utf-8`}),t)}var Zn=12e3;async function gt(o){let t=new AbortController,e=setTimeout(()=>t.abort(),Zn);try{let n=await fetch(o,{credentials:"omit",signal:t.signal});return n.ok?await n.blob():null}catch{return null}finally{clearTimeout(e)}}async function po(o){return o.svg?new Blob([o.svg],{type:"image/svg+xml"}):o.url?gt(o.url):null}async function lo(o){let t=await po(o);if(t)return me(t,o.filename),!0;if(o.url){let e=document.createElement("a");e.href=o.url,e.target="_blank",e.rel="noopener",e.click()}return!1}async function co(o,t,e){let n=[],i=new Set,r=0,s=0,p=[...o],a=async()=>{for(let l=p.shift();l;l=p.shift()){let c=await po(l);if(c){let d=l.filename;for(let h=2;i.has(d);h++)d=l.filename.replace(/(\.[^.]*)?$/,`-${h}$1`);i.add(d),n.push({name:d,data:new Uint8Array(await c.arrayBuffer())})}else r++;e?.(++s,o.length)}};return await Promise.all(Array.from({length:5},a)),n.length&&me(ao(n),t),{saved:n.length,skipped:r}}var uo=400,ho=/^(:root|html|body|:host)$/i,Xn=/(\.dark\b|\.theme-dark\b|\.dark-mode\b|\[data-(?:bs-)?(?:theme|mode|color-scheme)\s*[~^$*|]?=\s*["']?dark["']?\])/i,go=/^--(tw-|webkit|moz|radix-|swiper-|wp-|cmdk-|sb-)/i,Jn=/^(\d+(?:\.\d+)?)(?:deg)?\s+(\d+(?:\.\d+)?)%\s+(\d+(?:\.\d+)?)%(?:\s*\/\s*[\d.]+%?)?$/;function $t(o){let t=o.trim().match(Jn);if(t)return F(Ne({h:parseFloat(t[1]),s:parseFloat(t[2])/100,l:parseFloat(t[3])/100}));let e=P(o);return e&&e.a>0?F(e):null}function mo(o,t){return $t(t)?"color":/^-?[\d.]+(px|rem|em|%|vw|vh|ch)$/.test(t)||/^calc\(/.test(t)?"dimension":/shadow|elevation/i.test(o)||/\d+(px|rem)\s+-?\d+(px|rem).*(rgba?\(|hsla?\(|#)/.test(t)?"shadow":/font|family/i.test(o)&&!/size|weight|height/i.test(o)||/,\s*(sans-serif|serif|monospace|system-ui|ui-)/i.test(t)?"font":"other"}function Qn(o,t){let e=o.split(",").map(i=>i.trim()),n=null;for(let i of e)ho.test(i)&&!t?n=n??"light":(ho.test(i)&&t||Xn.test(i)&&/^(:root|html|body|\.dark|\.theme-dark|\.dark-mode|\[|:host)/i.test(i)||t&&/^(:root|html|body)(:not\([^)]*\)|\[[^\]]*\])*$/i.test(i))&&(n="dark");return n}function Ot(o,t,e,n){for(let i of Array.from(o))if(i instanceof CSSStyleRule){let r=Qn(i.selectorText,t);if(!r)continue;let s=r==="dark"?n:e;for(let p=0;p<i.style.length;p++){let a=i.style[p];a.startsWith("--")&&s.set(a,i.style.getPropertyValue(a).trim())}}else if(i instanceof CSSMediaRule){let r=i.conditionText||i.media.mediaText;/prefers-color-scheme\s*:\s*dark/i.test(r)?Ot(i.cssRules,!0,e,n):(/prefers-color-scheme\s*:\s*light/i.test(r)||/^\s*(all|screen)\s*$/i.test(r))&&Ot(i.cssRules,t,e,n)}else"cssRules"in i&&(i instanceof CSSSupportsRule||i.constructor.name==="CSSLayerBlockRule")&&Ot(i.cssRules,t,e,n)}function fo(){let o=new Map,t=new Map;for(let r of Y(document).sheets)try{Ot(r.cssRules,!1,o,t)}catch{}let e=document.documentElement.style;for(let r=0;r<e.length;r++){let s=e[r];s.startsWith("--")&&o.set(s,e.getPropertyValue(s).trim())}let n=getComputedStyle(document.documentElement),i=[];for(let[r,s]of o){if(go.test(r)||!s)continue;let p=n.getPropertyValue(r).trim()||s,a=s.match(/^var\(\s*(--[\w-]+)\s*(?:,[^)]*)?\)$/)?.[1];if(i.push({name:r,kind:mo(r,p),value:s,resolved:p,alias:a,dark:t.get(r)}),i.length>=uo)break}for(let[r,s]of t){if(o.has(r)||go.test(r)||i.length>=uo)continue;let p=n.getPropertyValue(r).trim()||s;i.push({name:r,kind:mo(r,p),value:p,resolved:p,dark:s})}return i}function yo(o){let t=o.replace(/\s+/g," ").trim().toLowerCase(),e=t.match(/(rgba?\([^)]*\)|hsla?\([^)]*\)|#[0-9a-f]{3,8}\b)/)?.[1],n=e?P(e):null;if(!n||!/\d+(px)?\s+-?\d+/.test(t.replace(e,"")))return t;let i=(t.replace(e,"").match(/-?\d*\.?\d+/g)??[]).map(Number);for(;i.length<4;)i.push(0);return`shadow:${i.slice(0,4).join(",")}|${F(n)}${n.a<1?`@${n.a}`:""}`}function _n(o){let t=new Map,e=new Map,n=(i,r,s)=>{let p=i.get(r)??[];p.length<6&&!p.includes(s)&&p.push(s),i.set(r,p)};for(let i of o)if(i.kind==="color"){let r=$t(i.resolved);r&&n(t,r,i.name)}else n(e,yo(i.resolved),i.name);return{color:t,other:e}}var ti={H1:"H1",H2:"H2",H3:"H3",H4:"H4",H5:"H5",H6:"H6",BUTTON:"Button",INPUT:"Input",TEXTAREA:"Input",SELECT:"Input",A:"Link",LABEL:"Label",LI:"List item",TD:"Table cell",TH:"Table head"};function ei(o){let t=o.textStyles.filter(i=>i.size>=8&&i.size<=200).slice(0,16),e=new Map;return t.map(i=>{let r=Object.entries(i.tags).sort((p,a)=>a[1]-p[1])[0]?.[0]??"",s=ti[r]??"Text";return e.set(s,(e.get(s)??0)+1),{base:s,style:i}}).sort((i,r)=>r.style.size-i.style.size||r.style.count-i.style.count).map(({base:i,style:r})=>({name:(e.get(i)??0)>1?`${i} ${Math.round(r.size*10)/10}/${r.weight}`:i,family:r.family,size:`${Math.round(r.size*10)/10}px`,weight:r.weight,lineHeight:r.lineHeight,letterSpacing:r.letterSpacing,count:r.count}))}var bo=o=>{let t=o.match(/(-?[\d.]+)px\s+(-?[\d.]+)px\s+([\d.]+)px/);return t?parseFloat(t[3]):0},vo=/radius|rounded|corner/i,xo=/space|spacing|gap|pad|margin|inset|gutter/i,Nt=o=>parseFloat(o)||0;function wo(o){let t=_n(o.tokens),e=(a,l)=>(t.other.get(yo(a))??[]).filter(c=>!l||l.test(c)),n=o.colors.map(a=>({hex:a.hex,count:a.count,surface:a.background,text:a.text,border:a.border,icon:a.icon,tokens:t.color.get(a.hex)??[]})),i=o.shadows.slice(0,6).sort((a,l)=>bo(a.value)-bo(l.value)).map((a,l)=>{let c=e(a.value);return{name:c[0]??`Shadow ${l+1}`,value:a.value,count:a.count,tokens:c}}),r=o.radii.slice(0,10).sort((a,l)=>Nt(a.value)-Nt(l.value)).map(a=>({name:e(a.value,vo)[0]??a.value,value:a.value,count:a.count,tokens:e(a.value,vo)})),s=o.spacing.slice(0,14).filter(a=>Number.isInteger(parseFloat(a.value)*2)).sort((a,l)=>Nt(a.value)-Nt(l.value)).map(a=>({name:e(a.value,xo)[0]??a.value,value:a.value,count:a.count,tokens:e(a.value,xo)})),p=o.gradients.slice(0,6).map((a,l)=>{let c=e(a.value);return{name:c[0]??`Gradient ${l+1}`,value:a.value,count:a.count,tokens:c}});return{source:{url:o.url,title:o.title},tokens:o.tokens,colors:n,fonts:o.fonts.map(a=>({family:a.family,weights:a.weights,source:a.source})),textStyles:ei(o),shadows:i,radii:r,spacing:s,gradients:p}}var be={css:"CSS vars",tailwind:"Tailwind v4",scss:"SCSS",dtcg:"DTCG",json:"JSON",md:"DESIGN.md"},mt=o=>o.replace(/^--/,""),J=o=>o.toLowerCase().replace(/#/g,"").replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,""),$o=o=>/[\s,]/.test(o)?`"${o}"`:o;function jt(o,t){return t==="dark"?o.tokens.filter(e=>e.dark).map(e=>[mt(e.name),e.dark]):o.tokens.map(e=>[mt(e.name),e.value])}function fe(o){let t=new Set(o.tokens.map(i=>mt(i.name))),e=[],n=(i,r)=>{t.has(i)||e.push([i,r])};for(let i of o.colors)i.tokens.length||n(`color-${J(i.hex)}`,i.hex);return o.fonts.forEach(i=>n(`font-${J(i.family)}`,$o(i.family))),o.shadows.forEach((i,r)=>!i.tokens.length&&n(`shadow-${r+1}`,i.value)),o.radii.forEach(i=>!i.tokens.length&&n(`radius-${J(i.value)}`,i.value)),o.spacing.forEach(i=>!i.tokens.length&&n(`space-${J(i.value)}`,i.value)),o.gradients.forEach((i,r)=>!i.tokens.length&&n(`gradient-${r+1}`,i.value)),e}var ve=(o,t)=>t.length?`${o} {
${t.map(([e,n])=>`  --${e}: ${n};`).join(`
`)}
}
`:"",Vt=o=>`Read by PixelPeek from ${o.source.url}`,ko=o=>{let t=jt(o,"dark");return t.length?`
${ve(".dark",t)}`:""};function oi(o){return`/* ${Vt(o)} */
${ve(":root",[...jt(o,"light"),...fe(o)])}${ko(o)}`}function ni(o){let t=i=>Object.fromEntries(i.map(([r,s,p])=>[r,{$value:s,$type:p}])),e=i=>({color:"color",dimension:"dimension",font:"fontFamily",shadow:"shadow"})[i]??"string",n={$description:Vt(o),declared:t(o.tokens.map(i=>[mt(i.name),i.alias?`{declared.${mt(i.alias)}}`:i.value,e(i.kind)])),color:t(o.colors.filter(i=>!i.tokens.length).map(i=>[J(i.hex),i.hex,"color"])),fontFamily:t(o.fonts.map(i=>[J(i.family),$o(i.family),"fontFamily"])),textStyle:Object.fromEntries(o.textStyles.map(i=>[J(i.name),{$type:"typography",$value:{fontFamily:i.family,fontSize:i.size,fontWeight:i.weight,lineHeight:i.lineHeight,letterSpacing:i.letterSpacing}}])),shadow:t(o.shadows.map((i,r)=>[i.tokens[0]?mt(i.tokens[0]):`shadow-${r+1}`,i.value,"shadow"])),radius:t(o.radii.map(i=>[J(i.value),i.value,"dimension"])),spacing:t(o.spacing.map(i=>[J(i.value),i.value,"dimension"]))};return JSON.stringify(n,null,2)}function ii(o){let t=["# Design system","",`Read from ${o.source.url}${o.source.title?` ("${o.source.title}")`:""} with PixelPeek. Every value is taken from the page.`];if(o.tokens.length){t.push("","## Variables declared by the site","","| Name | Value | Dark |","| --- | --- | --- |");for(let e of o.tokens)t.push(`| \`${e.name}\` | \`${e.value}\`${e.alias?"":e.resolved!==e.value?` \u2192 \`${e.resolved}\``:""} | ${e.dark?`\`${e.dark}\``:""} |`)}t.push("","## Colors in use","","| Color | Surface | Text | Border | Icon | Token |","| --- | --- | --- | --- | --- | --- |");for(let e of o.colors.slice(0,40))t.push(`| ${e.hex} | ${e.surface} | ${e.text} | ${e.border} | ${e.icon} | ${e.tokens.map(n=>`\`${n}\``).join(", ")} |`);if(o.textStyles.length){t.push("","## Text styles","","| Style | Font | Size | Weight | Line height | Letter spacing |","| --- | --- | --- | --- | --- | --- |");for(let e of o.textStyles)t.push(`| ${e.name} | ${e.family} | ${e.size} | ${e.weight} | ${e.lineHeight} | ${e.letterSpacing} |`)}return o.shadows.length&&t.push("","## Effect styles (shadows)","",...o.shadows.map(e=>`- ${e.name}: \`${e.value}\``)),o.radii.length&&t.push("","## Corner radius","",...o.radii.map(e=>`- ${e.name}${e.name!==e.value?`: ${e.value}`:""} (${e.count}\xD7)`)),o.spacing.length&&t.push("","## Spacing in use","",...o.spacing.map(e=>`- ${e.name}${e.name!==e.value?`: ${e.value}`:""} (${e.count}\xD7)`)),o.gradients.length&&t.push("","## Gradients","",...o.gradients.map(e=>`- ${e.name}: \`${e.value}\``)),`${t.join(`
`)}
`}function Ut(o,t){let e=be[t];switch(t){case"css":return{label:e,filename:"tokens.css",mime:"text/css",text:oi(o)};case"tailwind":return{label:e,filename:"theme.css",mime:"text/css",text:`/* ${Vt(o)} */
@import "tailwindcss";

${ve("@theme",[...jt(o,"light"),...fe(o)])}${ko(o)}`};case"scss":return{label:e,filename:"tokens.scss",mime:"text/x-scss",text:`// ${Vt(o)}
${[...jt(o,"light"),...fe(o)].map(([n,i])=>`$${n}: ${i};`).join(`
`)}
`};case"dtcg":return{label:e,filename:"tokens.json",mime:"application/json",text:ni(o)};case"json":return{label:e,filename:"design-system.json",mime:"application/json",text:JSON.stringify(o,null,2)};case"md":return{label:e,filename:"DESIGN.md",mime:"text/markdown",text:ii(o)}}}var kt="pixelpeek-library",ri=300,So=()=>typeof chrome<"u"&&!!chrome.storage?.local;async function xe(){try{return So()?(await chrome.storage.local.get(kt))[kt]??[]:JSON.parse(localStorage.getItem(kt)??"[]")}catch{return[]}}async function ye(o){So()?await chrome.storage.local.set({[kt]:o}):localStorage.setItem(kt,JSON.stringify(o))}function Co(){return xe()}async function we(o,t){let{layout:e}=o,n={id:`${Date.now()}-${Math.random().toString(36).slice(2,7)}`,savedAt:Date.now(),url:t.url,title:t.title,selector:o.selector,tagName:o.tagName,width:e.boxModel.content.width,height:e.boxModel.content.height,text:o.text,tailwind:e.tailwind,css:e.rawCss,colors:e.colors.map(r=>({role:r.role,value:z(r.value)})),font:e.typography?.fontFamily},i=await xe();return await ye([n,...i].slice(0,ri)),n}async function Eo(o){await ye((await xe()).filter(t=>t.id!==o))}async function To(){await ye([])}var T=(o,t,e,n,i,r)=>({id:o,name:t,category:e,width:n,height:i,frame:r}),Gt=[T("responsive","Responsive","responsive",390,780,"plain"),T("iphone-16-pro-max","iPhone 16 Pro Max","phones",440,956,"island"),T("iphone-16-pro","iPhone 16 Pro","phones",402,874,"island"),T("iphone-16-plus","iPhone 16 Plus","phones",430,932,"island"),T("iphone-16","iPhone 16","phones",393,852,"island"),T("iphone-15-pro","iPhone 15 Pro","phones",393,852,"island"),T("iphone-14","iPhone 14","phones",390,844,"notch"),T("iphone-13-mini","iPhone 13 mini","phones",375,812,"notch"),T("iphone-se","iPhone SE","phones",375,667,"home"),T("pixel-9-pro","Pixel 9 Pro","phones",412,915,"punch"),T("pixel-8","Pixel 8","phones",412,915,"punch"),T("pixel-7","Pixel 7","phones",412,915,"punch"),T("galaxy-s24","Galaxy S24","phones",360,780,"punch"),T("galaxy-s24-ultra","Galaxy S24 Ultra","phones",384,824,"punch"),T("galaxy-s23","Galaxy S23","phones",360,780,"punch"),T("galaxy-z-fold-5","Galaxy Z Fold 5 (folded)","phones",344,882,"fold"),T("ipad-pro-13",'iPad Pro 13"',"tablets",1032,1376,"tablet"),T("ipad-pro-11",'iPad Pro 11"',"tablets",834,1194,"tablet"),T("ipad-air","iPad Air","tablets",820,1180,"tablet"),T("ipad-mini","iPad mini","tablets",744,1133,"tablet"),T("galaxy-tab-s9","Galaxy Tab S9","tablets",800,1280,"tablet"),T("macbook-air-13",'MacBook Air 13"',"desktop",1440,900,"laptop"),T("macbook-pro-14",'MacBook Pro 14"',"desktop",1512,982,"laptop"),T("macbook-pro-16",'MacBook Pro 16"',"desktop",1728,1117,"laptop"),T("imac-24",'iMac 24"',"desktop",2240,1260,"monitor"),T("desktop-hd","Desktop HD","desktop",1920,1080,"monitor"),T("apple-watch-10","Apple Watch Series 10","watches",208,248,"watch"),T("apple-watch-ultra-2","Apple Watch Ultra 2","watches",205,251,"watch")],Wt={responsive:"Responsive",phones:"Phones",tablets:"Tablets",desktop:"Desktop",watches:"Watches"},Mo="iphone-16-pro";function St(o){return Gt.find(t=>t.id===o)}function Ao(o){let{layout:t}=o,e=t.typography,n=[];n.push("Recreate this UI element as a React component styled with Tailwind CSS. Match the values below exactly."),n.push(""),n.push(`Element: <${o.tagName}> (${o.selector})`),n.push(`Size: ${t.boxModel.content.width} \xD7 ${t.boxModel.content.height}px`),o.text&&n.push(`Text: "${o.text}"`),n.push(`Location: ${o.domPath.slice(-4).join(" > ")}`),n.push(""),t.tailwind.length&&(n.push("Tailwind classes:"),n.push(t.tailwind.join(" ")),n.push("")),n.push("Design details:"),e&&n.push(`- Font: ${e.fontFamily}, ${e.fontSize} / ${e.lineHeight}, weight ${e.fontWeight}, letter spacing ${e.letterSpacing}`);for(let p of t.colors)n.push(`- ${p.role[0].toUpperCase()}${p.role.slice(1)} color: ${z(p.value)}`);t.contrast&&n.push(`- Text contrast: ${t.contrast.ratio.toFixed(2)}:1 (${t.contrast.aa?"passes":"fails"} WCAG AA)`),t.fills.length&&n.push(`- Background gradient: ${t.fills.map(p=>p.raw).join(", ")}`);let i=t.cornerRadius;n.push(`- Corner radius: ${i.topLeft} ${i.topRight} ${i.bottomRight} ${i.bottomLeft}`);for(let p of t.effects.shadows)n.push(`- ${p.type} shadow: ${p.x} ${p.y} blur ${p.blur} spread ${p.spread} ${p.color}`);let{padding:r,margin:s}=t.boxModel;return n.push(`- Padding: ${r.top}px ${r.right}px ${r.bottom}px ${r.left}px; margin: ${s.top}px ${s.right}px ${s.bottom}px ${s.left}px`),t.autoLayout&&n.push(`- Parent layout: ${t.autoLayout.direction}, gap ${t.autoLayout.gap}, align ${t.autoLayout.align}, distribute ${t.autoLayout.distribute}`),n.push(""),n.push("CSS:"),n.push(...t.rawCss),n.push(""),n.push("Use semantic HTML, keep the component self-contained, and do not invent values that are not listed above."),n.join(`
`)}var qt=64,si=4e3,ai={"image/svg+xml":"svg","image/png":"png","image/jpeg":"jpg","image/gif":"gif","image/webp":"webp","image/avif":"avif","image/x-icon":"ico","video/mp4":"mp4","video/webm":"webm"};function it(o){try{return new URL(o,document.baseURI).href}catch{return null}}function pi(o,t){if(o.startsWith("data:"))return ai[o.slice(5,o.indexOf(";")>0?o.indexOf(";"):o.indexOf(","))]??t;try{let e=new URL(o).pathname.match(/\.([a-z0-9]{2,5})$/i);return e?e[1].toLowerCase():t}catch{return t}}function li(o,t,e){let n=pi(o,e),i="";if(!o.startsWith("data:")&&!o.startsWith("blob:"))try{i=decodeURIComponent(new URL(o).pathname.split("/").pop()??"").replace(/\.[a-z0-9]{2,5}$/i,"")}catch{i=""}return i=i.replace(/[^\w.-]+/g,"-").replace(/^-+|-+$/g,"").slice(0,60)||`asset-${t}`,{name:`${i}.${n}`,filename:`${i}.${n}`}}function ci(o){return o.startsWith("data:")?Math.round(o.length*.75):performance.getEntriesByName(o)[0]?.encodedBodySize||void 0}function Lo(o){return o?o<1024?`${o} B`:o<1024*1024?`${Math.round(o/1024)} KB`:`${(o/1024/1024).toFixed(1)} MB`:""}function di(o){return`data:image/svg+xml;charset=utf-8,${encodeURIComponent(o)}`}function Ro(o){return o.svg?di(o.svg):o.kind==="video"||o.kind==="lottie"?o.poster:o.url}function Kt(o){return!!o.closest(`#${R}`)}function Po(o){let t=[],e=l=>o?[...o.matches(l)?[o]:[],...Array.from(o.querySelectorAll(l))]:Array.from(document.querySelectorAll(l)),n=new Set,i=l=>{let c=l.svg??l.url;if(!c||n.has(c))return;n.add(c);let d=t.length+1,h=l.url?li(l.url,d,l.ext):{name:`inline-${d}.${l.ext}`,filename:`inline-${d}.${l.ext}`},{ext:m,...v}=l,u=l.svg?l.svg.length:l.url?ci(l.url):void 0;t.push({...v,id:`asset-${d}`,...h,format:h.filename.split(".").pop()?.toUpperCase()??l.ext.toUpperCase(),bytes:u})},r=(l,c,d)=>c>0&&d>0&&c<=qt&&d<=qt?"icon":/\.svg(\?|#|$)/i.test(l)||l.startsWith("data:image/svg")?"svg":"image";for(let l of e("img")){if(Kt(l))continue;let c=it(l.currentSrc||l.src);if(!c||l.naturalWidth<=1&&l.naturalHeight<=1&&!/\.svg/i.test(c))continue;let d=l.naturalWidth||l.width,h=l.naturalHeight||l.height;i({kind:r(c,l.width||d,l.height||h),url:c,width:d,height:h,ext:"png"})}for(let l of e("svg")){if(Kt(l)||l.closest("svg")!==l)continue;let c=l.getBoundingClientRect();if(c.width<2||c.height<2)continue;let d=l.cloneNode(!0);d.getAttribute("xmlns")||d.setAttribute("xmlns","http://www.w3.org/2000/svg"),d.getAttribute("width")||d.setAttribute("width",String(Math.round(c.width))),d.getAttribute("height")||d.setAttribute("height",String(Math.round(c.height)));let h=new XMLSerializer().serializeToString(d).replace(/currentColor/g,getComputedStyle(l).color);i({kind:c.width<=qt&&c.height<=qt?"icon":"svg",svg:h,width:Math.round(c.width),height:Math.round(c.height),ext:"svg"})}for(let l of e("video")){if(Kt(l))continue;let c=l.poster?it(l.poster)??void 0:void 0,d=[l.currentSrc||l.src,...Array.from(l.querySelectorAll("source")).map(h=>h.src)];for(let h of d){let m=h&&!h.startsWith("blob:")?it(h):null;m&&i({kind:"video",url:m,width:l.videoWidth||void 0,height:l.videoHeight||void 0,poster:c,ext:"mp4"})}c&&i({kind:"image",url:c,ext:"jpg"})}for(let l of e("lottie-player, dotlottie-player, dotlottie-wc, lottie-web")){let c=l.getAttribute("src"),d=c?it(c):null;d&&i({kind:"lottie",url:d,ext:"json"})}for(let l of o?[]:performance.getEntriesByType("resource"))/\.lottie(\?|$)|lottie[^/]*\.json(\?|$)/i.test(l.name)&&i({kind:"lottie",url:l.name,ext:"json"});let s=(o?[o,...Array.from(o.querySelectorAll("*"))]:Array.from(document.body?.querySelectorAll("*")??[])).slice(0,si);for(let l of s){if(Kt(l))continue;let c=getComputedStyle(l).backgroundImage;if(!(!c||c==="none"))for(let d of c.matchAll(/url\(\s*["']?([^"')]+)["']?\s*\)/g)){let h=it(d[1]);if(!h)continue;let m=l.getBoundingClientRect();i({kind:r(h,Math.round(m.width),Math.round(m.height)),url:h,ext:"png"})}}for(let l of o?[]:Array.from(document.querySelectorAll('link[rel~="icon"], link[rel="apple-touch-icon"]'))){let c=it(l.href);c&&i({kind:"icon",url:c,ext:"png"})}let p=o?void 0:document.querySelector('meta[property="og:image"]')?.content,a=p?it(p):null;return a&&i({kind:"image",url:a,ext:"png"}),t}var A=o=>`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${o}</svg>`,w={palette:A('<path d="M12 3a9 9 0 100 18c1.7 0 2-1.2 1.4-2.2-.7-1.2.1-2.8 1.6-2.8H17a4 4 0 004-4c0-4.4-4-9-9-9z"/><circle cx="7.5" cy="11" r="1"/><circle cx="11" cy="7" r="1"/><circle cx="16" cy="8" r="1"/>'),type:A('<path d="M4 20l6-16 6 16M6.5 14h7M17 20h4M19 11v9"/>'),effect:A('<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>'),play:A('<circle cx="12" cy="12" r="9"/><path d="M10 8.5l5 3.5-5 3.5z"/>'),layout:A('<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>'),spacing:A('<rect x="3" y="7" width="18" height="10" rx="1.5"/><path d="M7 7v4M11 7v3M15 7v4M19 7v3"/>'),figma:A('<path d="M8 3h4a3 3 0 010 6H8z"/><path d="M12 3h4a3 3 0 010 6h-4z"/><path d="M8 9h4a3 3 0 010 6H8z"/><circle cx="15" cy="12" r="3"/><path d="M8 15a3 3 0 103 3v-3z"/>'),info:A('<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>'),image:A('<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/>'),svg:A('<path d="M12 3l9 5v8l-9 5-9-5V8z"/><path d="M12 12l9-4M12 12v9M12 12L3 8"/>'),star:A('<path d="M12 3l2.6 5.6 6.1.7-4.5 4.2 1.2 6L12 16.5 6.6 19.5l1.2-6L3.3 9.3l6.1-.7z"/>'),video:A('<rect x="2" y="5" width="14" height="14" rx="2"/><path d="M16 10l6-3v10l-6-3z"/>'),wand:A('<path d="M15 4l5 5L9 20l-5-5zM13 6l5 5M5 3v3M3.5 4.5h3M19 15v3M17.5 16.5h3"/>'),boxes:A('<rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="3" width="8" height="8" rx="1.5"/><rect x="3" y="13" width="8" height="8" rx="1.5"/><rect x="13" y="13" width="8" height="8" rx="1.5"/>'),tokens:A('<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>'),code:A('<path d="M8 7l-5 5 5 5M16 7l5 5-5 5M14 4l-4 16"/>'),file:A('<path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5"/>'),download:'<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12m0 0l-5-5m5 5l5-5M4 21h16"/></svg>',chevron:'<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg>',phone:A('<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>'),tablet:A('<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M11 18h2"/>'),desktop:A('<rect x="2" y="4" width="20" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>'),watch:A('<rect x="6" y="6" width="12" height="12" rx="3"/><path d="M9 6l1-4h4l1 4M9 18l1 4h4l1-4"/>'),responsive:A('<path d="M3 8V5a2 2 0 012-2h3M16 3h3a2 2 0 012 2v3M21 16v3a2 2 0 01-2 2h-3M8 21H5a2 2 0 01-2-2v-3"/>')},f=H,Yt='<button class="pp-btn" data-pp-act="rescan">Rescan</button>',D=o=>`<div class="pp-empty">${o}</div>`,ui=o=>`<p class="pp-note" style="margin:0 0 8px">${o}</p>`,Ho=o=>o.text?`<p class="pp-status${o.tone?` pp-${o.tone}`:""}">${f(o.text)}</p>`:"",$e=o=>`<div class="pp-empty">Couldn't read this page</div><p class="pp-status pp-warn">${f(o)}</p>`,Bo=o=>`${(Math.floor(o*100)/100).toFixed(2)}:1`,hi=/^(arial|helvetica|helvetica neue|times|times new roman|georgia|courier|courier new|verdana|tahoma|trebuchet ms|impact|segoe ui|system-ui|ui-sans-serif|ui-serif|ui-monospace|sans-serif|serif|monospace|cursive|fantasy|-apple-system|blinkmacsystemfont|menlo|consolas|monaco)$/i;function Oo(o,t){return t?` \xB7 <a href="${f(t)}" target="_blank" rel="noopener noreferrer">source</a>`:hi.test(o)?" \xB7 system font":" \xB7 no font file found (not loaded, or in a stylesheet PixelPeek cannot read)"}function L(o,t,e,n,i,r={}){let s=o.cards[t]??!r.closed;return`
    <section class="pp-card${s?" pp-card-open":""}" data-pp-anchor="${t.split(":")[1]??t}">
      <div class="pp-card-head" data-pp-act="card" data-pp-value="${f(t)}" role="button" tabindex="0" aria-expanded="${s}">
        <span class="pp-card-ico">${n}</span>
        <h3>${f(e)}</h3>
        ${r.meta?`<span class="pp-card-meta">${r.meta}</span>`:""}
        ${r.actions??""}
        <span class="pp-card-chev">${w.chevron}</span>
      </div>
      ${s?`<div class="pp-card-body">${i}</div>`:""}
    </section>`}function M(o,t,e,n){let i=n?`<span class="pp-swatch" style="background:${f(n)}"></span>`:"",r=`<span class="pp-cv-k">${f(o)}</span><span class="pp-cv-v">${i}${f(t)}</span>`;return e!==void 0?`<button class="pp-cv" data-pp-act="copy" data-pp-copy="${f(e)}" title="Click to copy">${r}<span class="pp-cv-i">\u29C9</span></button>`:`<div class="pp-cv pp-cv-off">${r}</div>`}function ke(o,t,e=o){return`
    <button class="pp-sq" data-pp-act="copy" data-pp-copy="${f(e)}" title="Copy ${f(e)}">
      <span class="pp-sq-fill" style="background:${f(o)}"><span class="pp-sq-copy">Copy</span></span>
      <span class="pp-sq-hex">${f(o)}</span>
      <span class="pp-sq-sub">${t}</span>
    </button>`}var et=(...o)=>`<div class="pp-cv-grid">${o.filter(Boolean).join("")}</div>`,gi=new Set(["input","button","textarea","select"]),rt=o=>`${Math.round(o*10)/10}px`,Io=(o,t,e,n)=>o===t&&t===e&&e===n?rt(o):o===e&&t===n?`${rt(o)} ${rt(t)}`:`${rt(o)} ${rt(t)} ${rt(e)} ${rt(n)}`,No=o=>!o||parseFloat(o)===0;function mi(o){let{margin:t,border:e,padding:n,content:i}=o.layout.boxModel,r=s=>s?String(Math.round(s*10)/10):"\u2013";return`
    <div class="pp-boxmodel" aria-label="Box model">
      <div class="pp-bm pp-bm-margin"><span class="pp-bm-name">margin</span><span class="pp-bm-t">${r(t.top)}</span>
        <div class="pp-bm pp-bm-border"><span class="pp-bm-name">border</span><span class="pp-bm-t">${r(e.top)}</span>
          <div class="pp-bm pp-bm-padding"><span class="pp-bm-name">padding</span><span class="pp-bm-t">${r(n.top)}</span>
            <div class="pp-bm pp-bm-content">${Math.round(i.width)} \xD7 ${Math.round(i.height)}</div>
            <span class="pp-bm-b">${r(n.bottom)}</span><span class="pp-bm-l">${r(n.left)}</span><span class="pp-bm-r">${r(n.right)}</span>
          </div>
          <span class="pp-bm-b">${r(e.bottom)}</span><span class="pp-bm-l">${r(e.left)}</span><span class="pp-bm-r">${r(e.right)}</span>
        </div>
        <span class="pp-bm-b">${r(t.bottom)}</span><span class="pp-bm-l">${r(t.left)}</span><span class="pp-bm-r">${r(t.right)}</span>
      </div>
    </div>`}var fi={background:"fill",text:"text",border:"border",icon:"icon",gradient:"gradient"},zo=24;function bi(o,t){let e=t.layout.palette,n=o.cards["styles:colors:all"]===!0,i=n?e:e.slice(0,zo),r=u=>`${u.roles.map(g=>fi[g]).join("/")}${u.count>1?` \xB7 ${u.count}\xD7`:""}`,s=i.filter(u=>u.own),p=i.filter(u=>!u.own),a=(u,g)=>g.length?`${u?`<div class="pp-sub"><span>${u}</span></div>`:""}<div class="pp-squares">${g.map(y=>ke(y.hex,r(y))).join("")}</div>`:"",l=s.length&&p.length?`${a("On this element",s)}${a(`Inside it \xB7 ${e.length-s.length}`,p)}`:a("",i),c=e.length>zo?`<button class="pp-btn pp-btn-sm" style="margin-top:10px" data-pp-act="card" data-pp-value="styles:colors:all" aria-expanded="${n}">${n?"Show fewer":`Show all ${e.length}`}</button>`:"",d=t.layout.fills.map(u=>`<button class="pp-grad" style="background:${f(u.raw)}" data-pp-act="copy" data-pp-copy="background-image: ${f(u.raw)};" title="Copy gradient"><span>Copy gradient</span></button>`).join(""),h=t.layout.contrast,m=(u,g)=>`<span class="pp-tag ${u?"pp-tag-pass":"pp-tag-fail"}">${g} ${u?"pass":"fail"}</span>`,v=h?h.onImage?'<div class="pp-contrast"><span class="pp-pair-hex">Text sits over an image, so its contrast cannot be measured.</span></div>':`<div class="pp-contrast"><span class="pp-contrast-ratio" title="Text colour against what is behind it">${Bo(h.ratio)}</span>${m(h.aa,"AA")}${m(h.aaa,"AAA")}${h.large?'<span class="pp-pair-hex">large text</span>':""}${h.gradient?'<span class="pp-pair-hex">worst point of the gradient</span>':""}</div>`:"";return!e.length&&!d?"":L(o,"styles:colors","Colors",w.palette,`${l}${c}${d}${v}`,{meta:String(e.length)})}function vi(o,t){let e=t.layout.typography;if(!e||!(t.text||gi.has(t.tagName)))return"";let n=(e.fontFamily.split(",")[0]??"").replace(/["']/g,"").trim(),i=[];["start","left"].includes(e.textAlign)||i.push(M("Align",e.textAlign,`text-align: ${e.textAlign};`)),e.textTransform!=="none"&&i.push(M("Case",e.textTransform,`text-transform: ${e.textTransform};`)),e.textDecoration!=="none"&&i.push(M("Decoration",e.textDecoration,`text-decoration: ${e.textDecoration};`)),e.truncation!=="none"&&i.push(M("Truncation",e.truncation));let r=`
    <button class="pp-fam" data-pp-act="copy" data-pp-copy="font-family: ${f(e.fontFamily)};" title="Copy font-family">
      <span class="pp-fam-sample" style="font-family:${f(e.fontFamily)}">Aa</span>
      <span class="pp-fam-info"><b>${f(n)}</b><span>${f(e.fontFamily)}</span></span>
      <span class="pp-cv-i">\u29C9</span>
    </button>
    ${et(M("Size",e.fontSize,`font-size: ${e.fontSize};`),M("Line height",e.lineHeight,`line-height: ${e.lineHeight};`),M("Weight",e.fontWeight,`font-weight: ${e.fontWeight};`),e.letterSpacing!=="normal"?M("Spacing",e.letterSpacing,`letter-spacing: ${e.letterSpacing};`):"",...i)}`;return L(o,"styles:typography","Typography",w.type,r)}function xi(o,t){let{stroke:e,cornerRadius:n,effects:i}=t.layout,r=[];if(e){let p=["top","right","bottom","left"].filter(l=>parseFloat(e[l].width)>0&&e[l].style!=="none"),a=e[p[0]];if(p.length===4&&p.every(l=>e[l].width===a.width&&e[l].color===a.color&&e[l].style===a.style)){let l=`${a.width} ${a.style} ${a.color}`;r.push(M("Stroke",l,`border: ${l};`,a.color))}else for(let l of p){let c=`${e[l].width} ${e[l].style} ${e[l].color}`;r.push(M(`Stroke ${l}`,c,`border-${l}: ${c};`,e[l].color))}}let s=[n.topLeft,n.topRight,n.bottomRight,n.bottomLeft];if(!s.every(No)){let p=s.every(a=>a===s[0])?s[0]:s.join(" ");r.push(M("Radius",p,`border-radius: ${p};`))}return i.shadows.forEach((p,a)=>{let l=`${p.type==="Inner"?"inset ":""}${p.x} ${p.y} ${p.blur}${p.spread!=="0px"?` ${p.spread}`:""} ${p.color}`;r.push(M(`${p.type==="Inner"?"Inner shadow":"Shadow"}${i.shadows.length>1?` ${a+1}`:""}`,l,`box-shadow: ${l};`,p.color))}),i.opacity&&r.push(M("Opacity",i.opacity,`opacity: ${i.opacity};`)),r.length?L(o,"styles:effect","Effect",w.effect,et(...r)):""}function yi(o,t){let e=t.layout.animation;if(!e)return"";let n=[];for(let r of e.transitions){let s=`${r.property} ${r.duration} ${r.easing}${parseFloat(r.delay)?` ${r.delay}`:""}`;n.push(M("Transition",s,`transition: ${s};`))}for(let r of e.animations){let s=`${r.name} ${r.duration} ${r.easing}${parseFloat(r.delay)?` ${r.delay}`:""} ${r.iterations}`;n.push(M("Animation",s,`animation: ${s};`))}let i=e.keyframes.map(r=>{let s=`@keyframes ${r.name} {
${r.steps.map(p=>`  ${p.offset} { ${p.css} }`).join(`
`)}
}`;return`<button class="pp-code-copy" data-pp-act="copy" data-pp-copy="${f(s)}" title="Copy keyframes"><pre class="pp-code">${f(s)}</pre></button>`}).join("");return L(o,"styles:animation","Animation",w.play,`${et(...n)}${i}`)}function wi(o,t){let{boxModel:e,display:n,position:i,autoLayout:r}=t.layout,s=[M("Size",`${Math.round(e.content.width)} \xD7 ${Math.round(e.content.height)}`,`width: ${Math.round(e.content.width)}px;
height: ${Math.round(e.content.height)}px;`)],p=Io(e.padding.top,e.padding.right,e.padding.bottom,e.padding.left);(e.padding.top||e.padding.right||e.padding.bottom||e.padding.left)&&s.push(M("Padding",p,`padding: ${p};`));let a=Io(e.margin.top,e.margin.right,e.margin.bottom,e.margin.left);(e.margin.top||e.margin.right||e.margin.bottom||e.margin.left)&&s.push(M("Margin",a,`margin: ${a};`)),(n.includes("flex")||n.includes("grid"))&&s.push(M("Display",n,`display: ${n};`)),i!=="static"&&s.push(M("Position",i,`position: ${i};`)),r&&!No(r.gap)&&s.push(M("Parent gap",r.gap,`gap: ${r.gap};`));let l=`<button class="pp-btn" data-pp-act="guides" aria-pressed="${o.guidesOn}">${w.spacing} ${o.guidesOn?"Hide":"Show"} spacing on the page</button>`;return L(o,"styles:layout","Layout",w.layout,`${et(...s)}${mi(t)}<div class="pp-btn-row" style="margin-top:8px">${l}</div>`)}function $i(o,t){let e=t.colors.slice(0,24).map(a=>ke(a.hex,`${a.count} use${a.count===1?"":"s"}`)).join(""),n=t.pairs.filter(a=>!a.aa),i=(o.failingOnly?n:t.pairs).slice(0,12),r=(a,l)=>`<span class="pp-tag ${a?"pp-tag-pass":"pp-tag-fail"}">${l} ${a?"pass":"fail"}</span>`,s=i.map(a=>`
      <div class="pp-pair">
        <span class="pp-pair-sample" style="background:${f(a.bg)};color:${f(a.fg)}">Aa</span>
        <div class="pp-pair-info"><div class="pp-pair-ratio">${Bo(a.ratio)}${a.large?' <span class="pp-pair-hex">large</span>':""}</div>
          <div class="pp-pair-hex">${f(a.fg)} on ${f(a.bg)} \xB7 ${a.count}\xD7</div></div>
        <div>${r(a.aa,"AA")} ${r(a.aaa,"AAA")}</div>
      </div>`).join(""),p=`
    ${t.colors.length?`<div class="pp-squares">${e}</div>`:D("No colours found")}
    ${t.colors.length>24?`<p class="pp-status">Showing the 24 most used of ${t.colors.length}.</p>`:""}
    <div class="pp-sub"><span>Contrast: ${n.length} of ${t.pairs.length} text styles fail AA</span>
      <button class="pp-chip" data-pp-act="failing" aria-pressed="${o.failingOnly}">Failing only</button></div>
    ${s||D(o.failingOnly?"Every text style passes AA.":"No text found")}`;return L(o,"styles:colors","Colors",w.palette,p,{meta:String(t.colors.length),actions:Yt.replace('class="pp-btn"','class="pp-btn pp-btn-sm"')})}function ki(o,t){let e=t.fonts.map(i=>{let r=i.sizes.length>1?`${i.sizes[0]}\u2013${i.sizes[i.sizes.length-1]}px`:`${i.sizes[0]}px`,s=Oo(i.family,i.source);return`
        <div class="pp-fam pp-fam-static">
          <button class="pp-fam-sample" data-pp-act="copy" data-pp-copy="font-family: ${f(JSON.stringify(i.family))};" title="Copy font-family" style="font-family:${f(JSON.stringify(i.family))}, sans-serif">Aa</button>
          <span class="pp-fam-info"><b>${f(i.family)}</b><span>${i.weights.join(", ")} \xB7 ${r} \xB7 ${i.count}\xD7${s}</span></span>
        </div>`}).join(""),n=t.textStyles.slice().sort((i,r)=>r.size-i.size||r.weight-i.weight).slice(0,10).map(i=>{let r=`font: ${i.weight} ${i.size}px/${i.lineHeight} ${i.family.includes(" ")?`"${i.family}"`:i.family};`;return M(`${i.size}px`,`${i.weight} \xB7 ${i.lineHeight}`,r)});return L(o,"styles:typography","Typography",w.type,`${e||D("No text found")}${n.length?`<div class="pp-sub"><span>Type scale</span></div>${et(...n)}`:""}`,{meta:`${t.fonts.length} families`})}function Si(o,t){let e=(i,r,s)=>r.slice(0,4).map(p=>M(`${i} \xB7 ${p.count}\xD7`,p.value,`${s}: ${p.value};`)),n=[...e("Shadow",t.shadows,"box-shadow"),...e("Radius",t.radii,"border-radius"),...e("Gradient",t.gradients,"background-image")];return n.length?L(o,"styles:effect","Effect",w.effect,et(...n),{closed:!0}):""}function Ci(o,t){return t.spacing.length?L(o,"styles:layout","Spacing in use",w.spacing,et(...t.spacing.slice(0,10).map(e=>M(`${e.count}\xD7`,e.value,e.value))),{closed:!0}):""}function jo(o){return o.capture?[bi(o,o.capture),vi(o,o.capture),xi(o,o.capture),yi(o,o.capture),wi(o,o.capture)].join(""):o.scanError?$e(o.scanError):o.scanning||!o.scan?D("Reading the page\u2026"):`${ui("The whole page. Click any element to inspect just that one.")}${$i(o,o.scan)}${ki(o,o.scan)}${Si(o,o.scan)}${Ci(o,o.scan)}`}function Vo(o){let t=o.figma,e=t?.warnings.length?`<ul class="pp-list">${t.warnings.map(r=>`<li>${f(r)}</li>`).join("")}</ul>`:"",n=`
    <p class="pp-status" style="margin:0 0 10px">Editable Figma layers: boxes with fills, strokes, radii and shadows, real text, images and icons. Then click the Figma canvas and press Ctrl+V (\u2318V on Mac).</p>
    ${o.capture?`<button class="pp-btn pp-btn-primary pp-btn-wide" data-pp-act="figma-element" ${o.busy?"disabled":""}>${w.figma} Copy <b>${f(o.capture.selector)}</b> for Figma</button>
      <div class="pp-sub"><span>Or the page</span></div>`:""}
    <div class="pp-btn-row">
      <button class="pp-btn ${o.capture?"":"pp-btn-primary"}" data-pp-act="figma-run" data-pp-value="viewport" ${o.busy?"disabled":""}>Copy visible area</button>
      <button class="pp-btn" data-pp-act="figma-run" data-pp-value="page" ${o.busy?"disabled":""}>Copy whole page</button>
    </div>
    ${Ho(o.figmaStatus)}${t?`<p class="pp-status">${t.layers} layer${t.layers===1?"":"s"} \xB7 ${Math.round(t.width)} \xD7 ${Math.round(t.height)}px</p>`:""}
    ${e}
    ${t?'<div class="pp-btn-row" style="margin-top:10px"><button class="pp-btn" data-pp-act="figma-copy-pending">Copy layers again</button></div>':""}`;return L(o,"figma:copy","Copy for Figma",w.figma,n)+L(o,"figma:expect","What to expect",w.info,`<ul class="pp-list" style="margin:0">
      <li>Layers match how the browser laid the page out. They are not auto layout.</li>
      <li>Text uses the page's fonts; Figma shows a missing-font notice for fonts you do not have.</li>
      <li>Rotated or scaled elements, inner shadows and conic gradients are simplified.</li>
      <li>Pages are capped at 4,000 elements and 20,000px tall.</li></ul>`,{closed:!0})}var Ei=[{kind:"image",title:"Images",icon:w.image},{kind:"svg",title:"SVG",icon:w.svg},{kind:"icon",title:"Icons",icon:w.star},{kind:"video",title:"Video",icon:w.video},{kind:"lottie",title:"Lottie",icon:w.wand}];function Uo(o){let t=n=>{let i=Ro(n),r=i?`<img src="${f(i)}" alt="" loading="lazy" referrerpolicy="no-referrer">`:n.kind,s=[n.format,Lo(n.bytes),n.width&&n.height?`${n.width}\xD7${n.height}`:""].filter(Boolean).join(" \xB7 ");return`
      <div class="pp-asset" title="${f(n.name)}">
        <div class="pp-asset-thumb">${r}</div>
        <button class="pp-asset-dl" data-pp-act="asset-dl" data-pp-value="${f(n.id)}" title="Download ${f(n.name)}" aria-label="Download ${f(n.name)}">${w.download}</button>
        <div class="pp-asset-meta">${f(n.name)}</div><div class="pp-asset-meta pp-asset-sub">${f(s)}</div>
      </div>`},e=Ei.map(({kind:n,title:i,icon:r})=>{let s=o.assets.filter(a=>a.kind===n);if(!s.length)return"";let p=`<button class="pp-btn pp-btn-sm" data-pp-act="assets-zip" data-pp-value="${n}" ${o.busy?"disabled":""} title="Download these as a ZIP">${w.download} ZIP</button>`;return L(o,`assets:${n}`,i,r,`<div class="pp-assets">${s.map(t).join("")}</div>`,{meta:String(s.length),actions:p})}).join("");return`
    <div class="pp-btn-row" style="margin-bottom:10px">
      <button class="pp-btn pp-btn-primary" data-pp-act="assets-zip" data-pp-value="all" ${o.assets.length&&!o.busy?"":"disabled"}>${w.download} Download all (ZIP)</button>
      ${Yt}
    </div>
    ${o.capture?`<p class="pp-note" style="margin:0 0 8px">Inside <b>${f(o.capture.selector)}</b>. Clear the selection to see the whole page.</p>`:""}
    ${Ho(o.assetStatus)}
    ${e||D(o.assetsLoading?"Reading the page\u2026":o.capture?"No images, icons or videos inside this element":"No assets found on this page")}`}var Fo=40,Do=o=>$t(o)??"";function Ti(o){let t=o.kind==="color"?Do(o.resolved):"",e=o.dark&&o.kind==="color"?Do(o.dark):"",n=o.alias?`${o.alias}${t?` \xB7 ${t}`:""}`:o.value;return`
    <button class="pp-tok" data-pp-act="copy" data-pp-copy="var(${f(o.name)})" title="Copy var(${f(o.name)})">
      ${o.kind==="color"?`<span class="pp-tok-sw" style="background:${f(t||o.resolved)}"></span>`:'<span class="pp-tok-sw pp-tok-none"></span>'}
      <span class="pp-tok-main"><b>${f(o.name)}</b><span>${f(n)}</span></span>
      ${o.dark?`<span class="pp-tok-dark" title="Dark mode: ${f(o.dark)}">${e?`<span class="pp-tok-sw" style="background:${f(e)}"></span>`:""}<em>dark</em></span>`:""}
    </button>`}function Mi(o,t){let e=[["Colors",t.tokens.filter(i=>i.kind==="color")],["Spacing, size and radius",t.tokens.filter(i=>i.kind==="dimension")],["Fonts",t.tokens.filter(i=>i.kind==="font")],["Shadows",t.tokens.filter(i=>i.kind==="shadow")],["Other",t.tokens.filter(i=>i.kind==="other")]],n=t.tokens.length?e.filter(([,i])=>i.length).map(([i,r])=>{let s=o.cards[`system:vars:${i}`]===!0,p=(s?r:r.slice(0,Fo)).map(Ti).join(""),a=r.length>Fo?`<button class="pp-btn pp-btn-sm" data-pp-act="card" data-pp-value="system:vars:${f(i)}" aria-expanded="${s}">${s?"Show fewer":`Show all ${r.length}`}</button>`:"";return`<div class="pp-sub"><span>${i} \xB7 ${r.length}</span></div><div class="pp-toks">${p}</div>${a}`}).join(""):'<p class="pp-note" style="margin:0">This site does not declare CSS variables, so it has no named tokens. The cards below show what the page actually uses.</p>';return L(o,"system:variables","Variables",w.tokens,n,{meta:t.tokens.length?`declared \xB7 ${t.tokens.length}`:"none declared",actions:Yt.replace('class="pp-btn"','class="pp-btn pp-btn-sm"')})}function Ai(o,t){let n=[["Surface","surface"],["Text","text"],["Border","border"],["Icon and fill","icon"]].map(([i,r])=>{let s=t.colors.filter(d=>d[r]>0).sort((d,h)=>h[r]-d[r]);if(!s.length)return"";let p=o.cards[`system:colors:${r}`]===!0,l=(p?s:s.slice(0,12)).map(d=>ke(d.hex,`${d.tokens[0]?`${d.tokens[0]} \xB7 `:""}${d[r]}\xD7`)).join(""),c=s.length>12?`<button class="pp-btn pp-btn-sm" style="margin-top:8px" data-pp-act="card" data-pp-value="system:colors:${r}" aria-expanded="${p}">${p?"Show fewer":`Show all ${s.length}`}</button>`:"";return`<div class="pp-sub"><span>${i} \xB7 ${s.length}</span></div><div class="pp-squares">${l}</div>${c}`}).join("");return L(o,"system:colors","Colors",w.palette,n||D("No colours found"),{meta:`${t.colors.length} in use`})}function Li(o,t){let e=t.fonts.map(r=>{let s=Oo(r.family,r.source),p=JSON.stringify(r.family);return`
        <button class="pp-fam" data-pp-act="copy" data-pp-copy="font-family: ${f(p)};" title="Copy font-family">
          <span class="pp-fam-sample" style="font-family:${f(p)}, sans-serif">Aa</span>
          <span class="pp-fam-info"><b>${f(r.family)}</b><span>${r.weights.join(", ")}${s}</span></span>
          <span class="pp-cv-i">\u29C9</span>
        </button>`}).join(""),n=t.textStyles.map(r=>{let s=r.family.includes(" ")?`"${r.family}"`:r.family,p=`font: ${r.weight} ${r.size}/${r.lineHeight} ${s};${r.letterSpacing!=="normal"?`
letter-spacing: ${r.letterSpacing};`:""}`;return`
        <button class="pp-fam" data-pp-act="copy" data-pp-copy="${f(p)}" title="Copy text style">
          <span class="pp-fam-sample" style="font-family:${f(JSON.stringify(r.family))}, sans-serif;font-weight:${r.weight}">Aa</span>
          <span class="pp-fam-info"><b>${f(r.name)}</b><span>${f(r.size)} / ${f(r.lineHeight)} \xB7 ${r.weight}${r.letterSpacing!=="normal"?` \xB7 ${f(r.letterSpacing)}`:""} \xB7 ${r.count}\xD7</span></span>
          <span class="pp-cv-i">\u29C9</span>
        </button>`}).join(""),i=`${e?`<div class="pp-sub" style="margin-top:0"><span>Fonts \xB7 ${t.fonts.length}</span></div>${e}`:""}${n?`<div class="pp-sub"><span>Text styles \xB7 ${t.textStyles.length}</span></div>${n}`:""}`;return L(o,"system:typography","Typography",w.type,i||D("No text found"))}function Ri(o,t){let e=t.shadows.map(i=>`
      <button class="pp-fx" data-pp-act="copy" data-pp-copy="box-shadow: ${f(i.value)};" title="Copy box-shadow">
        <span class="pp-fx-box" style="box-shadow:${f(i.value)}"></span>
        <span class="pp-fam-info"><b>${f(i.name)}</b><span>${f(i.value)} \xB7 ${i.count}\xD7</span></span>
      </button>`).join(""),n=t.gradients.map(i=>`
      <button class="pp-fx" data-pp-act="copy" data-pp-copy="background-image: ${f(i.value)};" title="Copy gradient">
        <span class="pp-fx-box" style="background:${f(i.value)}"></span>
        <span class="pp-fam-info"><b>${f(i.name)}</b><span>${f(i.value)} \xB7 ${i.count}\xD7</span></span>
      </button>`).join("");return!e&&!n?"":L(o,"system:effects","Effects",w.effect,`${e?`<div class="pp-sub" style="margin-top:0"><span>Shadows \xB7 ${t.shadows.length}</span></div>${e}`:""}${n?`<div class="pp-sub"><span>Gradients \xB7 ${t.gradients.length}</span></div>${n}`:""}`)}function Pi(o,t){if(!t.spacing.length&&!t.radii.length)return"";let e=(i,r)=>et(...i.map(s=>M(s.tokens[0]??`${s.count}\xD7`,s.value,r(s.value)))),n=`${t.spacing.length?`<div class="pp-sub" style="margin-top:0"><span>Spacing in use</span></div>${e(t.spacing,i=>i)}`:""}${t.radii.length?`<div class="pp-sub"><span>Corner radius in use</span></div>${e(t.radii,i=>`border-radius: ${i};`)}`:""}`;return L(o,"system:spacing","Spacing and radius",w.spacing,n,{closed:!0})}function Ii(o,t){return t||!o?D("Finding components\u2026"):o.length?o.map(e=>`
      <div class="pp-sub"><span>${e.kind}s \xB7 ${e.variants.reduce((n,i)=>n+i.count,0)}</span></div>
      ${e.variants.map(n=>`
          <div class="pp-comp">
            <div class="pp-comp-preview"><span style="${f(n.previewStyle)}">${f(n.label)}</span></div>
            <div class="pp-comp-details">${n.details.map(i=>`<span><i>${f(i.label)}</i>${i.label==="Fill"||i.label==="Text"?`<span class="pp-swatch" style="background:${f(i.value)}"></span>`:""}${f(i.value)}</span>`).join("")}</div>
            <div class="pp-comp-meta"><span>${n.count}\xD7 \xB7 ${f(n.size)}</span>
              <button class="pp-card-copy" data-pp-act="copy" data-pp-copy="${f(n.tailwind.join(" "))}" title="Copy Tailwind classes">\u29C9 Tailwind</button></div>
          </div>`).join("")}`).join(""):D("No buttons, inputs, cards or badges found")}function Go(o){if(o.scanError)return $e(o.scanError);let t=o.system;return o.scanning||!o.scan||!t?D("Reading the page\u2026"):Mi(o,t)+Ai(o,t)+Li(o,t)+Ri(o,t)+Pi(o,t)+L(o,"system:components","Components",w.boxes,Ii(o.components,o.componentsLoading))+'<div class="pp-btn-row" style="margin-top:12px"><button class="pp-btn pp-btn-primary" data-pp-act="tab" data-pp-value="export">Export these as code \u2192</button></div>'}var zi=["css","tailwind","scss","dtcg","json","md"];function Wo(o){let t=[];if(o.capture){let s=o.capture,p=s.layout.tailwind.length?`<div class="pp-sub"><span>Tailwind classes \xB7 click one to copy</span><button class="pp-card-copy" data-pp-act="copy" data-pp-copy="${f(s.layout.tailwind.join(" "))}">\u29C9 all</button></div>
         <div class="pp-tw">${s.layout.tailwind.map(c=>`<button class="pp-tw-chip" data-pp-act="copy" data-pp-copy="${f(c)}" title="Copy ${f(c)}">${f(c)}</button>`).join("")}</div>`:"",a=s.layout.rawCss.join(`
`),l=`
      <div class="pp-btn-row" style="margin-bottom:8px">
        <button class="pp-btn" data-pp-act="copy" data-pp-copy="${f(Ao(s))}">Copy as AI prompt</button>
        <button class="pp-btn" data-pp-act="copy" data-pp-copy="${f(a)}">Copy all as CSS</button>
      </div>
      ${p}
      ${a?`<div class="pp-sub"><span>CSS</span></div><button class="pp-code-copy" data-pp-act="copy" data-pp-copy="${f(a)}" title="Copy CSS"><pre class="pp-code">${f(a)}</pre></button>`:""}`;t.push(L(o,"export:element",s.selector,w.code,l))}let e;if(o.scanError)e=$e(o.scanError);else if(o.scanning||!o.system)e=D("Reading the page\u2026");else{let s=Ut(o.system,o.exportFormat);e=`
      <div class="pp-chips">${zi.map(a=>`<button class="pp-chip" data-pp-act="export-format" data-pp-value="${a}" aria-pressed="${o.exportFormat===a}">${be[a]}</button>`).join("")}</div>
      <div class="pp-btn-row">
        <button class="pp-btn pp-btn-primary" data-pp-act="export-download">${w.download} Download ${f(s.filename)}</button>
        <button class="pp-btn" data-pp-act="export-copy">Copy</button>
      </div>
      <pre class="pp-code">${f(s.text)}</pre>`}t.push(L(o,"export:system","Design system",w.tokens,e,{closed:!!o.capture,actions:Yt.replace('class="pp-btn"','class="pp-btn pp-btn-sm"')}));let n=o.clone,i=n?.warnings.length?`<ul class="pp-list">${n.warnings.map(s=>`<li>${f(s)}</li>`).join("")}</ul>`:"",r=o.busy?"Saving\u2026":n?"Download again":"Download as HTML";return t.push(L(o,"export:clone","Whole page as HTML",w.file,`<p class="pp-status" style="margin:0 0 10px">One HTML file with its styles, fonts and images inside, so it opens offline. Scripts are removed: it is a static snapshot.</p>
       <button class="pp-btn pp-btn-primary" data-pp-act="clone-run" ${o.busy?"disabled":""}>${w.download} ${r}</button>
       ${o.cloneStatus?`<p class="pp-status">${f(o.cloneStatus)}</p>`:""}
       ${n?`<p class="pp-status pp-ok">Saved ${f(n.filename)} (${n.sizeMb.toFixed(1)} MB).</p>${i}`:""}`)),t.join("")}function qo(o){let t=o.capture?`<button class="pp-btn pp-btn-primary pp-btn-wide" data-pp-act="save-element">Save <b>${f(o.capture.selector)}</b></button>`:'<p class="pp-note" style="margin:0 0 8px">Select an element to save it here.</p>';if(!o.saved.length)return`${t}${D("Nothing saved yet.")}`;let e=o.saved.map(n=>{let i=n.url;try{i=new URL(n.url).hostname.replace(/^www\./,"")}catch{}let r=n.colors.map(s=>`<span class="pp-swatch" title="${f(`${s.role} ${s.value}`)}" style="background:${f(s.value)}"></span>`).join("");return`
        <div class="pp-saved">
          <div class="pp-saved-head"><b>${f(n.selector)}</b><span>${n.width} \xD7 ${n.height}</span></div>
          <div class="pp-saved-meta">${f(i)} \xB7 ${new Date(n.savedAt).toLocaleDateString()} ${r}</div>
          ${n.text?`<div class="pp-saved-text">\u201C${f(n.text)}\u201D</div>`:""}
          <div class="pp-btn-row" style="margin-top:8px">
            <button class="pp-btn" data-pp-act="saved-tailwind" data-pp-value="${f(n.id)}">Copy Tailwind</button>
            <button class="pp-btn" data-pp-act="saved-css" data-pp-value="${f(n.id)}">Copy CSS</button>
            <button class="pp-btn" data-pp-act="saved-remove" data-pp-value="${f(n.id)}">Remove</button>
          </div>
        </div>`}).join("");return`${t}<div class="pp-sub"><span>${o.saved.length} saved</span><button class="pp-btn pp-btn-sm" data-pp-act="saved-clear">Clear all</button></div>${e}`}function Ko(){return`
    <div class="pp-account">
      <div class="pp-account-avatar" aria-hidden="true">?</div>
      <b>You are not signed in</b>
      <p class="pp-status">PixelPeek works fully without an account. An account is planned for things that need a server, such as syncing your Saved library between computers and sharing it.</p>
      <button class="pp-btn" disabled title="Not available yet">Sign in with Google</button>
      <p class="pp-note">Nothing you inspect leaves your computer today.</p>
    </div>`}var Fi={responsive:w.responsive,phones:w.phone,tablets:w.tablet,desktop:w.desktop,watches:w.watch};function Yo(o){let t=o.deviceQuery.trim().toLowerCase(),e=r=>{let s=St(r);return`<button class="pp-dev-row" data-pp-act="device-open" data-pp-value="${s.id}"><span>${f(s.name)}</span><span class="pp-dev-size">${s.category==="responsive"?"any size":`${s.width} \xD7 ${s.height}`}</span></button>`},n;if(t){let r=Gt.filter(s=>s.name.toLowerCase().includes(t)||Wt[s.category].toLowerCase().includes(t));n=r.length?r.map(s=>e(s.id)).join(""):D("No devices match")}else n=Object.keys(Wt).map(r=>{let s=Gt.filter(a=>a.category===r),p=o.deviceOpen===r;return`
          <button class="pp-dev-cat" data-pp-act="device-cat" data-pp-value="${r}" aria-expanded="${p}">
            <span class="pp-dev-cat-name">${Fi[r]} ${Wt[r].toUpperCase()}</span>
            <span class="pp-dev-cat-count">${s.length} ${w.chevron}</span>
          </button>
          ${p?`<div class="pp-dev-list">${s.map(a=>e(a.id)).join("")}</div>`:""}`}).join("");let i=St(Mo);return`
    <div class="pp-dev-search"><input type="search" placeholder="Search devices\u2026" value="${f(o.deviceQuery)}" data-pp-device-search aria-label="Search devices"></div>
    <div class="pp-dev-groups">${n}</div>
    <p class="pp-note" style="text-align:center;margin:12px 0 8px">Click a device to see this page inside it.</p>
    <button class="pp-btn pp-btn-dark pp-btn-wide" data-pp-act="device-open" data-pp-value="${i.id}">${w.phone} Quick Start ${f(i.name)}</button>
  `}var Q=o=>`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${o}</svg>`,Di=[{id:"inspect",label:"Inspect",icon:Q('<path d="M4 4l7 17 2.5-7.5L21 11z"/>')},{id:"figma",label:"Figma",icon:Q('<path d="M8 3h4a3 3 0 010 6H8z"/><path d="M12 3h4a3 3 0 010 6h-4z"/><path d="M8 9h4a3 3 0 010 6H8z"/><circle cx="15" cy="12" r="3"/><path d="M8 15a3 3 0 103 3v-3z"/>')},{id:"colors",label:"Colors",icon:Q('<path d="M12 3a9 9 0 100 18c1.7 0 2-1.2 1.4-2.2-.7-1.2.1-2.8 1.6-2.8H17a4 4 0 004-4c0-4.4-4-9-9-9z"/><circle cx="7.5" cy="11" r="1"/><circle cx="11" cy="7" r="1"/><circle cx="16" cy="8" r="1"/>')},{id:"fonts",label:"Fonts",icon:Q('<path d="M4 20l6-16 6 16M6.5 14h7M17 20h4M19 11v9"/>')},{id:"assets",label:"Assets",icon:Q('<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/>')},{id:"saved",label:"Saved",icon:Q('<path d="M6 3h12v18l-6-4-6 4z"/>')},{id:"system",label:"System",icon:Q('<path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5M3 17l9 5 9-5" opacity=".6"/>')},{id:"clone",label:"Clone",icon:Q('<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 012-2h10"/>')}],Hi=Q('<path d="M18 6L6 18M6 6l12 12"/>'),Zt=class{constructor(t,e){this.bar=document.createElement("div"),this.bar.className="pp-dock",this.bar.innerHTML=Di.map((n,i)=>`${i===1?'<span class="pp-dock-sep"></span>':""}<button class="pp-dock-btn" data-pp-dock="${n.id}" aria-pressed="false" title="${n.label}">${n.icon}<span>${n.label}</span></button>`).join("")+`<span class="pp-dock-sep"></span><button class="pp-dock-btn pp-dock-close" data-pp-dock-exit title="Close PixelPeek (Esc)" aria-label="Close PixelPeek">${Hi}</button>`,this.bar.addEventListener("click",n=>{let i=n.target;if(i.closest("[data-pp-dock-exit]")){e.onExit();return}let r=i.closest("[data-pp-dock]")?.dataset.ppDock;r&&e.onPick(r)});for(let n of["click","dblclick","mousedown","mouseup","pointerdown","pointerup","contextmenu"])this.bar.addEventListener(n,i=>i.stopPropagation());t.appendChild(this.bar)}setActive(t){for(let e of Array.from(this.bar.querySelectorAll("[data-pp-dock]")))e.setAttribute("aria-pressed",String(e.dataset.ppDock===t))}destroy(){this.bar.remove()}};var Zo="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAdMUlEQVR42o2befRlV1XnP/uc+6ZfVf2qUlVJhZCRqQNhCNgCylKkwyABgssmEVBAW5dTM7Qs1FZoEsCWBrtbF7asphUaQYEODdoDk0AjYFQCRlEhJgypTJXU9Kvf8H7v3XvPOXv3H+fce1+V9Fpda916w73v/s7eZw/f/d37Cv+Pf9eb+Q+LpO7zX9qp9Zvv3/fwzd3xRadjHMVlEoDugpTyh5Qgrn4HtDHhE4An+e6E78+nlEh4AHzK94wrN++u80CKafii+zYlqtHYZjMfL9xT3feLV5/45jVHjsy1u+Rm89wg6TvJKd9R+vIDsxvdK4++4YUP1tywE+R7F4GHJvE+KqiBWXktn7G8tlTOWXmfbBBGbbhWAU35c1Iw8r1M87nu/lq+6z7nkytHkdQBPqQ0Eu5dd/pnl+zVD932sunHmgRcb54P/2MlnKUAMxMBELGfu6N+3jGt3jx3/km7Aeo5xBY0JDOwbmGqw63M8qpVISUBjJRATTAMKwtXK2u3QZGpU2QRNN9LSAZq1isGZBDaikbpFSGYl6wJmCjsd/HWR63Xr//zV+z7jN5ojpswROwfKcDMRMSZ2Rvdy77+ht864atXbe5CvZOSqqGKU5x0gmPDYjHDyAvuFq+pvKrl75AVazEwyYIVxXXKNC3fm6EmvbVY+W2366L5t2dZQlGMqJkllAhU3k+Bi6rFW+/95T2/GswEy5s8KMBMuAmxm74xuuHvHnbzyYm/7szxmDQiSZ3rhEhlQWaCZan6Xet2wfrFGkmlV5aVP2NqvVnDcP2ggCKHUhRgSG8RWcn5BuVzUXz/vjOvEpMkkSyCnzp/oa8/eN/r/92PyQ03CTejiJhgJteD+6iTdN2X24+cnI1+eOvBFMxkFMuiUvHnwWwNM1f80XqztF6aznSLJaz6t4HqcH3RI5qkN/XOUkyLomFQgkp+r4aY0N+grE2QbClZ+PxeFQLBzfzoEl+/7/63zF4R3/i5ijc9I0oX7X/4S/Ubju+ZvGXrAW1VGfeBTrMprvpr76fdHy0Rq1uArvhyHyeK1XQuYLZ6XbaMXrkqmEo2ZwPnisul4vtdhCwKGYLY4AbWWYlKVoaCJQvVzI0ePp2/+o437/ttbjYvmMmrvtY8+q+2Rn+zuTCnEZcU6SP5ql/basS2Yo6ru9P9JguYFy2kZL17YJDUUHVZuTq4Tq/YbgeLydui394VIW0wf1bMvwttuqqszk3MUKd7qti+8Mrw6A+8cnZPJSJ2+xfaN86dG8U6RsWJaRbOEFQt36dTuBmpnBsCUj66WIFKMXfptaa9SZes0H+3ouiU/5CUnZMI2hovvjpx7VWCdxA1HyHl11aNkKCOsIywCLBTG/NGmNewtYT5UthZGLu1SFOr1a6a3XI8/aogPyOv/JvlFbc8OPr7nSAzS4aWTGglBZlZ9mdAKVG7U6xKjsapLDoV/9PBpLsd7WKBruT61bRHoigAnAmikHaMNz8/8Zpneh5cDEI2EYIaTRSamF/rYOwGYbsxtnaFnRo2l3B6Dpu7sLUL84WwbMzmtWNscfslTzzz6OrrJ+SGpfi11KZkJp4unZqhZgVjyJB+HZxxYJNiljVMasdYDZc6JVhvHV067FKj9qBI0GRZaMu/y5Hb0FphIVx1UeKnn+H41ibUwWjK75oI8wZCsoI0YV7DojWakGNL3UJdG20jxBZSAI1gScSlpLVU+794554XVluNe/bSMJIVdCCYaTH5DGC0cyER5h7+7dXGUw5Co7AMxitvFU48KFQRvBquAKFk4IpfhrLDjpwF+oC2KrwCtfJDPwg7h42rpoIlIZUAW4lw+4YyccKBcU7J928buy0cmAo4Yxng2BljMpIVK8uBVUqcEDBN2OZu9axq2cqVKSGu2xVWfBIwHCZZCcmDjYwXHREeOZUCI5Rf26ecmgt7p1BvQ5zD+IAx87C7ARpg7wEwU3Y3PHhj70FIjbHcEPzYmM6gnUPcFR7xaPj6QYfN88KjGZMKPn2X8sZPCvtHxm88H3Za4Y2fgGbX+NkfgIeswx/8hXLsfuEpVxoPPV+IsShci8XlgOYsIbXJY11KHLLWQJ1Y2SUrvpzfa++bWrDAmWC0Clsxv26o8NOPTdx1HfzoY4xajA88x/j2jxiPulgJa8anfkT59EuFak15yGHjj34KbnxRDi6PvsJ4+2vgWc9VrDU2l8KpTVjOQcVICohwfMcIp+HURjb3ZTB2zkB7BnZKjNg4Dew4duYQUz40ZSvQwRrEIqhyuDJzE9Ns3l2eL9C4dwMVMFe+j7C3grGDsct5aY/BR486vrZl3HkMJAr/+lbjwAzuOumQGv7l57M5hh3h1AJe+z+NnbkgQfj2PcZ//JCx8WD+3FYQ9kAMQ51wZmk882Ge+JzE+kQ4b02YRfi5ZxhbS3jYBULdCtc9WbjnAeWCw8JiaaTUWUEBW0qPRwQm8qgPJps34GQFSZaqrk+jRQHqYDGFp1yuHNkjtApe4VN3CPXp4sctSDIsrRQtWurbEuT6ejcJYobF/DuCQGM85Epj6eDaRxi/fr3j26eNNkIdYOxz5N+qc/RHhGWAzbkxr4VFyAHyzA5sL2BnCbtL2K1hWefgGIPRRM+BSZhXlABB59Id7NUBuJhAKgqY1HDLHZ7LLk5csdf409sr2AXXGtICUUgJXEmNXf53BUxoBJLDpSy4xZzvJQrWGtYaD3zJ4HgiXWdoNUZNCKoYwsk5bDcQ1VGHHISXrdAEYdEYO7Wwu4RFA8sWmpCzREwFwNlqLSxUfU6Ws3M0valIyQBgYvgkODVedSm87HLHRX+XU1aKZVfjEC8GNFbukwQJBk2b40oyJIIFCqoxCIGRRSINyBTVCVEVQTi1C392V97REHNmCVFoY/7cBKGNkt9HIwSIUWiCkQLESF+ed9C5spT9Wl0HWrpYoAOeH+qNngH679+Cvz1tpB2H1DKYuJ7zWvK8RQVxyMZx+Mp7s9TaYBoRFLE0sB9VhZ1pkVNPI8mLiUkRHPdtChtz8Ca0LbSpKCEVhUQIIbtLKAKHZKROcB3qkW59vQUMxYoVyCs9UtNUAJEJiVyc/OU3hb8UkFrKDnY3tVKJDVVZrwwEayK2fTQ7vbW9qXSQC0DjCJolGjf7apRS1FEgcCqRPaWCOYqJ53O5Wk1F+CyHYMlKNujKZ+sUIKiUNGEDkaG68uOSETxG28LPPU259jLhBb+vuOjQZAXQCHT5NhoSigRJQStcWzOaKEZV0GIqlWQq1aXh/QjzASdZ4R13EJMRYi6Ho0LbmX/Kpt5Gy2lPhRQLG9XD7ZLVVAZugeICGg2Rc6q/NMDYgekpzI/CpBJm41JuxhVzT2V1eNzGg8ht/xWjxZHQ+S6Pe/wF3Pz5t1K3WaoYjUVjbC6UE1uJE1uRY5vK1+5uuPSxB1jWlsFYuW1aKQr3zYwQsyLqYFTOaB0EEVyJ604gISxjUYJyVnaqupTUxwW1npDo/bfAWStxSgR+6/PCb90CsqBE9kJAJIHoM6qsG9j4JriAScJ25oxSxSMvP0woJElMMC9Fy9qmMToViNPEfXXArzmSGrFQaEmzITmBx16accZuIyzaLupLTndNTnfLJqe+EGE8gtNnshWLaV829y5gBXGdFfg6fq68DsQGPPKwcuF+44snPNIpMZFNvm1APT42TPdW4PKOREuMJ1M2tiNNzOYf2sSiNk7tRE5vJjY3E9tbRr2TiM2EZGtEBbFcE4QozCbGob3CYglNm12yDdC2QgicdaSCBitvOCnprC/l+xhgfXlr55CdGRdYjwu8ZJe57gnGtVc6rrkNXDRSSCAVcu9X8Hd8iFS3XPWES3nfn7yNEJTZRNi/Zvz1t4XHvmILGU+Rjb/AHrgZkxEpLdHUoJrQ2ZOpt9ZZe9EjsRc8nZQSzmWSxQTqBo6eMg7tERJSPM8KV2DELigW4VOCRUmdOb+vxoCebu4wgBWayXpf0VS4OYVUCP3P3S7ctWHQ5EID9SCCLbaJO/diy0CV1rj04oPsLuG8dVgbwX3bygMntmDi4WSA+0+Cm0DaAa2BhOzfweZCaOocBIvVpRUO8Wv3gnPW44A25NQYkhDL7scu98d8nXUR3gaUWnVRXswKoyMDlV2YHbr0WCxEgNu+Ltz2DyA10CakaYGKkQtM1ypa75lNZzStEUJkey7oVNhZRMQ1uGqCjBI2zrs6mU2p/BjTSBg7GmkwUnbLjmgtKRmXlT5fCiGWvB8z5o/RiNHQIMSY6TiN5R5phUIriqxUB769s4CepkrWp8UsvOANUoQfenbiKQ83fuVdY6qvfhI5+knizoKXvPz7ef3v/w4nNyIH1ifs3wP7Zp5r31DzjfsqNG5iZ76Mbq3hdv+asXuA5ZldXv/rr+XlL3kB9xxPvOq1b+avj34Rwoio11IwVFFGtshRpVy8N+90HaCNlmFvm4/QQohWlEIPhkKT5RqyQCl7u0Zfz+mtdGM6gjNr0CAK1Ujwk+I79TY2vxfbXrBvolxy2SFme2AyhsplcuW+045jx7NriRYobBEvDWjDofP2cclDDmETGFUJdAfTZd9ac4VOiyZ4Zzz6oTkNL+rMFtWNsGyFujYWjdA00HTBMWT/V4Wlg8X8XCi8Qlt1lHLH5fWUVdFYKtbyvz7r+fjnQHYhpSbnU5fft41RNxGHw9YciDEZC25sOHMkM0RkoJFFWC5rdpcNO1sFayAgjti1zaTwlAqjCiYjaBpog9GGnA2aJhc/IWbXiCtBsDucFIo8l8NUxIJGCwO8qoysAFkpkBTE43Y3aT/3Tpzuws4mr/rZZ/DjL3oHp063XHHpQaYjuPCQw4lQ+YIkHyPoRWP8iTNUX3034sdI2iGZZ7K+xtt+83f5nXf9ISEapzd3wE9JqqWWyiYbSwBf1MKdDxgH91jm/tqcGeqmuENTUmMUYrAVFxCaWld6CUZlmuGriQ7dmK5JoVJYoZUmhABNjWx+HScL0qmTXHTes3jCVZdzYgPWZiCWmFRD51HEYL182FWcbvStHAPEO06d3uD4iVOAMB6vgfjSPyxlrBtqJcE4tgH3nizVX5sjfohGCEIqQmu0wYq7DbRC/JUSt7K+pTWYeY+XV1nb7rx0Pe5dkCVow6jKZOdonM1TpCAuWWlaNOUImiOU90PbxxKjUUVVdVE6gLWYxbPrk6IAJwWVhi7q50AXiyJSyLtt0VYbpkPrzopGk1FpygjP2crur/D2q/33XA8bNjsPrv5lUmhxQXjfp+/iL269iZ0zkRdc9zR+4uXPZXM7MhkLB9byLvonZsbIP3Ap4d53wnSKv/tzyN//HjaaZXhqDkstXPELcPgy7ODhrAAczoZZAzVhbWocOW+I+k0rNI3RtkbbZiwQA8x3StzqO0ddL1Mx1QKEUteRtb6poQqipUKiY0Ry0DI3ZXTVU/EO6g346pdu56vf+hS0kYdcegE/9tLnMN9NJPWsz3LyGF3g8BhO9pEu/R6Ygts+BmKI9zkD4TAnsPefwORJ6LTpO0la1heiYzIyLj+Sl7OooalgXMHYQ+Oh9UbjIY1y5to6Y1hX2GgJ/wXsVT3px0rP/jtOYWT/8UAKyvP+WeS7HxN5/dsmjKZGtV7RbhmHDkzZP3PEQxPGHpzL6t9uckttUSfYaUEn2O42trOAUGUE6ByWlkhcQlxixFymm/VN16S5Zomlzk+pEB/BsvkXd9CuMOuwvayMnfQtqrSSBlnJ/V03FSvRRweFCH3XVXwF5tDzv59WDqLLyP++5RTHfuotzOfw8Eddwht/6ccJIfH28yGMjG9NjLc8vUJGwuy7vo/Zj7wHdWN27oH6mCBRYf1xcGwK65aRnAhCaZCQzf1bDxh7prnuatpcCLWNEVshFApMk7GYFwF1dXhhCCpV174SsbOIUER6Po+V+iCpQAV//HHPH/+JIQslrT0Czr8QonLH0Zu545ZPQAtXPvVx/NJrXsZiqbzgIIwm8NUD8LZHeJzCdN/F7Nl/MRFY/C3onSANuARSR2yiA6FB3vmUwIuxOYfjp+l9XSPEIMTWIEBf2q62nFcHFTRD2h4Kd2BPOmqsKxq05E3L57qi6bLzlSP74da/kozsaMCPcWsjxuuesICD+0ccOuTZW3v8tMTQNdiepwx+SNRmJG9s7QBzB42RnEA7DFzFrs/Y0XSlqPNiKIIrlatYCeYY1nVkdUX4vqWebyyqnQtYbnysjqH05XDuqXXKqySnm5dfAy/+brjqZ0DwUE1yuXrgaoI5tG75xunAT/38O1BTxiOHjy3Tiy7kP73iJWhKVBX4Kjc7tx5pnFmPbG0bp7eVu1PgwvWKNla5FijkiWoxzr5KLVMsfXd5yJdiOpT1usrz90wPlRUq23yOAx0r1Pf+V2YO6Pr/TrjtqOGcgVVlTqHKuXvPFaTRRdC2nDzzd7z/3e/IIAGDepfHPPXx/PbrXkrTKiIuNzwwtg4lToyVu09FjrrEeCOwf6IEnZG6eYWV2aK+1o+FsFHBVEsmy6ZvqzN2Z1V93TWRqq+MKEGPlXZQISmHSYw8LsPI+NhnPB+LGfWp5BIV9ZnulgSVw83G+P0jTMA7Ic0j5x0Yw9Thpg4BvIGrPfgRFsAmShglUhVQJ0TNh0ZYn8Gl52fLbttc2YU28wCxpbTCpTDBI1JQmkWDpZT73KYFb1hp4ycqSSl/MApyk37gqHeDfpouU1upFa75gcTVl8B/+IBDJJfKiCDOY9UUnGFrl5COvAQLSxTF9rR847TjJ1/92/2wp1pmcNooLIMxrx3zZsTpky2Pf/qVXPXUa9BkxNLenlU5JLkE3mUgKU5wYuBAnOK8oRgyEqKDqJpjQgE/Qo5ropHKomYqu2OJxJ9FGZ01TSiCuLzBz3gcvPifwm9+JJOgZgmcK/y+z342OYQevgbCLhYaEOHEzjd4z7vemec6ZSW3igNXgUxgMoXtlksfNcXcMEwVY955SwPsDQ3E1gitEVtDo6HJSClnEDTRNwdWB5DKuSrfeVVKI49agjl/lhJEQKsciX/3zx2fvDOhgbwV5oosHlyOJpYAF6HyIFUefxmP8QfWMMkBRso4DniQMcYIYUqqRogf9+AnJtenO0t55iCVKq/7zjQLr6nzfxvq4I746IBOypG0kp5mkUFKyZO3ogkKPJUyfqreuPwxxvpe48SO46onKf9wu8e2R4iPBW9YNksEFQFfITpBkqJ6IenAMxGtQWNeLJkfMATTMeMjh0gXeFh/ZKnpXS+HxlzthZCtIEWIQYlBScFI0VDVrAgzTBNYQEqzw7r2Uikvq2FauTNDl4MFmasTGYhEE4Gp8u9fpjz5Es9OgFqUG96W+NZXHYxGOZ04RZNkCtlFsIgFn7dqNsEOPz/3rtMCqh0ICasFfEKmjvV/8TROtTPSzEiNoprr+o6b0LKJeepD+4nUVCq+vNHZCqyYiNlq23vICpUlLUhDVgb+pNDnPuMDWRlS9kY02KhhuwU/FpbeuPZ5idc83fMbHxc+8+kR/+YXlMdeLvzSfx5x9z1j3v46Q/yUX/k1z3mzMb/4ugu54+iSd994lEu+a8bTX30RX/nsFv/w3nvwM4VWMVFUXZ//dxfGgyfyVFqGvansvKIhYimVQi6DIE0Ra+uVcdU0KKG08CrRWPpNrjh59z5H1Zz/pUCsXBV6L/hK8Jrjlh8ZJ5bCl08qG0uDkfDNDYhTo44CHu48AYZi1YjWV9z54IhjGw7W9tPohAfvnjA/M4HRGn7NQ3QkZ6Xjm3t/Z7aM02cUjxGaRIqR1KYV/rubxYsD/i++n7vPsc8GHUFSDR1ENwhON59aGBAnoC53fBvhayeVap+yG4TFjtLuwldu83zlC1Z6Z4kP/mHBDuV+v/fOQulUytZO5PfeGiA2MIYTd835zJt2wC3BBdr7a8R5dKyEOCKl7PNVqU+0+LIlRbT4dY/7O+E7jB8LIsysqHT+Uwq+KrZhSZJZHvd04HyeFDS/0kUtIy9OkEa46f1CdSgH9rgt2P2CS4aLCY0JVcUXNqgbrPIOcDk9CYqbBSy2aHBI5XAHarRNWDA23n8U2zV49n7CEx9Giom2Ec5bhyOHhfncET1E50kuW7NREpEKpg5IWApIl93KYPUqGDLTUFW0m+hoRkwm4vMsi+TRuL57gGcIBh455YinS3oMuYTVoJhmP8Q0jwPYAKDy8xMl7ZUeveHB+TyNquPsZr4BW0K7ZLnrCDHP9IQ2NzkeesSxu89TL416CfVCaZpIDDHHg5hIIaAxgbRYyoMYeQSoG0nVTEVrPFGNJNwOowtJwUw0j4Q5PwREV1790CES58vQYTf+kpCUMI3Dlhfg1ClAijdZ11/vzruqmNm4PMNgmctbc9z7zS3mmxHE09SJ0MByabQ1tEsh1Im2TcQ2koISQ8JCzOvoqGAt4CHFbl4ONCmM3MTp1/0Fj//5I9tL/2xLjYqpE86dh2d1dq4gK10h2yOSQja34pOyQioKKw0HVcS6aeNVstEKAOsexFDEQ31mwfaZXS58+AWEVBGSK4DIEaIjJk9Inpgcqq4MRHJOBZjX2+EAsYRZwjtxFx1M76ie9PD0kROntt+0iDLFJTN1gvgytZzKkXO4SDHZlZqBjm0tryI6sMzIcK0UbywxJY8fWz8aI1Ku9RXCCAsJmU345q33cfzoKQ5ecj5mFW1QYttRYIkUlZQSGiOqqYzvn53rOzY4zwVkimky1c2nP3H//xAncMFzv/wHx7f2/ShpK5rzFeIZDjccrsrFDqUAGh44WmFcVyupAq4gD0jJUGHKWZWmldTVLTxAWEKoEV1gzSJ/1pgLEQrH10V8GR4oEudKnQGGz5smHpP8vSARv7966OHmXfd/4UU/69RMrrpC3zx1260lE7S1DLRbSA2Smvw+NhBrCDXEGgvL/DnW+Vx3XWoL9Czzb9oW4B7682IR04BozHBb0+roXv7P+zwt5kbIZIrM9iBre5DZGm6yhoxmyGgNRmuIX4NqCtUEpMrchIwRqRjAjEMMs+RlNqp3v+fq/b9umHiuv8kffe/Fpy55wsvDTrv/2RoWEVO/8iTDOcOD3fBtN0TUCZDOLjZW3ot1z7SlAkRKnOioK/TsuNDFj9LAKw/d5R22XESZWYknDK1tDNf178lzjVIoMjHDVONosre67Pz0r7743677LNdf5bODXn+zqz56Qzr0A3/6gRPb+19i8UwQ50dWXCD7JyvaHHw6+7hbKRnPnsSU1TjQFVtdZujdQIbJp45+1thHb9FsjZ3VYKHPONK1tAvYkTLJKHZWRW+mEp1fHx05r/kvJ/7qFT+Tvu/Gis+/Ka6gBMTsw3LBMw5/8PRi/Xptt1J2X+/NrczWILn1Je7s5y77YEd/TXe9iSDiMArxuBpEV5946lesZz9qkmKeHilwNqe2kCO6pozuJGcoK5FepG+FJVPEj/a6A3vjezb/9id+Mun1Hm7WgeZdefpoVIld9Mz/8/YHN/wvNq2ALVVETETE+pW7f5TnrQwgicu7bF03qbOc8j0mg0XZOVbTB8WzH0QUUyy1iMYMaVPZaeuAV8H6pphGE1MTS6qmDiZuOjI9fNDd9MCXf+ItSW90cFPPdp6zDZ2hiz3hn//JNfecrN48X7rvbYLPaKp7lMuGR09zzbDKIHVm7gbh+0yyYiU2WMvQcbFzpplX/NvSAGZIQ8GT4hBzNJRHTR0ijrGP7N8nX3jYEf+rX/rEj91i3OjgTXbOar/j09MebkijCr7rRZ/7wWMn0ou3F+F762CXqMnUylBDFqIIuvLcYP9dZwWuS4eyYv6r150tb68WYyUwpsElKIguhT6g5pnjhJe0HHu9e33m/+yyh0w+dOvHr/9sGwaZ/v+eHge4/mbPh/MPHJDsrum1rzxx6amT8wsXmzs+VlBFiFVFBURiodZKm3vlXyxXVHkeg+50PPfCci5G8j0idH+n/IXhbjH21xMzt7//vD3xgvP2H/+j3/2+u7xI6AA319/sOlnO/fd/AeNOCzuVUPyFAAAAAElFTkSuQmCC";var Se="pp-pill-pos",Ct=40,st=8,Bi=250,Oi=4,Ce=o=>`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${o}</svg>`,Ni='<svg width="12" height="18" viewBox="0 0 38 57" aria-hidden="true"><path d="M19 28.5a9.5 9.5 0 1 1 19 0 9.5 9.5 0 0 1-19 0z" fill="#1ABCFE"/><path d="M0 47.5A9.5 9.5 0 0 1 9.5 38H19v9.5a9.5 9.5 0 1 1-19 0z" fill="#0ACF83"/><path d="M19 0v19h9.5a9.5 9.5 0 1 0 0-19H19z" fill="#FF7262"/><path d="M0 9.5A9.5 9.5 0 0 0 9.5 19H19V0H9.5A9.5 9.5 0 0 0 0 9.5z" fill="#F24E1E"/><path d="M0 28.5A9.5 9.5 0 0 0 9.5 38H19V19H9.5A9.5 9.5 0 0 0 0 28.5z" fill="#A259FF"/></svg>',Ee=[{id:"inspect",label:"Inspect elements",short:"Inspect",desc:"Hover any element to read its styles. Click it to select it.",svg:Ce('<path d="M4 4l7 17 2.5-7.5L21 11z"/>')},{id:"devices",label:"Responsive preview",short:"Responsive",desc:"See this page inside phone, tablet and desktop frames.",svg:Ce('<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>')},{id:"saved",label:"Saved",short:"Saved",desc:"Elements you saved, kept on this computer.",svg:Ce('<path d="M6 3h12v18l-6-4-6 4z"/>')},{id:"figma",label:"Copy to Figma",short:"Figma",desc:"Copies the selected element, or the one under your pointer, as editable Figma layers.",svg:Ni}],ji=`<img src="${Zo}" alt="" width="28" height="28" draggable="false">`,Xt=class{constructor(t,e){this.callbacks=e;this.left=16;this.top=0;this.closeTimer=0;this.noteTimer=0;this.dragging=!1;this.pressed={inspect:!1,devices:!1,saved:!1,figma:!1};this.onResize=()=>this.place();this.top=Math.max(st,window.innerHeight-Ct-24),this.el=document.createElement("div"),this.el.className="pp-pill",this.el.innerHTML=`
      <div class="pp-pill-card" role="toolbar" aria-label="PixelPeek tools">
        <button class="pp-pill-mark" title="Drag to move" aria-label="PixelPeek tools: drag to move">${ji}</button>
        ${Ee.map(i=>`<button class="pp-pill-btn" data-pp-pill="${i.id}" aria-label="${i.label}" aria-pressed="false"><span class="pp-pill-ico">${i.svg}</span><span class="pp-pill-tip">${i.label}</span></button>`).join("")}
      </div>
      <div class="pp-pill-note" role="status"></div>`,this.card=this.el.querySelector(".pp-pill-card"),this.note=this.el.querySelector(".pp-pill-note");for(let i of["click","dblclick","mousedown","mouseup","pointerdown","pointerup","contextmenu"])this.el.addEventListener(i,r=>r.stopPropagation());this.card.addEventListener("mouseenter",()=>this.open()),this.card.addEventListener("mouseleave",()=>this.scheduleClose()),this.card.addEventListener("focusin",()=>this.open()),this.card.addEventListener("focusout",()=>this.scheduleClose()),this.card.addEventListener("click",i=>{let r=i.target.closest("[data-pp-pill]");r&&this.callbacks.onTool(r.dataset.ppPill)});let n=this.card.querySelector(".pp-pill-mark");n.addEventListener("pointerdown",i=>this.startDrag(i,n)),window.addEventListener("resize",this.onResize),t.append(this.el),this.place(),this.restore()}destroy(){clearTimeout(this.closeTimer),clearTimeout(this.noteTimer),window.removeEventListener("resize",this.onResize),this.el.remove()}setVisible(t){this.el.style.display=t?"":"none"}setState(t){Object.assign(this.pressed,t),this.card.querySelectorAll("[data-pp-pill]").forEach(e=>{e.setAttribute("aria-pressed",String(this.pressed[e.dataset.ppPill]))})}flash(t){this.note.textContent=t,this.note.classList.add("pp-pill-note-on"),clearTimeout(this.noteTimer),this.noteTimer=window.setTimeout(()=>this.note.classList.remove("pp-pill-note-on"),1800)}open(){clearTimeout(this.closeTimer),this.card.classList.add("pp-pill-open")}scheduleClose(){this.dragging||(clearTimeout(this.closeTimer),this.closeTimer=window.setTimeout(()=>{this.card.matches(":focus-within")||this.card.classList.remove("pp-pill-open")},Bi))}clamp(){let t=Math.max(st,window.innerWidth-Ct-st),e=Math.max(st,window.innerHeight-Ct-st);this.left=Math.min(Math.max(st,this.left),t),this.top=Math.min(Math.max(st,this.top),e)}place(){this.clamp(),this.el.style.left=`${this.left}px`,this.el.style.top=`${this.top}px`,this.el.classList.toggle("pp-pill-up",this.top+Ct/2>window.innerHeight/2),this.el.classList.toggle("pp-pill-left",this.left+Ct/2>window.innerWidth/2)}startDrag(t,e){if(t.button!==0)return;t.preventDefault();let n=t.clientX,i=t.clientY,r=this.left,s=this.top,p=!1;e.setPointerCapture(t.pointerId);let a=c=>{let d=c.clientX-n,h=c.clientY-i;!p&&Math.hypot(d,h)<Oi||(p||(p=!0,this.dragging=!0,this.el.classList.add("pp-pill-dragging")),this.left=r+d,this.top=s+h,this.place())},l=()=>{e.removeEventListener("pointermove",a),e.removeEventListener("pointerup",l),e.removeEventListener("pointercancel",l),e.hasPointerCapture(t.pointerId)&&e.releasePointerCapture(t.pointerId),this.el.classList.remove("pp-pill-dragging"),this.dragging=!1,p&&this.save()};e.addEventListener("pointermove",a),e.addEventListener("pointerup",l),e.addEventListener("pointercancel",l)}async restore(){try{if(typeof chrome>"u"||!chrome.storage?.local)return;let t=(await chrome.storage.local.get(Se))[Se];t&&typeof t.left=="number"&&typeof t.top=="number"&&(this.left=t.left,this.top=t.top,this.place())}catch{}}async save(){try{if(typeof chrome>"u"||!chrome.storage?.local)return;await chrome.storage.local.set({[Se]:{left:this.left,top:this.top}})}catch{}}};var Vi="pp-panel-pos",Ui='<svg width="10" height="16" viewBox="0 0 10 16" fill="currentColor" aria-hidden="true"><circle cx="2.5" cy="3" r="1.3"/><circle cx="7.5" cy="3" r="1.3"/><circle cx="2.5" cy="8" r="1.3"/><circle cx="7.5" cy="8" r="1.3"/><circle cx="2.5" cy="13" r="1.3"/><circle cx="7.5" cy="13" r="1.3"/></svg>',Gi=[{id:"styles",label:"Styles"},{id:"figma",label:"Figma"},{id:"assets",label:"Assets"},{id:"system",label:"Design System"},{id:"export",label:"Export"}],Et=o=>`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${o}</svg>`,Te={inspect:Et('<path d="M4 4l7 17 2.5-7.5L21 11z"/>'),device:Et('<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>'),saved:Et('<path d="M6 3h12v18l-6-4-6 4z"/>'),account:Et('<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>'),close:Et('<path d="M18 6L6 18M6 6l12 12"/>')},Jt=class{constructor(t,e,n){this.backend=e;this.callbacks=n;this.anchor=null;this.toastTimer=0;this.alive=!0;this.s={capture:null,scan:null,scanning:!1,scanError:null,system:null,components:null,componentsLoading:!1,failingOnly:!1,guidesOn:!1,assets:[],assetsLoading:!1,assetStatus:{text:"",tone:""},busy:!1,figma:null,figmaStatus:{text:"",tone:""},exportFormat:"css",clone:null,cloneStatus:"",saved:[],deviceQuery:"",deviceOpen:"phones",cards:{}};this.tab="styles";this.mode="main";this.inspecting=!0;this.lastDock="colors";this.pos=null;this.onWindowResize=()=>{this.pos&&this.movePanel(this.pos,!1)};this.el=document.createElement("div"),this.el.className="pp-ov",this.el.innerHTML=`
      <div class="pp-ov-nav" data-pp-nav></div>
      <div class="pp-ov-body" data-pp-body></div>
      <div class="pp-ov-foot" data-pp-foot></div>
      <div class="pp-toast" data-pp-toast></div>
    `,this.nav=this.el.querySelector("[data-pp-nav]"),this.body=this.el.querySelector("[data-pp-body]"),this.foot=this.el.querySelector("[data-pp-foot]"),this.toastEl=this.el.querySelector("[data-pp-toast]"),this.el.addEventListener("click",i=>this.onClick(i)),this.el.addEventListener("input",i=>this.onInput(i)),this.el.addEventListener("pointerdown",i=>this.startPanelDrag(i)),this.el.addEventListener("dblclick",i=>{i.target.closest(".pp-ov-tools")&&!i.target.closest("button")&&this.movePanel(null)}),window.addEventListener("resize",this.onWindowResize);for(let i of["click","dblclick","mousedown","mouseup","pointerdown","pointerup","contextmenu"])this.el.addEventListener(i,r=>r.stopPropagation());this.pill=document.createElement("button"),this.pill.className="pp-exit-pill",this.pill.innerHTML=`${Te.close}<span>Stop inspecting</span><kbd>Esc</kbd>`,this.pill.addEventListener("click",()=>this.callbacks.onExit());for(let i of["click","dblclick","mousedown","mouseup","pointerdown","pointerup","contextmenu"])this.pill.addEventListener(i,r=>r.stopPropagation());this.dock=null,t.append(this.pill,this.el),this.tools=new Xt(t,{onTool:i=>this.onPillTool(i)}),this.render(),this.loadForTab()}destroy(){this.alive=!1,window.removeEventListener("resize",this.onWindowResize),clearTimeout(this.toastTimer),this.el.remove(),this.pill.remove(),this.tools.destroy(),this.dock?.destroy()}setCapture(t){this.s.capture=t,this.s.figma=null,this.s.figmaStatus={text:"",tone:""},t&&(this.mode="main",(this.tab==="assets"||this.tab==="system")&&(this.tab="styles")),this.render(),this.tab==="assets"&&this.mode==="main"&&this.refreshAssets()}setInspecting(t){this.inspecting=t,this.render()}get collapsed(){return this.inspecting&&!this.s.capture&&this.mode==="main"}goTo(t){if(t==="inspect"){this.inspecting=!0,this.callbacks.onInspectToggle(!0),this.mode="main",this.anchor=null,this.render();return}if(this.inspecting&&!this.s.capture&&(this.inspecting=!1,this.callbacks.onInspectToggle(!1)),this.anchor=null,t==="saved"){this.mode="saved",this.loadSaved(),this.render();return}let e={figma:["figma",null],colors:["styles","colors"],fonts:["styles","typography"],assets:["assets",null],system:["system",null],clone:["export","clone"]},[n,i]=e[t];this.tab=n,this.mode="main",this.anchor=i,i&&(this.s.cards[`${n}:${i}`]=!0),this.lastDock=t,this.render(),this.loadForTab()}dockActive(){if(this.mode==="saved")return"saved";if(this.collapsed)return"inspect";if(this.mode!=="main")return null;switch(this.tab){case"figma":return"figma";case"assets":return"assets";case"system":return"system";case"export":return this.lastDock==="clone"?"clone":null;default:return this.s.capture?null:this.lastDock==="fonts"?"fonts":"colors"}}get isInspecting(){return this.inspecting}async ensureScan(t=!1){if(!(this.s.scanning||this.s.scan&&!t)){this.s.scanning=!0,this.s.scanError=null,this.render();try{this.s.scan=await this.backend.scan(),this.s.system=wo(this.s.scan)}catch(e){console.error("[PixelPeek] Could not scan this page",e),this.s.scanError=e instanceof Error?e.message:String(e)}finally{this.s.scanning=!1,this.alive&&this.render()}}}async loadComponents(){if(!(this.s.componentsLoading||this.s.components)){this.s.componentsLoading=!0,this.render();try{await new Promise(t=>setTimeout(t,30)),this.s.components=await this.backend.scanComponents()}catch(t){console.error("[PixelPeek] Could not scan components",t),this.s.components=[]}this.s.componentsLoading=!1,this.alive&&this.render()}}async refreshAssets(){this.s.assetStatus={text:"",tone:""},this.s.assetsLoading=!0,this.render();try{this.s.assets=await this.backend.collectAssets()}catch(t){console.error("[PixelPeek] Could not collect assets",t),this.s.assets=[],this.s.assetStatus={text:t instanceof Error?t.message:"Could not read the assets on this page.",tone:"warn"}}this.s.assetsLoading=!1,this.alive&&this.render()}async loadSaved(){this.s.saved=await Co(),this.alive&&this.render()}loadForTab(){this.mode==="saved"&&this.loadSaved(),this.mode==="main"&&(this.tab==="assets"&&this.refreshAssets(),this.tab==="styles"&&!this.s.capture&&this.ensureScan(),this.tab==="system"&&(this.ensureScan(),this.loadComponents()),this.tab==="export"&&this.ensureScan())}toast(t){this.toastEl.textContent=t,this.toastEl.classList.add("pp-toast-on"),clearTimeout(this.toastTimer),this.toastTimer=window.setTimeout(()=>this.toastEl.classList.remove("pp-toast-on"),1500)}async copy(t,e="Copied"){if(t)try{await wt(t),this.toast(e)}catch{this.toast("Could not copy")}}onInput(t){let e=t.target;if(!e.matches("[data-pp-device-search]"))return;this.s.deviceQuery=e.value,this.renderBody();let n=this.body.querySelector("[data-pp-device-search]");n?.focus(),n?.setSelectionRange(n.value.length,n.value.length)}onClick(t){let n=t.target.closest("[data-pp-act], [data-pp-tab], [data-pp-top-btn], [data-pp-panel-tool]");if(!n)return;let i=n.dataset.ppPanelTool;if(i){this.onPillTool(i);return}let r=n.dataset.ppTopBtn;if(r){this.onTopButton(r);return}if(n.dataset.ppTab){this.setTab(n.dataset.ppTab);return}let s=n.dataset.ppValue??"";switch(n.dataset.ppAct){case"tab":this.setTab(s);return;case"deselect":this.callbacks.onDeselect();return;case"card":this.s.cards[s]=n.getAttribute("aria-expanded")!=="true",this.render();return;case"copy":this.copy(n.dataset.ppCopy);return;case"rescan":this.tab==="assets"?this.refreshAssets():(this.s.components=null,this.ensureScan(!0),this.tab==="system"&&this.loadComponents());return;case"failing":this.s.failingOnly=!this.s.failingOnly,this.render();return;case"guides":this.s.guidesOn=!this.s.guidesOn,this.callbacks.onGuides(this.s.guidesOn),this.render();return;case"asset-dl":this.downloadOne(s);return;case"assets-zip":this.downloadZip(s);return;case"export-format":this.s.exportFormat=s,this.render();return;case"export-download":{let p=this.currentExport();p&&Bt(p.text,p.filename,p.mime);return}case"export-copy":this.copy(this.currentExport()?.text);return;case"clone-run":this.runClone();return;case"figma-run":this.runFigma(()=>this.backend.buildFigma(s),s==="page"?"the whole page":"the visible area");return;case"figma-element":this.runFigma(()=>this.callbacks.onFigmaElement(),"the element");return;case"figma-copy-pending":this.copyFigma();return;case"save-element":this.s.capture&&this.callbacks.onSaveElement(this.s.capture).then(()=>this.loadSaved()).then(()=>this.toast("Saved")).catch(()=>this.toast("Could not save"));return;case"saved-css":case"saved-tailwind":{let p=this.s.saved.find(a=>a.id===s);p&&this.copy(n.dataset.ppAct==="saved-css"?p.css.join(`
`):p.tailwind.join(" "));return}case"saved-remove":Eo(s).then(()=>this.loadSaved());return;case"saved-clear":To().then(()=>this.loadSaved());return;case"device-cat":this.s.deviceOpen=this.s.deviceOpen===s?null:s,this.render();return;case"device-open":{let p=St(s);p&&this.callbacks.onOpenDevice(p);return}}}onTopButton(t){if(t==="inspect")this.inspecting=!this.inspecting,this.callbacks.onInspectToggle(this.inspecting),this.mode="main";else{let e=t;this.mode=this.mode===e?"main":e,this.mode==="saved"&&this.loadSaved()}this.render()}movePanel(t,e=!0){this.pos=t;let n=this.el.style;if(!t)n.left=n.top=n.right=n.bottom=n.height=n.maxHeight="";else{let i=this.el.offsetWidth,r=Math.min(Math.max(0,t.left),Math.max(0,window.innerWidth-i)),s=Math.min(Math.max(0,t.top),Math.max(0,window.innerHeight-80));this.pos={left:r,top:s},n.left=`${r}px`,n.top=`${s}px`,n.right="auto",n.bottom="auto",n.height=`${Math.max(240,window.innerHeight-s-12)}px`,n.maxHeight=`calc(100vh - ${s}px - 8px)`}if(e)try{typeof chrome<"u"&&chrome.storage?.local&&chrome.storage.local.set({[Vi]:this.pos})}catch{}}startPanelDrag(t){let e=t.target,n=e.closest(".pp-ov-tools");if(!n||e.closest("button")||t.button!==0)return;t.preventDefault();let i=this.el.getBoundingClientRect(),r=t.clientX,s=t.clientY;n.setPointerCapture(t.pointerId),this.el.classList.add("pp-ov-dragging");let p=l=>this.movePanel({left:i.left+l.clientX-r,top:i.top+l.clientY-s},!1),a=()=>{n.removeEventListener("pointermove",p),n.removeEventListener("pointerup",a),n.removeEventListener("pointercancel",a),n.hasPointerCapture(t.pointerId)&&n.releasePointerCapture(t.pointerId),this.el.classList.remove("pp-ov-dragging"),this.pos&&this.movePanel(this.pos)};n.addEventListener("pointermove",p),n.addEventListener("pointerup",a),n.addEventListener("pointercancel",a)}onPillTool(t){if(t!=="figma"){this.onTopButton(t);return}if(this.s.capture){this.runFigma(()=>this.callbacks.onFigmaElement(),"the element");return}this.notify("Building Figma layers\u2026"),this.callbacks.onFigmaHovered().then(e=>this.notify(e)).catch(()=>this.notify("Could not copy: try again"))}notify(t){this.collapsed?this.tools.flash(t):this.toast(t)}setTab(t){this.inspecting&&!this.s.capture&&(this.inspecting=!1,this.callbacks.onInspectToggle(!1)),this.tab=t,this.anchor=null,this.mode="main",this.render(),this.loadForTab()}currentExport(){return this.s.system?Ut(this.s.system,this.s.exportFormat):null}async downloadOne(t){let e=this.s.assets.find(n=>n.id===t);if(e){try{let n=await this.backend.downloadAsset(t);this.s.assetStatus=n?{text:`Saved ${e.filename}`,tone:"ok"}:{text:`${e.filename} is blocked by the site, so it opened in a new tab to save by hand.`,tone:"warn"}}catch(n){this.s.assetStatus={text:n instanceof Error?n.message:String(n),tone:"warn"}}this.render()}}async downloadZip(t){let e=t==="all"?this.s.assets:this.s.assets.filter(n=>n.kind===t);if(!(!e.length||this.s.busy)){this.s.busy=!0,this.s.assetStatus={text:`Preparing 0 of ${e.length}\u2026`,tone:""},this.render();try{let n=await this.backend.downloadZip(e.map(i=>i.id),(i,r)=>{this.s.assetStatus={text:`Preparing ${i} of ${r}\u2026`,tone:""},this.alive&&this.render()});this.s.assetStatus=n.saved?{text:`Saved ${n.saved} file${n.saved===1?"":"s"}${n.skipped?`; ${n.skipped} blocked by the site were left out.`:"."}`,tone:n.skipped?"warn":"ok"}:{text:"The site blocks reading these files, so nothing could be zipped. Use each file's download button.",tone:"warn"}}catch(n){this.s.assetStatus={text:n instanceof Error?n.message:String(n),tone:"warn"}}this.s.busy=!1,this.alive&&this.render()}}async runFigma(t,e){if(!this.s.busy){this.s.busy=!0,this.s.figma=null,this.s.figmaStatus={text:`Building layers for ${e}\u2026`,tone:""},this.render();try{this.s.figma=await t(),this.s.figmaStatus={text:"",tone:""},await this.copyFigma(!0)}catch(n){console.error("[PixelPeek] Could not build Figma layers",n),this.s.figmaStatus={text:n instanceof Error?n.message:String(n),tone:"warn"}}this.s.busy=!1,this.alive&&this.render()}}async copyFigma(t=!1){let e=this.s.figma;if(e){try{await wt(e.svg),this.s.figmaStatus={text:`Copied ${e.layers} layer${e.layers===1?"":"s"}. Open Figma, click the canvas and press Ctrl+V (\u2318V on Mac).`,tone:"ok"},this.toast("Copied for Figma")}catch{this.s.figmaStatus={text:t?'The layers are built. Click "Copy layers again" to put them on the clipboard.':"Could not reach the clipboard.",tone:"warn"}}this.render()}}async runClone(){if(!this.s.busy){this.s.busy=!0,this.s.clone=null,this.s.cloneStatus="Starting\u2026",this.render();try{this.s.clone=await this.backend.clone(t=>{this.s.cloneStatus=t,this.alive&&this.render()}),this.s.cloneStatus=""}catch(t){console.error("[PixelPeek] Could not clone this page",t),this.s.cloneStatus=`Could not save this page: ${t instanceof Error?t.message:String(t)}`}this.s.busy=!1,this.alive&&this.render()}}render(){this.renderTop(),this.renderBody();let t=this.s.scan?.elementCount;this.foot.innerHTML=`<span>${t?`${t} elements`:""}</span><span>Esc to exit</span>`,this.pill.style.display=this.inspecting?"inline-flex":"none",this.el.classList.toggle("pp-ov-collapsed",this.collapsed),this.tools.setState({inspect:this.inspecting,devices:this.mode==="devices",saved:this.mode==="saved"}),this.tools.setVisible(this.collapsed),this.dock?.setActive(this.dockActive())}renderTop(){let t=this.s.capture,e={inspect:this.inspecting,devices:this.mode==="devices",saved:this.mode==="saved",figma:!1},n=Ee.map(i=>`<button class="pp-ov-tool" data-pp-panel-tool="${i.id}" aria-pressed="${e[i.id]}" aria-label="${i.label}">${i.svg}</button>`).join("");this.nav.innerHTML=`
      <div class="pp-ov-tools" title="Drag to move the panel. Double-click to put it back."><span class="pp-ov-grip" aria-hidden="true">${Ui}</span>${n}</div>
      <div class="pp-ov-head">
        <div class="pp-ov-title" title="${H(t?t.domPath.join(" > "):document.title)}">${t?`<b>${H(t.selector)}</b><span>${Math.round(t.layout.boxModel.content.width)} \xD7 ${Math.round(t.layout.boxModel.content.height)}</span>`:`<b>Whole page</b><span>${H(document.title.slice(0,40))}</span>`}</div>
        <div class="pp-ov-head-btns">
          <button class="pp-close-btn" data-pp-top-btn="account" aria-pressed="${this.mode==="account"}" title="Account" aria-label="Account">${Te.account}</button>
          ${t?`<button class="pp-close-btn" data-pp-act="deselect" title="Clear selection" aria-label="Clear selection">${Te.close}</button>`:""}
        </div>
      </div>
      <div class="pp-ov-tabs" role="tablist">
        ${Gi.map(i=>`<button class="pp-ov-tab" role="tab" data-pp-tab="${i.id}" aria-selected="${this.mode==="main"&&this.tab===i.id}">${i.label}</button>`).join("")}
      </div>`}renderBody(){let t=this.body.scrollTop,e;if(this.mode==="devices")e=Yo(this.s);else if(this.mode==="saved")e=qo(this.s);else if(this.mode==="account")e=Ko();else switch(this.tab){case"styles":e=jo(this.s);break;case"figma":e=Vo(this.s);break;case"assets":e=Uo(this.s);break;case"system":e=Go(this.s);break;case"export":e=Wo(this.s);break}if(this.body.innerHTML=e,this.body.scrollTop=t,this.anchor){let n=this.body.querySelector(`[data-pp-anchor="${this.anchor}"]`);n&&(this.body.scrollTop=n.offsetTop-this.body.offsetTop-6,this.anchor=null)}}};var Ae=8e3,Wi=new Set(["SCRIPT","STYLE","NOSCRIPT","LINK","META","HEAD","TITLE","BR","WBR","TEMPLATE"]),qi=new Set(["path","circle","rect","ellipse","polygon","polyline","line","g"]);function Qt(o,t,e=1){o.set(t,(o.get(t)??0)+e)}function _t(o){return Array.from(o,([t,e])=>({value:t,count:e})).sort((t,e)=>e.count-t.count)}function Ki(o){return(o.split(",")[0]??"").trim().replace(/^["']|["']$/g,"")}function Yi(){let o=new Map,t=new Map;for(let e of Y(document).sheets){let n;try{n=e.cssRules}catch{continue}for(let i of Array.from(n)){if(!(i instanceof CSSFontFaceRule))continue;let r=i.style.getPropertyValue("font-family").trim().replace(/^["']|["']$/g,"").toLowerCase(),p=i.style.getPropertyValue("src").match(/url\(\s*["']?([^"')]+)["']?\s*\)/)?.[1];if(!(!r||!p||o.has(r)))try{o.set(r,new URL(p,e.href??document.baseURI).href)}catch{o.set(r,p)}}}for(let e of Array.from(document.querySelectorAll('link[href*="fonts.googleapis.com"], link[href*="fonts.bunny.net"], link[href*="use.typekit.net"]')))for(let n of e.href.matchAll(/[?&]family=([^&]+)/g)){let i=decodeURIComponent(n[1]).split(":")[0].replace(/\+/g," ").split("|")[0].toLowerCase();i&&t.set(i,e.href)}return{faces:o,links:t}}async function Xo(){await ht(document);let o=new Map,t=new Map,e=new Map,n=new Map,i=new Map,r=new Map,s=new Map,p=new Map,a=new WeakMap,l=(u,g)=>{let y=P(u);if(!y||y.a===0)return;let $=F(y),k=o.get($);k||(k={hex:$,count:0,text:0,background:0,border:0,icon:0},o.set($,k)),k.count++,k[g]++},c=Array.from(document.body?.querySelectorAll("*")??[]),d=c.length>Ae?c.slice(0,Ae):c,h=0;for(let u of d){if(Wi.has(u.tagName)||u.id===R)continue;let g=getComputedStyle(u);if(g.display==="none")continue;h++;let y=u instanceof SVGElement&&qi.has(u.tagName.toLowerCase());if(y)g.fill!=="none"&&l(g.fill,"icon"),g.stroke!=="none"&&l(g.stroke,"icon");else{l(g.backgroundColor,"background");for(let S of["Top","Right","Bottom","Left"])parseFloat(g.getPropertyValue(`border-${S.toLowerCase()}-width`))>0&&g.getPropertyValue(`border-${S.toLowerCase()}-style`)!=="none"&&l(g.getPropertyValue(`border-${S.toLowerCase()}-color`),"border")}g.backgroundImage.includes("gradient(")&&Qt(s,g.backgroundImage),g.boxShadow!=="none"&&Qt(r,g.boxShadow),g.borderRadius!=="0px"&&Qt(i,g.borderRadius);for(let S of["padding-top","padding-left","margin-top","margin-left","row-gap","column-gap"]){let tt=g.getPropertyValue(S);/^\d+(\.\d+)?px$/.test(tt)&&parseFloat(tt)>0&&Qt(p,tt)}if(y||!ot(u))continue;l(g.color,"text");let $=Ki(g.fontFamily),k=parseFloat(g.fontSize),I=parseInt(g.fontWeight,10)||400,N=e.get($)??{count:0,weights:new Set,sizes:new Set,headings:0};N.count++,N.weights.add(I),N.sizes.add(k),/^H[1-3]$/.test(u.tagName)&&N.headings++,e.set($,N);let G=`${$}|${k}|${I}|${g.lineHeight}|${g.letterSpacing}`,lt=u.tagName,W=n.get(G);W?(W.count++,W.tags[lt]=(W.tags[lt]??0)+1):n.set(G,{size:k,weight:I,family:$,lineHeight:g.lineHeight,letterSpacing:g.letterSpacing,count:1,tags:{[lt]:1}});let x=P(g.color);if(x&&x.a>0){let S=pe(x,It(u,a),k,I),tt=`${S.fg}|${S.bg}|${S.large}`,Fe=t.get(tt);Fe?Fe.count++:t.set(tt,{fg:S.fg,bg:S.bg,ratio:S.ratio,count:1,large:S.large,aa:S.aa,aaa:S.aaa})}}let m=Yi(),v=Array.from(e,([u,g])=>{let y=u.toLowerCase();return{family:u,count:g.count,weights:Array.from(g.weights).sort(($,k)=>$-k),sizes:Array.from(g.sizes).sort(($,k)=>$-k),source:m.faces.get(y)??m.links.get(y)??null,headings:g.headings}}).sort((u,g)=>g.count-u.count);return{url:location.href,title:document.title,elementCount:h,truncated:c.length>Ae,colors:Array.from(o.values()).sort((u,g)=>g.count-u.count),pairs:Array.from(t.values()).sort((u,g)=>g.count-u.count),fonts:v,textStyles:Array.from(n.values()).sort((u,g)=>g.count-u.count),radii:_t(i),shadows:_t(r),gradients:_t(s),spacing:_t(p),tokens:fo(),unreadableSheets:Y(document).unreadable}}var Zi=3e6,Xi=4e7,Jo=/url\(\s*(["']?)([^"')]+)\1\s*\)/g;function Ji(o){return new Promise((t,e)=>{let n=new FileReader;n.onload=()=>t(String(n.result)),n.onerror=()=>e(n.error),n.readAsDataURL(o)})}var Le=class{constructor(){this.cache=new Map;this.total=0;this.failed=0}embed(t){if(t.startsWith("data:"))return Promise.resolve(t);let e=this.cache.get(t);return e||(e=this.load(t),this.cache.set(t,e)),e}async load(t){let e=await gt(t);return e?e.size>Zi||this.total+e.size>Xi?null:(this.total+=e.size,Ji(e)):(this.failed++,null)}};function Re(o,t){if(o.startsWith("data:")||o.startsWith("#"))return null;try{return new URL(o,t).href}catch{return null}}async function te(o,t,e){let n=new Set;for(let r of o.matchAll(Jo)){let s=Re(r[2],t);s&&n.add(s)}let i=new Map;return await Promise.all(Array.from(n).map(async r=>{i.set(r,await e.embed(r)??r)})),o.replace(Jo,(r,s,p)=>{let a=Re(p,t);return a?`url("${i.get(a)??a}")`:r})}function Qo(o){try{return Array.from(o.cssRules).map(t=>t.cssText).join(`
`)}catch{return null}}async function Qi(o,t){if(t){let n=Qo(t);if(n!==null)return n}let e=await gt(o.href);return e?e.text():null}function _i(){let o=location.hostname.replace(/^www\./,"")||"page",t=location.pathname.replace(/\/+$/,"").split("/").pop()??"";return`${(t?`${o}-${t}`:o).replace(/[^\w.-]+/g,"-").slice(0,80)}.html`}async function _o(o){let t=[],e=new Le;o?.("Reading stylesheets\u2026"),await ht(document);let n=document.documentElement.cloneNode(!0);n.querySelector(`#${R}`)?.remove(),n.querySelectorAll('script, noscript, link[rel~="preload"], link[rel~="modulepreload"], link[rel~="prefetch"], meta[http-equiv="Content-Security-Policy"]').forEach(u=>u.remove()),n.querySelectorAll("*").forEach(u=>{for(let g of Array.from(u.attributes))/^on/i.test(g.name)&&u.removeAttribute(g.name)});let i=n.querySelector("head")??n.insertBefore(document.createElement("head"),n.firstChild),r=document.createElement("base");r.href=document.baseURI,i.prepend(r),o?.("Inlining styles\u2026");let s=Array.from(document.querySelectorAll('link[rel~="stylesheet"]')),p=Array.from(n.querySelectorAll('link[rel~="stylesheet"]')),a=new Map(Array.from(document.styleSheets).map(u=>[u.ownerNode,u])),l=0;await Promise.all(p.map(async(u,g)=>{let y=s[g],$=y?await Qi(y,a.get(y)):null;if($===null){u.setAttribute("href",y?.href??u.href),l++;return}let k=document.createElement("style");k.textContent=await te($,y.href,e),u.replaceWith(k)})),l&&t.push(`${l} stylesheet${l===1?"":"s"} could not be saved and still load from the live site.`);for(let u of Array.from(n.querySelectorAll("style")))u.textContent&&(u.textContent=await te(u.textContent,document.baseURI,e));for(let u of Y(document).sheets){if(u.ownerNode||u.href)continue;let g=Qo(u);if(!g)continue;let y=document.createElement("style");y.textContent=await te(g,document.baseURI,e),i.appendChild(y)}o?.("Embedding images\u2026");let c=Array.from(document.querySelectorAll("img")),d=Array.from(n.querySelectorAll("img"));n.querySelectorAll("picture source").forEach(u=>u.remove()),await Promise.all(d.map(async(u,g)=>{let y=c[g]?.currentSrc||c[g]?.src,$=y?Re(y,document.baseURI):null;u.removeAttribute("srcset"),u.removeAttribute("loading"),$&&u.setAttribute("src",await e.embed($)??$)}));for(let u of Array.from(n.querySelectorAll('[style*="url("]')))u.setAttribute("style",await te(u.getAttribute("style")??"",document.baseURI,e));let h=n.querySelectorAll("canvas").length,m=n.querySelectorAll("video").length;return h&&t.push(`${h} canvas element${h===1?"":"s"} will be blank.`),m&&t.push(`${m} video${m===1?"":"s"} still stream from the live site.`),e.failed&&t.push(`${e.failed} file${e.failed===1?"":"s"} blocked by the site were left as links to the live site.`),{html:`<!DOCTYPE html>
${`<!-- Saved with PixelPeek from ${document.URL} on ${new Date().toISOString()} -->
`}${n.outerHTML}`,filename:_i(),warnings:t}}var tr=6e3,er=6,Tt=o=>parseFloat(o)||0,or=o=>{let t=P(o);return!!t&&t.a>.05};function nr(o,t){let e=[`background:${o.backgroundColor}`,`color:${o.color}`,`border:${o.borderTopWidth} ${o.borderTopStyle==="none"?"solid":o.borderTopStyle} ${o.borderTopColor}`,`border-radius:${o.borderTopLeftRadius}`,`padding:${o.paddingTop} ${o.paddingRight} ${o.paddingBottom} ${o.paddingLeft}`,`font-family:${o.fontFamily}`,`font-size:${o.fontSize}`,`font-weight:${o.fontWeight}`,`line-height:${o.lineHeight}`,`letter-spacing:${o.letterSpacing}`];return o.boxShadow!=="none"&&e.push(`box-shadow:${o.boxShadow}`),o.textTransform!=="none"&&e.push(`text-transform:${o.textTransform}`),t==="Card"?e.push("width:100%","min-height:56px","box-sizing:border-box"):e.push("display:inline-block","box-sizing:border-box"),e.join(";")}function ir(o){let t=r=>{let s=P(r);return s&&s.a>0?F(s):""},e=(r,s,p,a)=>r===s&&s===p&&p===a?r:r===p&&s===a?`${r} ${s}`:`${r} ${s} ${p} ${a}`,n=Tt(o.borderTopWidth)>0&&o.borderTopStyle!=="none"?`${o.borderTopWidth} ${t(o.borderTopColor)}`:"";return[{label:"Fill",value:t(o.backgroundColor)},{label:"Text",value:t(o.color)},{label:"Border",value:n},{label:"Radius",value:o.borderTopLeftRadius!=="0px"?o.borderTopLeftRadius:""},{label:"Padding",value:e(o.paddingTop,o.paddingRight,o.paddingBottom,o.paddingLeft)},{label:"Font",value:`${(o.fontFamily.split(",")[0]??"").replace(/["']/g,"").trim()} ${o.fontSize}/${o.fontWeight}`},{label:"Shadow",value:o.boxShadow!=="none"?o.boxShadow:""}].filter(r=>r.value&&r.value!=="0px")}function rr(o){return[F(P(o.backgroundColor)??{r:0,g:0,b:0,a:0}),F(P(o.color)??{r:0,g:0,b:0,a:1}),o.borderTopWidth,o.borderTopColor,o.borderTopLeftRadius,o.paddingTop,o.paddingLeft,o.fontSize,o.fontWeight,o.boxShadow].join("|")}function sr(o,t,e){let n=o.tagName;if(n==="INPUT"){let a=o.type;return["button","submit","reset"].includes(a)?"Button":["hidden","checkbox","radio","range","file","color","image"].includes(a)?null:"Input"}if(n==="TEXTAREA"||n==="SELECT")return"Input";if(e.width<8||e.height<8)return null;let i=or(t.backgroundColor),r=Tt(t.borderTopWidth)>0&&t.borderTopStyle!=="none",s=Tt(t.borderTopLeftRadius),p=(o.textContent??"").trim();return n==="BUTTON"||o.getAttribute("role")==="button"||n==="A"&&(i||r)&&Tt(t.paddingLeft)>=8&&p.length>0&&p.length<40&&e.height<90?"Button":i&&p.length>0&&p.length<=24&&e.height<=36&&s>=e.height/2-1&&Tt(t.fontSize)<=14&&o.children.length<=1?"Badge":(r||t.boxShadow!=="none")&&s>=4&&i&&e.width>=140&&e.width<=720&&e.height>=60&&o.children.length>=1?"Card":null}function tn(){let o=new Map,t=Array.from(document.body?.querySelectorAll("*")??[]).slice(0,tr);for(let n of t){if(n.id===R||n.closest(`#${R}`)||n instanceof SVGElement)continue;let i=getComputedStyle(n);if(i.display==="none"||i.visibility==="hidden")continue;let r=n.getBoundingClientRect(),s=sr(n,i,r);if(!s)continue;let p=rr(i),a=o.get(s);a||o.set(s,a=new Map);let l=a.get(p);if(l){l.count++;continue}let c=(n.textContent??"").trim().replace(/\s+/g," ");a.set(p,{count:1,label:s==="Input"?n.placeholder||n.type||"Input":c.slice(0,24)||s,tailwind:Ft(n,i).filter(d=>!/^(w|h)-/.test(d)),previewStyle:nr(i,s),size:`${Math.round(r.width)} \xD7 ${Math.round(r.height)}`,details:ir(i)})}return["Button","Input","Card","Badge"].filter(n=>o.has(n)).map(n=>({kind:n,variants:Array.from(o.get(n).values()).sort((i,r)=>r.count-i.count).slice(0,er)}))}var Pe=4e3,Ie=2e4,ar=15e5,pr=14e6,lr=new Set(["SCRIPT","STYLE","NOSCRIPT","LINK","META","HEAD","TITLE","TEMPLATE","BR","WBR","SOURCE","TRACK"]),en=new Set(["hidden","auto","scroll","clip"]),B=o=>o.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"),C=o=>parseFloat(o)||0,b=o=>String(Math.round(o*100)/100),Mt;function on(o){if(Mt===void 0&&(Mt=document.createElement("canvas").getContext("2d")),!Mt)return{ascent:0,height:0};Mt.font=o;let t=Mt.measureText("Mg");return{ascent:t.fontBoundingBoxAscent,height:t.fontBoundingBoxAscent+t.fontBoundingBoxDescent}}function at(o){let t=P(o);if(!t||t.a===0)return null;let e=n=>Math.round(n).toString(16).padStart(2,"0");return{fill:`#${e(t.r)}${e(t.g)}${e(t.b)}`,opacity:t.a}}var ft=(o,t="fill")=>{let e=at(o);return e?`${t}="${e.fill}"${e.opacity<1?` ${t}-opacity="${b(e.opacity)}"`:""}`:`${t}="none"`};function cr(o,t,e,n,i,r,s,p){let a=l=>Math.max(0,Math.min(l,e/2,n/2));return[i,r,s,p]=[a(i),a(r),a(s),a(p)],[`M${b(o+i)} ${b(t)}`,`H${b(o+e-r)}`,r?`A${b(r)} ${b(r)} 0 0 1 ${b(o+e)} ${b(t+r)}`:"",`V${b(t+n-s)}`,s?`A${b(s)} ${b(s)} 0 0 1 ${b(o+e-s)} ${b(t+n)}`:"",`H${b(o+p)}`,p?`A${b(p)} ${b(p)} 0 0 1 ${b(o)} ${b(t+n-p)}`:"",`V${b(t+i)}`,i?`A${b(i)} ${b(i)} 0 0 1 ${b(o+i)} ${b(t)}`:"","Z"].join("")}function ee(o,t){return o.endsWith("%")?C(o)/100*t:C(o)}function At(o,t,e=0){let n=o.x+e,i=o.y+e,r=Math.max(0,o.w-e*2),s=Math.max(0,o.h-e*2),p=o.r.map(a=>Math.max(0,a-e));return p.every(a=>a===p[0])?`<rect x="${b(n)}" y="${b(i)}" width="${b(r)}" height="${b(s)}"${p[0]?` rx="${b(Math.min(p[0],r/2,s/2))}"`:""} ${t}/>`:`<path d="${cr(n,i,r,s,p[0],p[1],p[2],p[3])}" ${t}/>`}var ze=class{constructor(t,e,n){this.ox=t;this.oy=e;this.bounds=n;this.defs=[];this.layers=0;this.elements=0;this.warnings=new Set;this.ids=0;this.images=[];this.imageBytes=0;this.skippedImages=0;this.transformed=0}id(t){return`${t}${this.ids++}`}imageToken(t){let e=`@@IMG${this.images.length}@@`;return this.images.push({token:e,url:t}),e}async resolveImages(t){let e=new Map,n=async r=>{if(r.startsWith("data:"))return r;let s=await gt(r);return!s||s.size>ar||this.imageBytes+s.size>pr?null:(this.imageBytes+=s.size,new Promise(p=>{let a=new FileReader;a.onload=()=>p(String(a.result)),a.onerror=()=>p(null),a.readAsDataURL(s)}))};await Promise.all(this.images.map(async({url:r})=>{e.has(r)||e.set(r,await n(r))}));let i=t;for(let{token:r,url:s}of this.images){let p=e.get(s);p||this.skippedImages++,i=i.replace(r,p??s)}return i}shadowFilter(t,e){let n=e.filter(a=>a.type==="Drop"&&at(a.color));if(e.some(a=>a.type==="Inner")&&this.warnings.add("Inner shadows are not copied."),!n.length)return null;let i=this.id("shadow"),r=0;for(let a of n)r=Math.max(r,Math.abs(C(a.x))+Math.abs(C(a.y))+C(a.blur)*2+Math.abs(C(a.spread)));let s='<feFlood flood-opacity="0" result="BackgroundImageFix"/>',p="BackgroundImageFix";return n.forEach((a,l)=>{let c=at(a.color),d=[1,3,5].map(h=>(parseInt(c.fill.slice(h,h+2),16)/255).toFixed(3));s+=`<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/><feOffset dx="${b(C(a.x))}" dy="${b(C(a.y))}"/><feGaussianBlur stdDeviation="${b(C(a.blur)/2)}"/><feComposite in2="hardAlpha" operator="out"/><feColorMatrix type="matrix" values="0 0 0 0 ${d[0]} 0 0 0 0 ${d[1]} 0 0 0 0 ${d[2]} 0 0 0 ${b(c.opacity)} 0"/><feBlend mode="normal" in2="${p}" result="effect${l+1}"/>`,p=`effect${l+1}`}),s+=`<feBlend mode="normal" in="SourceGraphic" in2="${p}" result="shape"/>`,this.defs.push(`<filter id="${i}" x="${b(t.x-r)}" y="${b(t.y-r)}" width="${b(t.w+r*2)}" height="${b(t.h+r*2)}" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">${s}</filter>`),i}gradientFill(t,e){if(t.type==="Other"||t.stops.length<2)return null;let n=this.id("grad"),i=t.stops.length,r=1,s;if(t.type==="Linear"){let l=C(t.angle??"180")*Math.PI/180,c=Math.sin(l),d=-Math.cos(l);r=Math.abs(e.w*c)+Math.abs(e.h*d)||1;let h=e.x+e.w/2,m=e.y+e.h/2;s=`<linearGradient id="${n}" gradientUnits="userSpaceOnUse" x1="${b(h-c*r/2)}" y1="${b(m-d*r/2)}" x2="${b(h+c*r/2)}" y2="${b(m+d*r/2)}">`}else r=Math.max(e.w,e.h)||1,s=`<radialGradient id="${n}" gradientUnits="userSpaceOnUse" cx="${b(e.x+e.w/2)}" cy="${b(e.y+e.h/2)}" r="${b(r/2)}">`;let p=t.stops.map((a,l)=>{let c=at(a.color),d=i===1?0:l/(i-1);return a.position&&(d=a.position.endsWith("%")?C(a.position)/100:C(a.position)/(t.type==="Linear"?r:r/2)),`<stop offset="${b(Math.max(0,Math.min(1,d)))}" stop-color="${c?.fill??"#000000"}"${c&&c.opacity<1?` stop-opacity="${b(c.opacity)}"`:""}/>`}).join("");return this.defs.push(`${s}${p}</${t.type==="Linear"?"linearGradient":"radialGradient"}>`),n}clip(t){let e=this.id("clip");return this.defs.push(`<clipPath id="${e}">${At(t,"")}</clipPath>`),e}image(t,e,n,i){this.layers++;let r=n==="cover"?"xMidYMid slice":n==="fill"||n==="stretch"?"none":"xMidYMid meet",s=e.r.some(Boolean)||n==="cover"?` clip-path="url(#${this.clip(e)})"`:"";return`<image id="${B(i)}" x="${b(e.x)}" y="${b(e.y)}" width="${b(e.w)}" height="${b(e.h)}" preserveAspectRatio="${r}" href="${this.imageToken(t)}"${s}/>`}placeholder(t,e,n){return this.warnings.add(n),this.layers++,At(t,`id="${B(e)}" fill="#E5E7EB"`)}text(t,e){let n=[],i=C(e.fontSize),r=e.fontWeight,s=e.fontFamily,{ascent:p}=on(`${e.fontStyle==="italic"?"italic ":""}${r} ${i}px ${s}`),a=`font-family="${B(s.replace(/"/g,"'"))}" font-size="${b(i)}" font-weight="${r}"${e.fontStyle==="italic"?' font-style="italic"':""}${e.letterSpacing!=="normal"?` letter-spacing="${b(C(e.letterSpacing))}"`:""}${e.textDecorationLine!=="none"?` text-decoration="${B(e.textDecorationLine)}"`:""} ${ft(e.color)}`,l=c=>e.textTransform==="uppercase"?c.toUpperCase():e.textTransform==="lowercase"?c.toLowerCase():e.textTransform==="capitalize"?c.replace(/\b(\w)/g,d=>d.toUpperCase()):c;for(let c of Array.from(t.childNodes)){if(c.nodeType!==Node.TEXT_NODE||!c.textContent?.trim())continue;let d=c.textContent,h=[],m=document.createRange();for(let v of d.matchAll(/\S+/g)){let u=v.index??0;m.setStart(c,u),m.setEnd(c,u+v[0].length);let g=m.getClientRects()[0];if(!g||!g.width&&!g.height)continue;let y=h[h.length-1];y&&Math.abs(y.top-g.top)<Math.max(3,i*.4)?y.words.push(v[0]):h.push({top:g.top,left:g.left,words:[v[0]]})}for(let v of h){let u=l(v.words.join(" "));this.layers++,n.push(`<text id="${B(u.slice(0,40))}" x="${b(v.left-this.ox)}" y="${b(v.top-this.oy+p)}" ${a} xml:space="preserve">${B(u)}</text>`)}}return n.join("")}inlineSvg(t,e,n,i){let r=t.cloneNode(!0);r.setAttribute("xmlns","http://www.w3.org/2000/svg"),r.setAttribute("width",b(e.w)),r.setAttribute("height",b(e.h)),r.getAttribute("viewBox")||r.setAttribute("viewBox",`0 0 ${b(e.w)} ${b(e.h)}`),r.removeAttribute("class"),r.removeAttribute("style");let s=new Set;for(let a of Array.from(r.querySelectorAll("use"))){let l=a.getAttribute("href")??a.getAttribute("xlink:href");l?.startsWith("#")&&s.add(l.slice(1))}if(s.size){let a=document.createElementNS("http://www.w3.org/2000/svg","defs");for(let l of s){let c=document.getElementById(l);c&&a.appendChild(c.cloneNode(!0))}r.insertBefore(a,r.firstChild)}let p=new XMLSerializer().serializeToString(r).replace(/currentColor/g,n);return this.layers++,`<g id="${B(i)}" transform="translate(${b(e.x)} ${b(e.y)})">${p}</g>`}draw(t){if(lr.has(t.tagName)||t.id===R||this.elements>=Pe)return this.elements>=Pe&&this.warnings.add(`Only the first ${Pe} elements were copied.`),"";this.elements++;let e=getComputedStyle(t);if(e.display==="none"||e.visibility==="hidden"&&!t.children.length)return"";let n=parseFloat(e.opacity);if(n===0)return"";let i=t.getBoundingClientRect(),r={x:i.left-this.ox,y:i.top-this.oy,w:i.width,h:i.height,r:[ee(e.borderTopLeftRadius,i.width),ee(e.borderTopRightRadius,i.width),ee(e.borderBottomRightRadius,i.width),ee(e.borderBottomLeftRadius,i.width)]};e.transform!=="none"&&this.transformed++;let s=!this.bounds||r.x<this.bounds.w&&r.y<this.bounds.h&&r.x+r.w>0&&r.y+r.h>0,p=nn(t),a=[];if(s&&r.w>0&&r.h>0&&e.visibility!=="hidden"){let u=at(e.backgroundColor),g=ct(e.boxShadow),y=u?this.shadowFilter(r,g):null;!u&&g.length&&g.some($=>$.type==="Drop")&&this.warnings.add("Shadows on transparent boxes are not copied."),u&&(this.layers++,a.push(At(r,`id="Background" ${ft(e.backgroundColor)}${y?` filter="url(#${y})"`:""}`)));for(let $ of dt(e.backgroundImage)){let k=this.gradientFill($,r);k?(this.layers++,a.push(At(r,`id="Gradient" fill="url(#${k})"`))):$.type==="Other"&&this.warnings.add("Conic and repeating gradients are not copied.")}for(let $ of e.backgroundImage.matchAll(/url\(\s*["']?([^"')]+)["']?\s*\)/g))try{let k=new URL($[1],document.baseURI).href,I=e.backgroundSize;a.push(this.image(k,r,I.includes("cover")?"cover":I.includes("100% 100%")?"fill":"contain","Background image"))}catch{}if(a.push(...this.borders(e,r)),t instanceof HTMLImageElement){let $=t.currentSrc||t.src;if($){let k={...r,x:r.x+C(e.borderLeftWidth)+C(e.paddingLeft),y:r.y+C(e.borderTopWidth)+C(e.paddingTop),w:r.w-C(e.borderLeftWidth)-C(e.borderRightWidth)-C(e.paddingLeft)-C(e.paddingRight),h:r.h-C(e.borderTopWidth)-C(e.borderBottomWidth)-C(e.paddingTop)-C(e.paddingBottom)};a.push(this.image(new URL($,document.baseURI).href,k,e.objectFit==="cover"?"cover":e.objectFit==="fill"?"fill":"contain",p))}}else if(t instanceof SVGSVGElement)a.push(this.inlineSvg(t,r,e.color,p));else if(t instanceof HTMLCanvasElement)try{a.push(this.image(t.toDataURL(),r,"fill",p))}catch{a.push(this.placeholder(r,p,"Canvas elements that block reading were drawn as grey boxes."))}else t instanceof HTMLVideoElement?a.push(t.poster?this.image(new URL(t.poster,document.baseURI).href,r,"cover",p):this.placeholder(r,p,"Videos without a poster image were drawn as grey boxes.")):t instanceof HTMLIFrameElement?a.push(this.placeholder(r,p,"Embedded frames (iframes) were drawn as grey boxes.")):t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLSelectElement?a.push(this.formControlText(t,e,r)):a.push(this.text(t,e))}let l=t instanceof SVGSVGElement?[]:Array.from(t.children),c=u=>{let g=getComputedStyle(u);return g.position==="static"?0:parseInt(g.zIndex,10)||0},h=l.map((u,g)=>({c:u,i:g,z:c(u)})).sort((u,g)=>u.z-g.z||u.i-g.i).map(({c:u})=>this.draw(u)).join(""),m=a.filter(Boolean);if(m.length===1&&!h&&n===1)return m[0];let v=m.join("");return h&&(en.has(e.overflowX)||en.has(e.overflowY)?v+=`<g clip-path="url(#${this.clip(r)})">${h}</g>`:v+=h),v?`<g id="${B(p)}"${n<1?` opacity="${b(n)}"`:""}>${v}</g>`:""}borders(t,e){let i=["top","right","bottom","left"].map(s=>({side:s,w:t.getPropertyValue(`border-${s}-style`)==="none"?0:C(t.getPropertyValue(`border-${s}-width`)),color:t.getPropertyValue(`border-${s}-color`),dash:t.getPropertyValue(`border-${s}-style`)})).filter(s=>s.w>0&&at(s.color));if(!i.length)return[];if(i.length===4&&i.every(s=>s.w===i[0].w&&s.color===i[0].color)){let s=i[0].w,p=i[0].dash==="dashed"?` stroke-dasharray="${b(s*3)} ${b(s*3)}"`:i[0].dash==="dotted"?` stroke-dasharray="${b(s)} ${b(s)}"`:"";return this.layers++,[At(e,`id="Border" fill="none" ${ft(i[0].color,"stroke")} stroke-width="${b(s)}"${p}`,s/2)]}return i.map(s=>{this.layers++;let[p,a,l,c]=s.side==="top"?[e.x,e.y,e.w,s.w]:s.side==="bottom"?[e.x,e.y+e.h-s.w,e.w,s.w]:s.side==="left"?[e.x,e.y,s.w,e.h]:[e.x+e.w-s.w,e.y,s.w,e.h];return`<rect id="Border ${s.side}" x="${b(p)}" y="${b(a)}" width="${b(l)}" height="${b(c)}" ${ft(s.color)}/>`})}formControlText(t,e,n){let i="",r=e.color;if(t instanceof HTMLSelectElement)i=t.selectedOptions[0]?.textContent?.trim()??"";else{if(t instanceof HTMLInputElement&&["checkbox","radio","range","file","color","hidden"].includes(t.type))return"";i=t.value,!i&&t.placeholder&&(i=t.placeholder,r="rgba(0,0,0,0.4)")}if(!i)return"";let s=C(e.fontSize),{ascent:p,height:a}=on(`${e.fontWeight} ${s}px ${e.fontFamily}`);this.layers++;let l=n.y+n.h/2-a/2+p;return`<text id="${B(i.slice(0,40))}" x="${b(n.x+C(e.borderLeftWidth)+C(e.paddingLeft))}" y="${b(l)}" font-family="${B(e.fontFamily.replace(/"/g,"'"))}" font-size="${b(s)}" font-weight="${e.fontWeight}" ${ft(r)} xml:space="preserve">${B(i)}</text>`}};function nn(o){let t=o.tagName.toLowerCase();if(o.id)return`${t}#${o.id}`;let e=Array.from(o.classList).find(n=>/^[a-z][\w-]{2,}$/i.test(n));return e?`${t}.${e}`:t}async function bt(o,t){let e=0,n=0,i,r,s=null,p,a="";if(t==="element"){let m=o.getBoundingClientRect();e=m.left,n=m.top,i=m.width,r=m.height,p=nn(o)}else{o=document.body;let m=document.documentElement;t==="page"?(e=-window.scrollX,n=-window.scrollY,i=Math.max(m.scrollWidth,window.innerWidth),r=Math.min(Math.max(m.scrollHeight,window.innerHeight),Ie)):(i=window.innerWidth,r=window.innerHeight,s={w:i,h:r}),p=document.title.slice(0,60)||location.hostname;let v=[getComputedStyle(m).backgroundColor,getComputedStyle(document.body).backgroundColor].find(u=>at(u))??"#ffffff";a=`<rect id="Page background" width="${b(i)}" height="${b(r)}" ${ft(v)}/>`}let l=new ze(e,n,s);a&&l.layers++;let c=l.draw(o),d=`<svg xmlns="http://www.w3.org/2000/svg" width="${b(i)}" height="${b(r)}" viewBox="0 0 ${b(i)} ${b(r)}" fill="none">${t==="element"?c:`<g id="${B(p)}">${a}${c}</g>`}${l.defs.length?`<defs>${l.defs.join("")}</defs>`:""}</svg>`;d=await l.resolveImages(d);let h=Array.from(l.warnings);return l.skippedImages&&h.push(`${l.skippedImages} image${l.skippedImages===1?" was":"s were"} too large or blocked by the site, so Figma will show them empty.`),l.transformed&&h.push(`${l.transformed} rotated or scaled element${l.transformed===1?" was":"s were"} drawn upright at ${l.transformed===1?"its":"their"} final size and position.`),t==="page"&&document.documentElement.scrollHeight>Ie&&h.push(`The page is taller than ${Ie}px, so the bottom was cut off.`),{svg:d,layers:l.layers,width:i,height:r,warnings:h}}var oe=class{constructor(t=()=>null){this.getLocked=t;this.assets=new Map}scan(){return Xo()}async collectAssets(){let t=this.getLocked(),e=Po(t?t.closest("svg")??t:void 0);return this.assets=new Map(e.map(n=>[n.id,n])),e}async downloadAsset(t){let e=this.assets.get(t);return e?lo(e):!1}async scanComponents(){return tn()}downloadZip(t,e){let n=t.map(r=>this.assets.get(r)).filter(r=>!!r),i=location.hostname.replace(/^www\./,"")||"page";return co(n,`${i}-assets.zip`,e)}async buildFigma(t){let e=this.getLocked();if(t==="element"){if(!e)throw new Error("Lock an element first.");return bt(e,"element")}return bt(document.body,t)}async clone(t){let e=await _o(t);return Bt(e.html,e.filename,"text/html"),{filename:e.filename,sizeMb:e.html.length/1024/1024,warnings:e.warnings}}};var rn=["click","dblclick","auxclick","contextmenu","mousedown","pointerdown","touchstart","touchend","submit","dragstart","mouseover","mouseout","mouseenter","mouseleave","pointerover","pointerout","pointerenter","pointerleave"],sn=["mousemove","pointermove","mouseup","pointerup"];function an(o){return o.target?.id===R}var ne=class{constructor(){this.blockHard=t=>{an(t)||(t.cancelable&&t.preventDefault(),t.stopImmediatePropagation())};this.blockSoft=t=>{an(t)||t.stopPropagation()};for(let t of rn)window.addEventListener(t,this.blockHard,{capture:!0});for(let t of sn)window.addEventListener(t,this.blockSoft,{capture:!0})}destroy(){for(let t of rn)window.removeEventListener(t,this.blockHard,{capture:!0});for(let t of sn)window.removeEventListener(t,this.blockSoft,{capture:!0})}};var dr={island:{top:14,right:14,bottom:14,left:14,radius:62},notch:{top:14,right:14,bottom:14,left:14,radius:52},punch:{top:14,right:14,bottom:14,left:14,radius:44},fold:{top:14,right:14,bottom:14,left:14,radius:34},home:{top:66,right:16,bottom:82,left:16,radius:46},tablet:{top:24,right:24,bottom:24,left:24,radius:36},laptop:{top:18,right:18,bottom:18,left:18,radius:20},monitor:{top:16,right:16,bottom:52,left:16,radius:18},watch:{top:22,right:22,bottom:22,left:22,radius:64},plain:{top:2,right:2,bottom:2,left:2,radius:12}},ur=[320,375,414,768,1024,1280,1440],ie=class{constructor(t,e){this.device=null;this.width=0;this.height=0;this.landscape=!1;this.onResize=()=>this.layout();this.callbacks=e,this.el=document.createElement("div"),this.el.className="pp-dp",this.el.style.display="none",this.el.addEventListener("click",n=>this.onClick(n)),this.el.addEventListener("input",n=>this.onInput(n));for(let n of["click","dblclick","mousedown","mouseup","pointerdown","pointerup","contextmenu","keydown","keyup"])this.el.addEventListener(n,i=>i.stopPropagation());t.appendChild(this.el)}get isOpen(){return this.device!==null}open(t){this.device=t,this.landscape=!1,this.width=t.width,this.height=t.height,this.el.style.display="flex",this.render(),window.addEventListener("resize",this.onResize)}close(){this.device&&(this.device=null,this.el.style.display="none",this.el.innerHTML="",window.removeEventListener("resize",this.onResize))}destroy(){this.close(),this.el.remove()}screen(){return this.landscape?{w:this.height,h:this.width}:{w:this.width,h:this.height}}render(){let t=this.device;if(!t)return;let e=t.category==="responsive",{w:n,h:i}=this.screen(),r=t.frame;this.el.innerHTML=`
      <div class="pp-dp-bar">
        <div class="pp-dp-title"><b>${H(t.name)}</b><span>${e?"":`${n} \xD7 ${i}`}</span></div>
        ${e?`
          <div class="pp-dp-size">
            <input type="number" min="200" max="3000" value="${n}" data-pp-dp-w aria-label="Width"> \xD7
            <input type="number" min="200" max="3000" value="${i}" data-pp-dp-h aria-label="Height">
          </div>
          <div class="pp-dp-presets">${ur.map(s=>`<button class="pp-chip" data-pp-dp-preset="${s}">${s}</button>`).join("")}</div>`:""}
        <span class="pp-dp-scale" data-pp-dp-scale></span>
        <button class="pp-btn" data-pp-dp-rotate title="Rotate">Rotate</button>
        <button class="pp-btn" data-pp-dp-reload title="Reload the preview">Reload</button>
        <button class="pp-btn" data-pp-dp-close>Close <kbd>Esc</kbd></button>
      </div>
      <div class="pp-dp-stage" data-pp-dp-stage>
        <div class="pp-dev pp-dev-${r}${this.landscape?" pp-landscape":""}" data-pp-dp-dev>
          <div class="pp-dev-screen">
            <iframe class="pp-dp-frame" data-pp-dp-iframe title="Preview of this page" referrerpolicy="same-origin"></iframe>
            <div class="pp-dp-blocked" data-pp-dp-blocked hidden>
              <b>This site cannot be shown inside a frame</b>
              <p>It sends headers that stop other pages (including this preview) from framing it. Open a real browser window at this size instead.</p>
              <button class="pp-btn pp-btn-primary" data-pp-dp-window>Open a ${n} \xD7 ${i} window</button>
            </div>
          </div>
          <span class="pp-dev-deco pp-dev-a"></span><span class="pp-dev-deco pp-dev-b"></span><span class="pp-dev-deco pp-dev-c"></span>
        </div>
      </div>
    `,this.layout(),this.loadFrame()}loadFrame(){let t=this.el.querySelector("[data-pp-dp-iframe]"),e=this.el.querySelector("[data-pp-dp-blocked]");!t||!e||(t.addEventListener("load",()=>{let n=!1;try{n=!!t.contentDocument?.body}catch{n=!1}e.hidden=n}),t.src=location.href)}layout(){let t=this.device,e=this.el.querySelector("[data-pp-dp-stage]"),n=this.el.querySelector("[data-pp-dp-dev]");if(!t||!e||!n)return;let{w:i,h:r}=this.screen(),s=dr[t.frame],p=this.landscape&&t.category!=="tablets"?{top:s.left,right:s.bottom,bottom:s.right,left:s.top,radius:s.radius}:s,a=i+p.left+p.right,l=r+p.top+p.bottom,c=t.frame==="laptop"?28:t.frame==="monitor"?64:t.frame==="watch"?80:0,d=Math.min(1,(e.clientWidth-48)/a,(e.clientHeight-24)/(l+c*2));n.style.cssText=`--sw:${i}px;--sh:${r}px;--bt:${p.top}px;--br:${p.right}px;--bb:${p.bottom}px;--bl:${p.left}px;--r:${p.radius}px;width:${a}px;height:${l}px;transform:scale(${d});`,n.parentElement.style.setProperty("--fit-w",`${a*d}px`),n.parentElement.style.setProperty("--fit-h",`${(l+c*2)*d}px`);let h=this.el.querySelector("[data-pp-dp-scale]");h&&(h.textContent=`${Math.round(d*100)}%`)}onInput(t){let e=t.target;if(e.matches("[data-pp-dp-w]"))this.width=Math.max(200,Math.min(3e3,parseInt(e.value,10)||this.width));else if(e.matches("[data-pp-dp-h]"))this.height=Math.max(200,Math.min(3e3,parseInt(e.value,10)||this.height));else return;this.layout()}onClick(t){let e=t.target;if(e.closest("[data-pp-dp-close]"))this.close(),this.callbacks.onClose();else if(e.closest("[data-pp-dp-rotate]"))this.landscape=!this.landscape,this.render();else if(e.closest("[data-pp-dp-reload]"))this.loadFrame();else if(e.closest("[data-pp-dp-window]")){let{w:n,h:i}=this.screen();this.callbacks.onOpenWindow(n,i)}else{let n=e.closest("[data-pp-dp-preset]")?.dataset.ppDpPreset;n&&(this.width=parseInt(n,10),this.render())}}};var O=o=>parseFloat(o)||0,re=class{constructor(t){this.target=null;this.raf=0;this.onMove=()=>{cancelAnimationFrame(this.raf),this.raf=requestAnimationFrame(()=>this.draw())};this.layer=document.createElement("div"),this.layer.className="pp-guides",this.layer.style.display="none",t.appendChild(this.layer)}get isOn(){return this.target!==null}show(t){this.target=t,this.layer.style.display="block",window.addEventListener("scroll",this.onMove,!0),window.addEventListener("resize",this.onMove),this.draw()}hide(){this.target=null,this.layer.style.display="none",this.layer.innerHTML="",window.removeEventListener("scroll",this.onMove,!0),window.removeEventListener("resize",this.onMove)}destroy(){this.hide(),this.layer.remove()}draw(){let t=this.target;if(!t)return;let e=getComputedStyle(t),n=t.getBoundingClientRect(),i={t:O(e.marginTop),r:O(e.marginRight),b:O(e.marginBottom),l:O(e.marginLeft)},r={t:O(e.borderTopWidth),r:O(e.borderRightWidth),b:O(e.borderBottomWidth),l:O(e.borderLeftWidth)},s={t:O(e.paddingTop),r:O(e.paddingRight),b:O(e.paddingBottom),l:O(e.paddingLeft)},p=(d,h,m,v,u,g)=>`<div class="${d}" style="left:${h}px;top:${m}px;width:${Math.max(0,v)}px;height:${Math.max(0,u)}px;${g?`border-width:${g.t}px ${g.r}px ${g.b}px ${g.l}px;`:""}"></div>`,a=(d,h,m,v)=>d>0?`<span class="pp-guide-label ${v}" style="left:${h}px;top:${m}px">${Math.round(d*10)/10}</span>`:"",l=n.left+n.width/2,c=n.top+n.height/2;this.layer.innerHTML=p("pp-guide pp-guide-margin",n.left-i.l,n.top-i.t,n.width,n.height,i)+p("pp-guide pp-guide-padding",n.left+r.l,n.top+r.t,n.width-r.l-r.r,n.height-r.t-r.b,s)+p("pp-guide pp-guide-content",n.left+r.l+s.l,n.top+r.t+s.t,n.width-r.l-r.r-s.l-s.r,n.height-r.t-r.b-s.t-s.b)+a(i.t,l,n.top-i.t/2,"pp-guide-label-margin")+a(i.b,l,n.bottom+i.b/2,"pp-guide-label-margin")+a(i.l,n.left-i.l/2,c,"pp-guide-label-margin")+a(i.r,n.right+i.r/2,c,"pp-guide-label-margin")+a(s.t,l,n.top+r.t+s.t/2,"pp-guide-label-padding")+a(s.b,l,n.bottom-r.b-s.b/2,"pp-guide-label-padding")+a(s.l,n.left+r.l+s.l/2,c,"pp-guide-label-padding")+a(s.r,n.right-r.r-s.r/2,c,"pp-guide-label-padding")}};var pt=o=>parseFloat(o)||0,pn=16,ln="Click to select \xB7 <kbd>F</kbd> Figma \xB7 <kbd>S</kbd> Save",vt=o=>String(Math.round(o*10)/10);function hr(o){if(o.id)return`#${o.id}`;let t=Array.from(o.classList).slice(0,2).join(".");return t?`${o.tagName.toLowerCase()}.${t}`:o.tagName.toLowerCase()}var cn=(o,t,e,n)=>{let[i,r,s,p]=[pt(o),pt(t),pt(e),pt(n)];return!i&&!r&&!s&&!p?"":i===r&&r===s&&s===p?`${vt(i)}px`:`${vt(i)} ${vt(r)} ${vt(s)} ${vt(p)}`},se=class{constructor(t){this.flashTimer=0;this.el=document.createElement("div"),this.el.className="pp-hover",this.el.style.display="none",t.appendChild(this.el)}show(t){let e=getComputedStyle(t),n=t.getBoundingClientRect(),i=zt(t,e),r=v=>`<span class="pp-swatch" style="background:${H(v)}"></span>`,s=[],p=(e.fontFamily.split(",")[0]??"").replace(/["']/g,"").trim();(t.textContent??"").trim()&&(s.push(["Font",`${H(p)} \xB7 ${e.fontSize} \xB7 ${e.fontWeight}`]),s.push(["Text",`${r(e.color)}${z(e.color)}${i&&!i.onImage?` <span class="${i.aa?"pp-hv-ok":"pp-hv-bad"}">${i.ratio.toFixed(1)}:1</span>`:""}`])),e.backgroundColor!=="rgba(0, 0, 0, 0)"&&e.backgroundColor!=="transparent"&&s.push(["Fill",`${r(e.backgroundColor)}${z(e.backgroundColor)}`]);let a=cn(e.paddingTop,e.paddingRight,e.paddingBottom,e.paddingLeft),l=cn(e.marginTop,e.marginRight,e.marginBottom,e.marginLeft);a&&s.push(["Padding",a]),l&&s.push(["Margin",l]),pt(e.borderTopLeftRadius)&&s.push(["Radius",e.borderTopLeftRadius]),(e.display.includes("flex")||e.display.includes("grid"))&&s.push(["Layout",`${e.display}${pt(e.rowGap)?` \xB7 gap ${vt(pt(e.rowGap))}px`:""}`]),this.el.innerHTML=`
      <div class="pp-hover-head"><b>${H(hr(t))}</b><span>${Math.round(n.width)} \xD7 ${Math.round(n.height)}</span></div>
      ${s.map(([v,u])=>`<div class="pp-hover-row"><span>${v}</span><span>${u}</span></div>`).join("")}
      <div class="pp-hover-foot" data-pp-hover-foot>${ln}</div>`,this.el.style.display="block";let c=this.el.getBoundingClientRect(),d=10,h=n.bottom+d;h+c.height>window.innerHeight-pn&&(h=n.top-c.height-d),h<8&&(h=Math.min(Math.max(8,n.top+8),window.innerHeight-c.height-pn));let m=Math.max(8,Math.min(n.left,window.innerWidth-c.width-8));this.el.style.top=`${h}px`,this.el.style.left=`${m}px`}flash(t){let e=this.el.querySelector("[data-pp-hover-foot]");e&&(e.textContent=t,e.classList.add("pp-hover-flash"),clearTimeout(this.flashTimer),this.flashTimer=window.setTimeout(()=>{e.innerHTML=ln,e.classList.remove("pp-hover-flash")},1400))}hide(){this.el.style.display="none"}destroy(){this.el.remove()}};var _;function gr(){window.__pixelpeekActive=!0;let{root:o}=He(),t=null,e=null,n=!1,i=new oe(()=>t),r=new re(o),s=new se(o),p=()=>{let m=t??e;n&&m?r.show(m):r.hide()},a=new ie(o,{onOpenWindow:(m,v)=>{typeof chrome<"u"&&chrome.runtime?.id&&chrome.runtime.sendMessage({pp:"open-window",url:location.href,width:m,height:v}).catch(()=>{})},onClose:()=>{}}),l=async m=>{let v=await bt(m,"element");return await wt(v.svg),`Copied ${v.layers} layer${v.layers===1?"":"s"} \u2713`},c=new Jt(o,i,{onInspectToggle:m=>d.setEnabled(m),onDeselect:()=>d.release(),onFigmaElement:()=>t?bt(t,"element"):Promise.reject(new Error("Select an element first.")),onFigmaHovered:async()=>{let m=t??e;return m?l(m):"Hover or select an element first"},onSaveElement:async m=>{await we(m,{url:location.href,title:document.title})},onGuides:m=>{n=m,p()},onOpenDevice:m=>a.open(m),onExit:()=>d.closeExtension()}),d=new Lt(o,{onLock:m=>{t=m,s.hide(),c.setCapture(ge(m)),p()},onUnlock:()=>{t=null,c.setCapture(null),p()},onScrolling:m=>{m?s.hide():e&&!t&&s.show(e)},onHoverKey:(m,v)=>{if(m==="save"){we(ge(v),{url:location.href,title:document.title}).then(()=>s.flash("Saved \u2713")).catch(()=>s.flash("Could not save"));return}s.flash("Building Figma layers\u2026"),l(v).then(u=>s.flash(u)).catch(()=>s.flash("Could not copy: press F again"))},onHover:m=>{e=m,m&&!t?s.show(m):s.hide(),p()},onDeactivate:dn,onEscape:()=>a.isOpen?(a.close(),!0):!1});ht(document);let h=new ne;_={picker:d,overlay:c,preview:a,guides:r,hover:s,guard:h}}function dn(){window.__pixelpeekActive=!1,_&&(_.guard.destroy(),_.picker.destroy(),_.guides.destroy(),_.hover.destroy(),_.preview.destroy(),_.overlay.destroy()),_=void 0,Be()}window.__pixelpeekActive?window.__pixelpeekTeardown?.():(gr(),window.__pixelpeekTeardown=dn);})();
