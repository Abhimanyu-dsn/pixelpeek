"use strict";(()=>{var Dt=`/*\r
 * Light, Atlassian-style UI: white surfaces, a blue accent, subtle 1px borders, compact\r
 * 12-14px type, 3-6px corner radii, and a soft two-layer overlay shadow. Monospace is\r
 * reserved for CSS-like values.\r
 */\r
\r
:host {\r
  all: initial;\r
\r
  --pp-font: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;\r
  --pp-mono: ui-monospace, SFMono-Regular, Menlo, monospace;\r
\r
  --pp-blue-300: #579DFF;  /* outline fill */\r
  --pp-blue-400: #0C66E4;  /* primary accent */\r
  --pp-blue-500: #0055CC;  /* hover / pressed */\r
  --pp-blue-a12: #E9F2FF;  /* selected surface */\r
  --pp-blue-a35: #85B8FF;  /* selected border */\r
\r
  --pp-green-400: #1F845A;\r
  --pp-green-bg: #DCFFF1;\r
  --pp-red-400: #C9372C;\r
  --pp-red-bg: #FFECEB;\r
  --pp-amber-300: #A54800;\r
  --pp-amber-a15: #FFF7D6;\r
  --pp-amber-a40: #F5CD47;\r
\r
  --pp-bg: #FFFFFF;\r
  --pp-bg-subtle: #F7F8F9;\r
  --pp-bg-hover: #F1F2F4;\r
  --pp-border: #DCDFE4;\r
  --pp-border-strong: #B3B9C4;\r
  --pp-text: #172B4D;\r
  --pp-text-subtle: #44546F;\r
  --pp-text-subtlest: #626F86;\r
\r
  --pp-space-025: 2px;\r
  --pp-space-050: 4px;\r
  --pp-space-100: 8px;\r
  --pp-space-150: 12px;\r
  --pp-space-200: 16px;\r
  --pp-space-300: 24px;\r
\r
  --pp-font-size-body-small: 12px;\r
  --pp-line-height-body-small: 16px;\r
  --pp-font-size-body: 14px;\r
  --pp-line-height-body: 20px;\r
\r
  --pp-radius-small: 4px;\r
  --pp-radius: 8px;\r
\r
  --pp-shadow-overlay: 0 8px 12px rgba(9, 30, 66, 0.15), 0 0 1px rgba(9, 30, 66, 0.31);\r
}\r
\r
.pixelpeek-outline {\r
  position: fixed;\r
  pointer-events: none;\r
  border: 2px solid var(--pp-blue-400);\r
  background: rgba(12, 102, 228, 0.1);\r
  box-sizing: border-box;\r
  z-index: 1;\r
  transition: none;\r
}\r
\r
.pixelpeek-outline.locked {\r
  border-color: var(--pp-blue-500);\r
  background: rgba(12, 102, 228, 0.14);\r
}\r
\r
.pixelpeek-chip {\r
  position: fixed;\r
  pointer-events: none;\r
  background: var(--pp-bg);\r
  color: var(--pp-text);\r
  border: 1px solid var(--pp-border-strong);\r
  font: 500 var(--pp-font-size-body-small)/var(--pp-line-height-body-small) var(--pp-font);\r
  padding: var(--pp-space-025) var(--pp-space-100);\r
  border-radius: var(--pp-radius-small);\r
  z-index: 2;\r
  white-space: nowrap;\r
}\r
\r
.pixelpeek-chip.locked {\r
  background: var(--pp-blue-400);\r
  border-color: var(--pp-blue-500);\r
  color: #ffffff;\r
}\r
\r
/* The shell is placed and dragged; the card inside scrolls; the variants button hangs off the shell. */\r
\r
.pp-close-btn {\r
  flex-shrink: 0;\r
  width: 24px;\r
  height: 24px;\r
  border: none;\r
  background: none;\r
  color: var(--pp-text-subtle);\r
  font-size: 13px;\r
  line-height: 1;\r
  border-radius: var(--pp-radius-small);\r
  cursor: pointer;\r
}\r
\r
.pp-close-btn:hover {\r
  background: var(--pp-bg-hover);\r
  color: var(--pp-text);\r
}\r
\r
.pp-note {\r
  margin: 0 0 var(--pp-space-050);\r
  font-size: 11px;\r
  color: var(--pp-text-subtlest);\r
}\r
\r
.pp-dots {\r
  width: var(--pp-space-150);\r
  height: var(--pp-space-150);\r
  border: 2px solid var(--pp-blue-a35);\r
  border-top-color: var(--pp-blue-400);\r
  border-radius: 50%;\r
  animation: pp-spin 0.8s linear infinite;\r
}\r
\r
@keyframes pp-spin {\r
  to { transform: rotate(360deg); }\r
}\r
\r
.pp-swatch {\r
  display: inline-block;\r
  width: 10px;\r
  height: 10px;\r
  border-radius: var(--pp-radius-small);\r
  border: 1px solid var(--pp-border-strong);\r
}\r
\r
/* ---- Page panel (Colors, Fonts, Assets, System, Clone) ---- */\r
\r
.pp-btn {\r
  display: inline-flex;\r
  align-items: center;\r
  justify-content: center;\r
  gap: 6px;\r
  padding: 6px 12px;\r
  border: 1px solid var(--pp-border-strong);\r
  border-radius: var(--pp-radius-small);\r
  background: var(--pp-bg);\r
  color: var(--pp-text);\r
  font: inherit;\r
  font-size: 12px;\r
  font-weight: 600;\r
  cursor: pointer;\r
}\r
\r
.pp-btn:hover { background: var(--pp-bg-hover); }\r
\r
.pp-btn:disabled { opacity: 0.5; cursor: default; }\r
\r
.pp-btn-primary { background: var(--pp-blue-400); border-color: var(--pp-blue-400); color: #fff; }\r
\r
.pp-btn-primary:hover { background: var(--pp-blue-500); }\r
\r
.pp-btn-primary:disabled:hover { background: var(--pp-blue-400); }\r
\r
.pp-btn-row { display: flex; flex-wrap: wrap; gap: var(--pp-space-100); }\r
\r
.pp-chip {\r
  padding: 3px 10px;\r
  border: 1px solid var(--pp-border);\r
  border-radius: 999px;\r
  background: var(--pp-bg);\r
  color: var(--pp-text-subtle);\r
  font: inherit;\r
  font-size: 12px;\r
  cursor: pointer;\r
}\r
\r
.pp-chip:hover { background: var(--pp-bg-hover); }\r
\r
.pp-chip[aria-pressed="true"] { background: var(--pp-blue-a12); border-color: var(--pp-blue-a35); color: var(--pp-blue-400); font-weight: 600; }\r
\r
.pp-chips { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: var(--pp-space-150); }\r
\r
.pp-empty {\r
  padding: var(--pp-space-300) var(--pp-space-100);\r
  text-align: center;\r
  font-size: 12px;\r
  color: var(--pp-text-subtle);\r
}\r
\r
.pp-status { margin: var(--pp-space-100) 0 0; font-size: 12px; color: var(--pp-text-subtle); }\r
\r
.pp-status.pp-ok { color: var(--pp-green-400); }\r
\r
.pp-status.pp-warn { color: var(--pp-amber-300); }\r
\r
/* Palette */\r
\r
.pp-pair {\r
  display: flex;\r
  align-items: center;\r
  gap: var(--pp-space-100);\r
  padding: 6px 0;\r
  border-bottom: 1px solid var(--pp-border);\r
  font-size: 12px;\r
}\r
\r
.pp-pair:last-child { border-bottom: none; }\r
\r
.pp-pair-sample {\r
  flex-shrink: 0;\r
  width: 40px;\r
  height: 28px;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  border: 1px solid var(--pp-border);\r
  border-radius: var(--pp-radius-small);\r
  font-weight: 700;\r
}\r
\r
.pp-pair-info { flex: 1; min-width: 0; }\r
\r
.pp-pair-hex { font: 11px/14px var(--pp-mono); color: var(--pp-text-subtle); }\r
\r
.pp-pair-ratio { font-weight: 700; }\r
\r
.pp-tag {\r
  display: inline-block;\r
  padding: 0 6px;\r
  border-radius: 999px;\r
  font-size: 10px;\r
  font-weight: 700;\r
  line-height: 16px;\r
}\r
\r
.pp-tag-pass { background: var(--pp-green-bg); color: var(--pp-green-400); }\r
\r
.pp-tag-fail { background: var(--pp-red-bg); color: var(--pp-red-400); }\r
\r
/* Fonts */\r
\r
/* Assets */\r
\r
.pp-assets { display: grid; grid-template-columns: repeat(3, 1fr); gap: var(--pp-space-100); }\r
\r
.pp-asset {\r
  position: relative;\r
  border: 1px solid var(--pp-border);\r
  border-radius: var(--pp-radius-small);\r
  overflow: hidden;\r
  background: var(--pp-bg);\r
}\r
\r
.pp-asset-thumb {\r
  height: 84px;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  background-color: var(--pp-bg-subtle);\r
  background-image: linear-gradient(45deg, #EBECF0 25%, transparent 25%, transparent 75%, #EBECF0 75%), linear-gradient(45deg, #EBECF0 25%, transparent 25%, transparent 75%, #EBECF0 75%);\r
  background-size: 12px 12px;\r
  background-position: 0 0, 6px 6px;\r
  font-size: 11px;\r
  font-weight: 700;\r
  color: var(--pp-text-subtlest);\r
}\r
\r
.pp-asset-thumb img { max-width: 100%; max-height: 100%; object-fit: contain; }\r
\r
.pp-asset-meta { padding: 4px 6px; font-size: 10px; color: var(--pp-text-subtle); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\r
\r
.pp-asset-dl {\r
  position: absolute;\r
  top: 4px;\r
  right: 4px;\r
  width: 22px;\r
  height: 22px;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  padding: 0;\r
  border: 1px solid var(--pp-border-strong);\r
  border-radius: var(--pp-radius-small);\r
  background: var(--pp-bg);\r
  color: var(--pp-text);\r
  cursor: pointer;\r
}\r
\r
.pp-asset-dl:hover { background: var(--pp-blue-a12); color: var(--pp-blue-400); }\r
\r
/* Design system */\r
\r
.pp-scale { margin-bottom: var(--pp-space-150); }\r
\r
.pp-scale-name { margin-bottom: 4px; font-size: 12px; font-weight: 700; text-transform: capitalize; }\r
\r
.pp-scale-strip { display: grid; grid-template-columns: repeat(11, 1fr); border: 1px solid var(--pp-border); border-radius: var(--pp-radius-small); overflow: hidden; }\r
\r
.pp-scale-step { height: 32px; border: none; padding: 0; cursor: pointer; }\r
\r
.pp-scale-step:hover { outline: 2px solid var(--pp-text); outline-offset: -2px; }\r
\r
.pp-code {\r
  max-height: 220px;\r
  margin: var(--pp-space-100) 0 0;\r
  padding: var(--pp-space-100) var(--pp-space-150);\r
  overflow: auto;\r
  background: var(--pp-bg-subtle);\r
  border: 1px solid var(--pp-border);\r
  border-radius: var(--pp-radius-small);\r
  font: 11px/16px var(--pp-mono);\r
  color: var(--pp-text);\r
  white-space: pre;\r
  user-select: text;\r
}\r
\r
.pp-list { margin: var(--pp-space-100) 0 0; padding-left: 18px; font-size: 12px; color: var(--pp-text-subtle); }\r
\r
/* ---- Designers first, developers second ---- */\r
\r
.pp-audience {\r
  display: flex;\r
  align-items: baseline;\r
  justify-content: space-between;\r
  gap: var(--pp-space-100);\r
  margin: var(--pp-space-200) 0 var(--pp-space-050);\r
  padding: 6px var(--pp-space-100);\r
  border-radius: var(--pp-radius-small);\r
  background: var(--pp-bg-subtle);\r
  border: 1px solid var(--pp-border);\r
  font-size: 12px;\r
  font-weight: 700;\r
  color: var(--pp-text);\r
}\r
\r
.pp-audience-hint { font-weight: 400; font-size: 11px; color: var(--pp-text-subtlest); text-align: right; }\r
\r
.pp-btn-wide { flex: 1; }\r
\r
.pp-status-ok { color: var(--pp-green-400); }\r
\r
.pp-status-warn { color: var(--pp-amber-300); }\r
\r
.pp-dev-actions { display: flex; flex-wrap: wrap; gap: var(--pp-space-100); padding: var(--pp-space-100) 0; }\r
\r
/* Tailwind chips */\r
\r
.pp-tw { display: flex; flex-wrap: wrap; gap: 4px; padding: var(--pp-space-050) 0 var(--pp-space-100); }\r
\r
.pp-tw-chip {\r
  padding: 1px 6px;\r
  border: 1px solid var(--pp-border);\r
  border-radius: var(--pp-radius-small);\r
  background: var(--pp-bg-subtle);\r
  color: var(--pp-text);\r
  font: 11px/18px var(--pp-mono);\r
  cursor: pointer;\r
}\r
\r
.pp-tw-chip:hover { background: var(--pp-blue-a12); border-color: var(--pp-blue-a35); color: var(--pp-blue-400); }\r
\r
/* Exit from inspecting */\r
\r
.pp-exit-pill {\r
  position: fixed;\r
  top: 16px;\r
  left: 50%;\r
  transform: translateX(-50%);\r
  display: inline-flex;\r
  align-items: center;\r
  gap: 8px;\r
  padding: 7px 10px 7px 12px;\r
  border: 1px solid var(--pp-border-strong);\r
  border-radius: 999px;\r
  background: var(--pp-bg);\r
  color: var(--pp-text);\r
  box-shadow: var(--pp-shadow-overlay);\r
  font: 600 12px/16px var(--pp-font);\r
  cursor: pointer;\r
  z-index: 4;\r
  pointer-events: auto;\r
}\r
\r
.pp-exit-pill:hover { background: var(--pp-red-bg); border-color: var(--pp-red-400); color: var(--pp-red-400); }\r
\r
.pp-exit-pill kbd { padding: 0 6px; border: 1px solid var(--pp-border); border-radius: 4px; background: var(--pp-bg-subtle); color: var(--pp-text-subtle); font: 10px/16px var(--pp-mono); }\r
\r
/* Alt-measuring */\r
\r
.pixelpeek-measure-box { position: fixed; pointer-events: none; box-sizing: border-box; border: 1px dashed #E5484D; background: rgba(229, 72, 77, 0.06); z-index: 1; }\r
\r
.pixelpeek-measure-line { position: fixed; pointer-events: none; background: #E5484D; z-index: 2; }\r
\r
.pixelpeek-measure-label { position: fixed; pointer-events: none; transform: translate(-50%, -50%); padding: 0 5px; border-radius: 3px; background: #E5484D; color: #fff; font: 600 11px/16px var(--pp-font); z-index: 2; }\r
\r
/* Saved library */\r
\r
.pp-saved { padding: var(--pp-space-150); margin-bottom: var(--pp-space-100); border: 1px solid var(--pp-border); border-radius: var(--pp-radius-small); }\r
\r
.pp-saved-head { display: flex; justify-content: space-between; gap: var(--pp-space-100); font-size: 13px; }\r
\r
.pp-saved-head b { font-family: var(--pp-mono); font-size: 12px; color: var(--pp-blue-400); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\r
\r
.pp-saved-head span, .pp-saved-meta { font-size: 11px; color: var(--pp-text-subtlest); }\r
\r
.pp-saved-meta { display: flex; align-items: center; gap: 4px; margin-top: 2px; }\r
\r
.pp-saved-text { margin-top: 4px; font-size: 12px; color: var(--pp-text-subtle); }\r
\r
.pp-asset-sub { padding-top: 0; color: var(--pp-text-subtlest); }\r
\r
/* ================================================================================================\r
   The overlay: one panel hovering over the page, on the right. It is position:fixed, so the page\r
   keeps its own width and layout.\r
   ================================================================================================ */\r
\r
.pp-ov {\r
  position: fixed;\r
  top: 12px;\r
  right: 12px;\r
  bottom: 12px;\r
  width: 400px;\r
  max-width: calc(100vw - 24px);\r
  display: flex;\r
  flex-direction: column;\r
  background: var(--pp-bg);\r
  color: var(--pp-text);\r
  border: 1px solid var(--pp-border);\r
  border-radius: 14px;\r
  box-shadow: var(--pp-shadow-overlay);\r
  font: var(--pp-font-size-body)/var(--pp-line-height-body) var(--pp-font);\r
  z-index: 3;\r
  pointer-events: auto;\r
  overflow: hidden;\r
}\r
\r
.pp-ov-top { flex-shrink: 0; padding: 10px 12px 0; border-bottom: 1px solid var(--pp-border); background: var(--pp-bg); }\r
\r
.pp-ov-icons { display: flex; justify-content: flex-end; gap: 4px; }\r
\r
.pp-ov-icon {\r
  width: 34px;\r
  height: 34px;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  padding: 0;\r
  border: none;\r
  border-radius: 8px;\r
  background: none;\r
  color: var(--pp-text);\r
  cursor: pointer;\r
}\r
\r
.pp-ov-icon:hover { background: var(--pp-bg-hover); }\r
\r
.pp-ov-icon[aria-pressed="true"] { background: var(--pp-blue-a12); color: var(--pp-blue-400); }\r
\r
.pp-ov-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 10px 2px 8px; }\r
\r
.pp-ov-title { min-width: 0; display: flex; align-items: baseline; gap: 8px; }\r
\r
.pp-ov-title b { font: 600 13px/18px var(--pp-mono); color: var(--pp-blue-400); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\r
\r
.pp-ov-title span { font-size: 11px; color: var(--pp-text-subtlest); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }\r
\r
.pp-ov-tabs { display: flex; gap: 4px; padding: 0 0 10px; }\r
\r
.pp-ov-tab {\r
  flex: 1;\r
  padding: 6px 4px;\r
  border: none;\r
  border-radius: 999px;\r
  background: none;\r
  color: var(--pp-text-subtle);\r
  font: 600 12px/16px var(--pp-font);\r
  white-space: nowrap;\r
  cursor: pointer;\r
}\r
\r
.pp-ov-tab:hover { background: var(--pp-bg-hover); color: var(--pp-text); }\r
\r
.pp-ov-tab[aria-selected="true"] { background: var(--pp-text); color: #fff; }\r
\r
.pp-ov-body { flex: 1; min-height: 0; overflow-y: auto; padding: 14px 14px 20px; background: var(--pp-bg); }\r
\r
.pp-ov-body::-webkit-scrollbar { width: 8px; }\r
\r
.pp-ov-body::-webkit-scrollbar-track { background: transparent; }\r
\r
.pp-ov-body::-webkit-scrollbar-thumb { background: var(--pp-border-strong); border-radius: 4px; }\r
\r
.pp-ov-foot {\r
  flex-shrink: 0;\r
  display: flex;\r
  justify-content: space-between;\r
  padding: 8px 14px;\r
  border-top: 1px solid var(--pp-border);\r
  background: var(--pp-bg-subtle);\r
  font-size: 11px;\r
  color: var(--pp-text-subtlest);\r
}\r
\r
.pp-toast {\r
  position: absolute;\r
  left: 50%;\r
  bottom: 44px;\r
  transform: translate(-50%, 8px);\r
  padding: 6px 12px;\r
  border-radius: 999px;\r
  background: var(--pp-text);\r
  color: #fff;\r
  font-size: 12px;\r
  font-weight: 600;\r
  opacity: 0;\r
  pointer-events: none;\r
  transition: opacity 0.15s, transform 0.15s;\r
}\r
\r
.pp-toast-on { opacity: 1; transform: translate(-50%, 0); }\r
\r
.pp-close-btn svg { display: block; margin: auto; }\r
\r
/* Style groups: Colors, Typography, Effect, Animation, Layout guide */\r
\r
.pp-btn[aria-pressed="true"] { background: var(--pp-blue-a12); border-color: var(--pp-blue-a35); color: var(--pp-blue-400); }\r
\r
.pp-btn-dark { background: #1D2125; border-color: #1D2125; color: #fff; }\r
\r
.pp-btn-dark:hover { background: #2C333A; }\r
\r
.pp-btn-wide { width: 100%; }\r
\r
.pp-dev-actions { display: flex; flex-wrap: wrap; gap: var(--pp-space-100); padding: var(--pp-space-100) 0; }\r
\r
.pp-status-ok { color: var(--pp-green-400); }\r
\r
/* Box model */\r
\r
.pp-boxmodel { margin: 8px 0; font: 10px/14px var(--pp-mono); color: var(--pp-text-subtle); }\r
\r
.pp-bm { position: relative; padding: 18px 26px; border: 1px dashed var(--pp-border-strong); border-radius: 4px; text-align: center; }\r
\r
.pp-bm-margin { background: #FFF0E6; }\r
\r
.pp-bm-border { background: #FFE9A8; border-style: solid; }\r
\r
.pp-bm-padding { background: #DFF5E7; }\r
\r
.pp-bm-content { padding: 8px; background: #CFE3FF; border-style: solid; color: var(--pp-text); }\r
\r
.pp-bm-name { position: absolute; top: 1px; left: 5px; font-size: 9px; text-transform: uppercase; opacity: 0.7; }\r
\r
.pp-bm-t, .pp-bm-b { position: absolute; left: 50%; transform: translateX(-50%); }\r
\r
.pp-bm-t { top: 2px; }\r
\r
.pp-bm-b { bottom: 2px; }\r
\r
.pp-bm-l, .pp-bm-r { position: absolute; top: 50%; transform: translateY(-50%); }\r
\r
.pp-bm-l { left: 6px; }\r
\r
.pp-bm-r { right: 6px; }\r
\r
/* Layout guides drawn on the page */\r
\r
.pp-guides { position: fixed; inset: 0; pointer-events: none; z-index: 1; }\r
\r
.pp-guide { position: fixed; box-sizing: border-box; border-style: solid; border-color: transparent; }\r
\r
.pp-guide-margin { border-color: rgba(255, 153, 51, 0.38); }\r
\r
.pp-guide-padding { border-color: rgba(52, 168, 83, 0.38); }\r
\r
.pp-guide-content { border: 1px dashed rgba(12, 102, 228, 0.9); background: rgba(12, 102, 228, 0.08); }\r
\r
.pp-guide-label { position: fixed; transform: translate(-50%, -50%); padding: 0 4px; border-radius: 3px; font: 600 10px/14px var(--pp-font); color: #fff; }\r
\r
.pp-guide-label-margin { background: #E07B12; }\r
\r
.pp-guide-label-padding { background: #2A8F47; }\r
\r
/* Design system components */\r
\r
.pp-comp { margin-bottom: 8px; border: 1px solid var(--pp-border); border-radius: var(--pp-radius-small); overflow: hidden; }\r
\r
.pp-comp-preview { display: flex; align-items: center; padding: 14px; background: var(--pp-bg-subtle); overflow: hidden; }\r
\r
.pp-comp-preview > span { max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\r
\r
.pp-comp-meta { display: flex; align-items: center; justify-content: space-between; padding: 6px 10px; font-size: 11px; color: var(--pp-text-subtle); }\r
\r
/* Account */\r
\r
.pp-account { display: flex; flex-direction: column; align-items: center; gap: 8px; padding: 28px 8px; text-align: center; }\r
\r
.pp-account-avatar { width: 56px; height: 56px; display: flex; align-items: center; justify-content: center; border-radius: 50%; background: var(--pp-bg-hover); color: var(--pp-text-subtlest); font-size: 22px; font-weight: 700; }\r
\r
/* Device list */\r
\r
.pp-dev-search input {\r
  width: 100%;\r
  box-sizing: border-box;\r
  padding: 9px 12px;\r
  border: 1px solid var(--pp-border-strong);\r
  border-radius: 10px;\r
  background: var(--pp-bg);\r
  color: var(--pp-text);\r
  font: inherit;\r
}\r
\r
.pp-dev-search input:focus { outline: 2px solid var(--pp-blue-a35); border-color: var(--pp-blue-400); }\r
\r
.pp-dev-groups { margin-top: 10px; background: var(--pp-bg-subtle); border-radius: 10px; padding: 4px 0; }\r
\r
.pp-dev-cat {\r
  display: flex;\r
  width: 100%;\r
  align-items: center;\r
  justify-content: space-between;\r
  padding: 10px 12px;\r
  border: none;\r
  background: none;\r
  color: var(--pp-text-subtle);\r
  font: 700 12px/16px var(--pp-font);\r
  letter-spacing: 0.04em;\r
  cursor: pointer;\r
}\r
\r
.pp-dev-cat:hover { color: var(--pp-text); }\r
\r
.pp-dev-cat-name, .pp-dev-cat-count { display: inline-flex; align-items: center; gap: 8px; }\r
\r
.pp-dev-cat-count { font-weight: 400; color: var(--pp-text-subtlest); }\r
\r
.pp-dev-cat[aria-expanded="true"] .pp-dev-cat-count svg { transform: rotate(90deg); }\r
\r
.pp-dev-list { padding: 0 6px 6px; }\r
\r
.pp-dev-row {\r
  display: flex;\r
  width: 100%;\r
  align-items: center;\r
  justify-content: space-between;\r
  padding: 8px 10px;\r
  border: none;\r
  border-radius: 8px;\r
  background: none;\r
  color: var(--pp-text);\r
  font: 13px/18px var(--pp-font);\r
  text-align: left;\r
  cursor: pointer;\r
}\r
\r
.pp-dev-row:hover { background: var(--pp-bg); box-shadow: inset 0 0 0 1px var(--pp-border); }\r
\r
.pp-dev-size { font: 11px/16px var(--pp-mono); color: var(--pp-text-subtlest); }\r
\r
/* ================================================================================================\r
   Responsive device preview\r
   ================================================================================================ */\r
\r
.pp-dp {\r
  position: fixed;\r
  inset: 0;\r
  display: none;\r
  flex-direction: column;\r
  background: rgba(15, 20, 32, 0.86);\r
  backdrop-filter: blur(3px);\r
  z-index: 5;\r
  pointer-events: auto;\r
  font: var(--pp-font-size-body-small)/var(--pp-line-height-body-small) var(--pp-font);\r
  color: #fff;\r
}\r
\r
.pp-dp-bar { display: flex; align-items: center; flex-wrap: wrap; gap: 10px; padding: 10px 16px; background: rgba(0, 0, 0, 0.35); }\r
\r
.pp-dp-title { display: flex; align-items: baseline; gap: 8px; margin-right: auto; }\r
\r
.pp-dp-title b { font-size: 14px; }\r
\r
.pp-dp-title span, .pp-dp-scale { color: rgba(255, 255, 255, 0.65); font-family: var(--pp-mono); }\r
\r
.pp-dp-bar .pp-btn { background: rgba(255, 255, 255, 0.1); border-color: rgba(255, 255, 255, 0.25); color: #fff; }\r
\r
.pp-dp-bar .pp-btn:hover { background: rgba(255, 255, 255, 0.2); }\r
\r
.pp-dp-bar kbd { margin-left: 4px; padding: 0 5px; border: 1px solid rgba(255, 255, 255, 0.35); border-radius: 4px; font: 10px/14px var(--pp-mono); }\r
\r
.pp-dp-size { display: flex; align-items: center; gap: 6px; }\r
\r
.pp-dp-size input { width: 70px; padding: 4px 6px; border: 1px solid rgba(255, 255, 255, 0.3); border-radius: 6px; background: rgba(255, 255, 255, 0.1); color: #fff; font: 12px var(--pp-mono); }\r
\r
.pp-dp-presets { display: flex; gap: 4px; }\r
\r
.pp-dp-presets .pp-chip { background: rgba(255, 255, 255, 0.08); border-color: rgba(255, 255, 255, 0.2); color: #fff; padding: 2px 8px; }\r
\r
.pp-dp-stage { flex: 1; min-height: 0; display: flex; align-items: center; justify-content: center; overflow: hidden; }\r
\r
.pp-dp-stage > .pp-dev { transform-origin: center center; flex-shrink: 0; }\r
\r
/* The mockup. Its size and bezel thickness come in as custom properties from the preview code. */\r
\r
.pp-dev { position: relative; box-sizing: border-box; background: #14171C; border-radius: var(--r); box-shadow: 0 0 0 2px #3A3F47, 0 24px 60px rgba(0, 0, 0, 0.5); }\r
\r
.pp-dev-screen {\r
  position: absolute;\r
  left: var(--bl);\r
  top: var(--bt);\r
  width: var(--sw);\r
  height: var(--sh);\r
  overflow: hidden;\r
  border-radius: max(0px, calc(var(--r) - 12px));\r
  background: #fff;\r
}\r
\r
.pp-dp-frame { display: block; width: 100%; height: 100%; border: 0; background: #fff; }\r
\r
.pp-dp-blocked {\r
  position: absolute;\r
  inset: 0;\r
  display: flex;\r
  flex-direction: column;\r
  align-items: center;\r
  justify-content: center;\r
  gap: 10px;\r
  padding: 24px;\r
  background: #fff;\r
  color: var(--pp-text);\r
  text-align: center;\r
}\r
\r
.pp-dp-blocked[hidden] { display: none; }\r
\r
.pp-dp-blocked p { margin: 0; color: var(--pp-text-subtle); }\r
\r
.pp-dev-deco { position: absolute; display: none; pointer-events: none; }\r
\r
/* Phones with a Dynamic Island, a notch or a punch-hole camera */\r
\r
.pp-dev-island .pp-dev-a { display: block; top: calc(var(--bt) + 11px); left: 50%; width: 118px; height: 34px; margin-left: -59px; border-radius: 20px; background: #000; z-index: 2; }\r
\r
.pp-dev-notch .pp-dev-a { display: block; top: var(--bt); left: 50%; width: 160px; height: 30px; margin-left: -80px; border-radius: 0 0 20px 20px; background: #14171C; z-index: 2; }\r
\r
.pp-dev-punch .pp-dev-a { display: block; top: calc(var(--bt) + 14px); left: 50%; width: 18px; height: 18px; margin-left: -9px; border-radius: 50%; background: #000; z-index: 2; }\r
\r
.pp-dev-fold .pp-dev-a { display: block; top: calc(var(--bt) + 14px); left: 50%; width: 16px; height: 16px; margin-left: -8px; border-radius: 50%; background: #000; z-index: 2; }\r
\r
.pp-dev-island .pp-dev-b, .pp-dev-notch .pp-dev-b, .pp-dev-punch .pp-dev-b, .pp-dev-fold .pp-dev-b { display: block; bottom: calc(var(--bb) + 8px); left: 50%; width: 134px; height: 5px; margin-left: -67px; border-radius: 3px; background: rgba(0, 0, 0, 0.55); z-index: 2; }\r
\r
/* iPhone SE: forehead speaker and a home button */\r
\r
.pp-dev-home .pp-dev-a { display: block; top: 28px; left: 50%; width: 60px; height: 6px; margin-left: -30px; border-radius: 3px; background: #2B2F36; }\r
\r
.pp-dev-home .pp-dev-b { display: block; bottom: 17px; left: 50%; width: 48px; height: 48px; margin-left: -24px; border-radius: 50%; border: 2px solid #3A3F47; }\r
\r
.pp-dev-tablet .pp-dev-a { display: block; top: 8px; left: 50%; width: 8px; height: 8px; margin-left: -4px; border-radius: 50%; background: #2B2F36; }\r
\r
/* Laptop: the lid, then a base under it */\r
\r
.pp-dev-laptop { box-shadow: 0 0 0 2px #3A3F47; margin-bottom: 28px; }\r
\r
.pp-dev-laptop .pp-dev-a { display: block; left: -6%; right: -6%; bottom: -14px; height: 14px; border-radius: 0 0 18px 18px; background: linear-gradient(#C9CDD3, #9EA3AB); box-shadow: 0 18px 30px rgba(0, 0, 0, 0.45); }\r
\r
.pp-dev-laptop .pp-dev-b { display: block; left: 50%; bottom: -14px; width: 110px; height: 6px; margin-left: -55px; border-radius: 0 0 8px 8px; background: #8A8F97; }\r
\r
/* Monitor: a chin and a stand */\r
\r
.pp-dev-monitor { margin-bottom: 64px; }\r
\r
.pp-dev-monitor .pp-dev-a { display: block; left: 50%; bottom: -46px; width: 70px; height: 46px; margin-left: -35px; background: linear-gradient(90deg, #8A8F97, #C9CDD3, #8A8F97); }\r
\r
.pp-dev-monitor .pp-dev-b { display: block; left: 50%; bottom: -56px; width: 190px; height: 10px; margin-left: -95px; border-radius: 6px; background: linear-gradient(#C9CDD3, #8A8F97); }\r
\r
/* Watch: a crown and two bands */\r
\r
.pp-dev-watch { margin: 80px 0; }\r
\r
.pp-dev-watch .pp-dev-a { display: block; right: -9px; top: 22%; width: 9px; height: 36px; border-radius: 0 5px 5px 0; background: #3A3F47; }\r
\r
.pp-dev-watch .pp-dev-b { display: block; left: 18%; right: 18%; top: -76px; height: 80px; border-radius: 12px 12px 0 0; background: #23272E; z-index: -1; }\r
\r
.pp-dev-watch .pp-dev-c { display: block; left: 18%; right: 18%; bottom: -76px; height: 80px; border-radius: 0 0 12px 12px; background: #23272E; z-index: -1; }\r
\r
.pp-dev-plain { background: #fff; box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.35); }\r
\r
.pp-dev-plain .pp-dev-screen { border-radius: 10px; }\r
\r
.pp-landscape.pp-dev-island .pp-dev-a, .pp-landscape.pp-dev-notch .pp-dev-a, .pp-landscape.pp-dev-punch .pp-dev-a,\r
.pp-landscape.pp-dev-island .pp-dev-b, .pp-landscape.pp-dev-notch .pp-dev-b, .pp-landscape.pp-dev-punch .pp-dev-b { display: none; }\r
\r
@keyframes pp-ov-open { from { opacity: 0.4; transform: translateY(-6px); } to { opacity: 1; transform: none; } }\r
\r
.pp-ov:not(.pp-ov-collapsed) { animation: pp-ov-open 0.18s ease-out; }\r
\r
/* While picking an element nothing of the panel is shown: the tools live in the floating pill. */\r
.pp-ov-collapsed { display: none; }\r
\r
.pp-ov-nav { flex-shrink: 0; padding: 4px 12px 0; background: var(--pp-bg-subtle); border-bottom: 1px solid var(--pp-border); }\r
\r
.pp-ov-head { padding: 8px 2px 8px; }\r
\r
.pp-ov-tabs { padding: 0 0 10px; }\r
\r
.pp-ov-body { background: var(--pp-bg); }\r
\r
\r
/* ---- Dock: one click from any tool to any other ---- */\r
\r
.pp-dock {\r
  position: fixed;\r
  left: 50%;\r
  bottom: 18px;\r
  transform: translateX(-50%);\r
  display: flex;\r
  align-items: center;\r
  gap: 2px;\r
  max-width: calc(100vw - 24px);\r
  padding: 4px;\r
  overflow-x: auto;\r
  background: var(--pp-bg);\r
  border: 1px solid var(--pp-border);\r
  border-radius: 12px;\r
  box-shadow: var(--pp-shadow-overlay);\r
  font: 600 12px/16px var(--pp-font);\r
  color: var(--pp-text);\r
  z-index: 4;\r
  pointer-events: auto;\r
  user-select: none;\r
}\r
\r
.pp-dock-btn {\r
  display: inline-flex;\r
  align-items: center;\r
  gap: 6px;\r
  padding: 6px 10px;\r
  border: none;\r
  border-radius: 8px;\r
  background: none;\r
  color: var(--pp-text-subtle);\r
  font: inherit;\r
  white-space: nowrap;\r
  cursor: pointer;\r
}\r
\r
.pp-dock-btn:hover { background: var(--pp-bg-hover); color: var(--pp-text); }\r
\r
.pp-dock-btn[aria-pressed="true"] { background: var(--pp-blue-a12); color: var(--pp-blue-400); }\r
\r
.pp-dock-btn svg { flex-shrink: 0; }\r
\r
.pp-dock-sep { width: 1px; height: 20px; margin: 0 4px; background: var(--pp-border); flex-shrink: 0; }\r
\r
.pp-dock-close { padding: 6px 8px; }\r
\r
.pp-dock-close:hover { background: var(--pp-red-bg); color: var(--pp-red-400); }\r
\r
/* ---- Hover card: the basics of whatever is under the pointer ---- */\r
\r
.pp-hover {\r
  position: fixed;\r
  width: 250px;\r
  padding: 8px 10px 6px;\r
  background: var(--pp-bg);\r
  color: var(--pp-text);\r
  border: 1px solid var(--pp-border-strong);\r
  border-radius: 10px;\r
  box-shadow: var(--pp-shadow-overlay);\r
  font: 12px/18px var(--pp-font);\r
  pointer-events: none;\r
  z-index: 2;\r
}\r
\r
.pp-hover-head { display: flex; justify-content: space-between; gap: 8px; padding-bottom: 4px; margin-bottom: 4px; border-bottom: 1px solid var(--pp-border); }\r
\r
.pp-hover-head b { font: 600 12px/18px var(--pp-mono); color: var(--pp-blue-400); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\r
\r
.pp-hover-head span { color: var(--pp-text-subtlest); white-space: nowrap; }\r
\r
.pp-hover-row { display: flex; justify-content: space-between; gap: 10px; }\r
\r
.pp-hover-row > span:first-child { color: var(--pp-text-subtle); }\r
\r
.pp-hover-row > span:last-child { display: inline-flex; align-items: center; gap: 5px; text-align: right; font: 11px/18px var(--pp-mono); }\r
\r
.pp-hover-foot { margin-top: 4px; padding-top: 4px; border-top: 1px solid var(--pp-border); font-size: 11px; color: var(--pp-text-subtlest); }\r
\r
.pp-hv-ok { color: var(--pp-green-400); font-weight: 700; }\r
\r
.pp-hv-bad { color: var(--pp-red-400); font-weight: 700; }\r
\r
/* Leave room for the dock so the two never overlap. */\r
\r
.pp-ov { bottom: 72px; }\r
\r
.pp-ov-collapsed { bottom: auto; }\r
\r
/* ================================================================================================\r
   Cards: every group of information is a collapsible card with an icon.\r
   ================================================================================================ */\r
\r
.pp-card { margin-bottom: 10px; border: 1px solid var(--pp-border); border-radius: 10px; background: var(--pp-bg); overflow: hidden; }\r
\r
.pp-card-head {\r
  display: flex;\r
  align-items: center;\r
  gap: 8px;\r
  padding: 9px 10px 9px 12px;\r
  background: var(--pp-bg-subtle);\r
  cursor: pointer;\r
  user-select: none;\r
}\r
\r
.pp-card-head:hover { background: var(--pp-bg-hover); }\r
.pp-card-open > .pp-card-head { border-bottom: 1px solid var(--pp-border); }\r
.pp-card-ico { display: inline-flex; color: var(--pp-blue-400); }\r
.pp-card-head h3 { flex: 1; min-width: 0; margin: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 13px; font-weight: 700; }\r
.pp-card-meta { padding: 0 7px; border-radius: 999px; background: var(--pp-bg-hover); color: var(--pp-text-subtle); font-size: 11px; line-height: 18px; }\r
.pp-card-chev { display: inline-flex; color: var(--pp-text-subtlest); transition: transform 0.15s; }\r
.pp-card-open > .pp-card-head .pp-card-chev { transform: rotate(90deg); }\r
.pp-card-body { padding: 12px; }\r
\r
.pp-card-copy {\r
  padding: 1px 8px;\r
  border: 1px solid var(--pp-border);\r
  border-radius: 999px;\r
  background: var(--pp-bg);\r
  color: var(--pp-text-subtle);\r
  font: 600 11px/18px var(--pp-font);\r
  white-space: nowrap;\r
  cursor: pointer;\r
}\r
\r
.pp-card-copy:hover { background: var(--pp-blue-a12); border-color: var(--pp-blue-a35); color: var(--pp-blue-400); }\r
.pp-btn-sm { padding: 1px 8px; font-size: 11px; line-height: 18px; }\r
\r
.pp-sub { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin: 12px 0 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: var(--pp-text-subtle); }\r
\r
/* Label + value chips: a click copies. Only values worth pasting get the copy affordance. */\r
.pp-cv-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }\r
\r
.pp-cv {\r
  position: relative;\r
  display: flex;\r
  flex-direction: column;\r
  align-items: flex-start;\r
  gap: 1px;\r
  min-width: 0;\r
  padding: 6px 24px 6px 9px;\r
  border: 1px solid var(--pp-border);\r
  border-radius: 8px;\r
  background: var(--pp-bg);\r
  color: var(--pp-text);\r
  font: inherit;\r
  text-align: left;\r
  cursor: pointer;\r
}\r
\r
.pp-cv:hover { border-color: var(--pp-blue-400); background: var(--pp-blue-a12); }\r
.pp-cv-off { cursor: default; background: var(--pp-bg-subtle); }\r
.pp-cv-off:hover { border-color: var(--pp-border); background: var(--pp-bg-subtle); }\r
.pp-cv-k { font-size: 10px; line-height: 14px; text-transform: uppercase; letter-spacing: 0.04em; color: var(--pp-text-subtlest); }\r
.pp-cv-v { display: inline-flex; align-items: center; gap: 5px; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font: 600 12px/18px var(--pp-mono); }\r
.pp-cv-i { position: absolute; top: 6px; right: 8px; opacity: 0; color: var(--pp-blue-400); font-size: 12px; transition: opacity 0.1s; }\r
.pp-cv:hover .pp-cv-i, .pp-fam:hover .pp-cv-i { opacity: 1; }\r
\r
/* Colour squares */\r
.pp-squares { display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px; }\r
.pp-sq { display: flex; flex-direction: column; gap: 3px; min-width: 0; padding: 0; border: none; background: none; font: inherit; text-align: left; cursor: pointer; }\r
.pp-sq-fill { position: relative; display: block; aspect-ratio: 1; border: 1px solid var(--pp-border-strong); border-radius: 8px; overflow: hidden; }\r
.pp-sq-copy { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; background: rgba(23, 43, 77, 0.55); color: #fff; font: 700 11px/16px var(--pp-font); opacity: 0; transition: opacity 0.12s; }\r
.pp-sq:hover .pp-sq-copy, .pp-sq:focus-visible .pp-sq-copy { opacity: 1; }\r
.pp-sq-hex { font: 600 10px/14px var(--pp-mono); color: var(--pp-text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\r
.pp-sq-sub { font-size: 10px; line-height: 12px; color: var(--pp-text-subtlest); text-transform: capitalize; }\r
\r
.pp-grad { position: relative; display: block; width: 100%; height: 34px; margin-top: 10px; border: 1px solid var(--pp-border-strong); border-radius: 8px; cursor: pointer; }\r
.pp-grad span { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; border-radius: 7px; background: rgba(23, 43, 77, 0.55); color: #fff; font: 700 11px/16px var(--pp-font); opacity: 0; transition: opacity 0.12s; }\r
.pp-grad:hover span { opacity: 1; }\r
\r
.pp-contrast { display: flex; align-items: center; flex-wrap: wrap; gap: 6px; margin-top: 10px; }\r
.pp-contrast-ratio { font: 700 13px/18px var(--pp-mono); }\r
\r
/* Typography */\r
.pp-fam { position: relative; display: flex; align-items: center; gap: 12px; width: 100%; box-sizing: border-box; margin-bottom: 8px; padding: 8px 28px 8px 10px; border: 1px solid var(--pp-border); border-radius: 8px; background: var(--pp-bg); color: var(--pp-text); font: inherit; text-align: left; cursor: pointer; }\r
.pp-fam:hover { border-color: var(--pp-blue-400); background: var(--pp-blue-a12); }\r
.pp-fam-static { cursor: default; padding-right: 10px; }\r
.pp-fam-static:hover { border-color: var(--pp-border); background: var(--pp-bg); }\r
.pp-fam-sample { flex-shrink: 0; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; padding: 0; border: none; border-radius: 8px; background: var(--pp-bg-hover); color: var(--pp-text); font-size: 24px; line-height: 1; cursor: pointer; }\r
.pp-fam-info { display: flex; flex-direction: column; min-width: 0; }\r
.pp-fam-info b { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 13px; }\r
.pp-fam-info span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 11px; color: var(--pp-text-subtlest); }\r
.pp-fam-info a { color: var(--pp-blue-400); }\r
\r
/* Code blocks you can click to copy */\r
.pp-code-copy { display: block; width: 100%; margin-top: 8px; padding: 0; border: none; background: none; text-align: left; cursor: pointer; }\r
.pp-code-copy:hover .pp-code { border-color: var(--pp-blue-400); }\r
.pp-code-copy .pp-code { margin: 0; }\r
\r
.pp-hover-foot kbd { padding: 0 4px; border: 1px solid var(--pp-border-strong); border-radius: 3px; background: var(--pp-bg-subtle); font: 600 10px/14px var(--pp-mono); color: var(--pp-text-subtle); }\r
.pp-hover-flash { color: var(--pp-green-400); font-weight: 700; }\r
\r
.pp-ov-head-btns { display: flex; align-items: center; gap: 2px; }\r
.pp-ov-head-btns .pp-close-btn[aria-pressed="true"] { background: var(--pp-blue-a12); color: var(--pp-blue-400); }\r
\r
/* ================================================================================================\r
   The floating tool pill: frosted glass, a dot at rest, a vertical stack on hover. Draggable.\r
   ================================================================================================ */\r
\r
.pp-pill { position: fixed; width: 40px; height: 40px; z-index: 5; pointer-events: auto; font: 600 12px/16px var(--pp-font); }\r
\r
.pp-pill-card {\r
  position: absolute;\r
  left: 0;\r
  top: 0;\r
  width: 40px;\r
  height: 40px;\r
  display: flex;\r
  flex-direction: column;\r
  align-items: center;\r
  box-sizing: border-box;\r
  overflow: hidden;\r
  border: 1px solid rgba(9, 30, 66, 0.14);\r
  border-radius: 20px;\r
  background: rgba(255, 255, 255, 0.72);\r
  -webkit-backdrop-filter: blur(14px) saturate(1.6);\r
  backdrop-filter: blur(14px) saturate(1.6);\r
  box-shadow: 0 6px 20px rgba(9, 30, 66, 0.18), 0 0 0 3px rgba(12, 102, 228, 0.12);\r
  transition: height 0.18s ease, box-shadow 0.18s ease;\r
}\r
\r
.pp-pill-up .pp-pill-card { top: auto; bottom: 0; flex-direction: column-reverse; }\r
.pp-pill-open { height: 192px; box-shadow: 0 10px 28px rgba(9, 30, 66, 0.22), 0 0 0 3px rgba(12, 102, 228, 0.2); }\r
.pp-pill-dragging .pp-pill-card { box-shadow: 0 12px 32px rgba(9, 30, 66, 0.28), 0 0 0 3px rgba(12, 102, 228, 0.35); }\r
\r
.pp-pill-mark, .pp-pill-btn {\r
  position: relative;\r
  flex-shrink: 0;\r
  width: 36px;\r
  height: 36px;\r
  display: flex;\r
  align-items: center;\r
  justify-content: center;\r
  margin: 1px 0;\r
  padding: 0;\r
  border: none;\r
  border-radius: 50%;\r
  background: none;\r
  color: var(--pp-text);\r
  cursor: pointer;\r
}\r
\r
.pp-pill-mark { color: var(--pp-blue-400); cursor: grab; touch-action: none; }\r
.pp-pill-dragging .pp-pill-mark { cursor: grabbing; }\r
.pp-pill-btn { opacity: 0; transition: opacity 0.12s 0.04s, background 0.12s; }\r
.pp-pill-open .pp-pill-btn { opacity: 1; }\r
.pp-pill-btn:hover, .pp-pill-btn:focus-visible { background: rgba(9, 30, 66, 0.08); }\r
.pp-pill-btn[aria-pressed="true"] { background: var(--pp-blue-a12); color: var(--pp-blue-400); }\r
.pp-pill-ico { display: inline-flex; }\r
\r
.pp-pill-tip, .pp-pill-note {\r
  position: absolute;\r
  top: 50%;\r
  left: calc(100% + 10px);\r
  transform: translateY(-50%);\r
  padding: 3px 8px;\r
  border-radius: 6px;\r
  background: #1D2125;\r
  color: #fff;\r
  font: 600 11px/16px var(--pp-font);\r
  white-space: nowrap;\r
  opacity: 0;\r
  pointer-events: none;\r
}\r
\r
.pp-pill-btn:hover .pp-pill-tip, .pp-pill-btn:focus-visible .pp-pill-tip { opacity: 1; }\r
.pp-pill-left .pp-pill-tip, .pp-pill-left .pp-pill-note { left: auto; right: calc(100% + 10px); }\r
.pp-pill-note { transition: opacity 0.15s; }\r
.pp-pill-note-on { opacity: 1; }\r
\r
@media (prefers-reduced-motion: reduce) {\r
  .pp-pill-card, .pp-pill-btn, .pp-pill-note { transition: none; }\r
}\r
\r
.pp-pill-mark img { display: block; width: 28px; height: 28px; border-radius: 8px; pointer-events: none; user-select: none; }\r
\r
/* The tools in the panel's top row (shown instead of the floating pill once something is selected). */\r
.pp-ov-tools { display: flex; gap: 4px; padding: 8px 0 2px; }\r
.pp-ov-tool { flex: 1; display: flex; align-items: center; justify-content: center; gap: 5px; min-width: 0; padding: 6px 4px; border: 1px solid var(--pp-border); border-radius: 8px; background: var(--pp-bg); color: var(--pp-text-subtle); font: 600 11px/16px var(--pp-font); cursor: pointer; }\r
.pp-ov-tool:hover { background: var(--pp-bg-hover); color: var(--pp-text); }\r
.pp-ov-tool[aria-pressed="true"] { background: var(--pp-blue-a12); border-color: var(--pp-blue-a35); color: var(--pp-blue-400); }\r
.pp-ov-tool span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\r
.pp-ov-tool svg { flex-shrink: 0; }\r
\r
.pp-sq-sub { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\r
\r
/* Design system: declared variables */\r
.pp-toks { display: flex; flex-direction: column; gap: 4px; margin-bottom: 6px; }\r
.pp-tok { display: flex; align-items: center; gap: 8px; width: 100%; box-sizing: border-box; padding: 5px 8px; border: 1px solid var(--pp-border); border-radius: 8px; background: var(--pp-bg); color: var(--pp-text); font: inherit; text-align: left; cursor: pointer; }\r
.pp-tok:hover { border-color: var(--pp-blue-400); background: var(--pp-blue-a12); }\r
.pp-tok-sw { flex-shrink: 0; width: 18px; height: 18px; border: 1px solid var(--pp-border-strong); border-radius: 5px; }\r
.pp-tok-none { background: repeating-linear-gradient(45deg, var(--pp-bg-subtle), var(--pp-bg-subtle) 3px, var(--pp-bg-hover) 3px, var(--pp-bg-hover) 6px); }\r
.pp-tok-main { display: flex; flex-direction: column; flex: 1; min-width: 0; }\r
.pp-tok-main b { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font: 600 12px/16px var(--pp-mono); }\r
.pp-tok-main span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font: 11px/14px var(--pp-mono); color: var(--pp-text-subtlest); }\r
.pp-tok-dark { display: inline-flex; align-items: center; gap: 4px; flex-shrink: 0; }\r
.pp-tok-dark em { font-style: normal; font-size: 10px; color: var(--pp-text-subtlest); text-transform: uppercase; letter-spacing: 0.04em; }\r
\r
/* Effects */\r
.pp-fx { display: flex; align-items: center; gap: 12px; width: 100%; box-sizing: border-box; margin-bottom: 8px; padding: 8px 10px; border: 1px solid var(--pp-border); border-radius: 8px; background: var(--pp-bg); color: var(--pp-text); font: inherit; text-align: left; cursor: pointer; }\r
.pp-fx:hover { border-color: var(--pp-blue-400); background: var(--pp-blue-a12); }\r
.pp-fx-box { flex-shrink: 0; width: 40px; height: 40px; border-radius: 8px; background: #fff; border: 1px solid var(--pp-border); }\r
\r
/* Components: the real values next to each preview */\r
.pp-comp-details { display: flex; flex-wrap: wrap; gap: 4px 6px; padding: 8px 0 2px; }\r
.pp-comp-details > span { display: inline-flex; align-items: center; gap: 4px; padding: 1px 6px; border: 1px solid var(--pp-border); border-radius: 999px; font: 11px/16px var(--pp-mono); color: var(--pp-text); max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\r
.pp-comp-details i { font-style: normal; font-family: var(--pp-font); font-size: 10px; text-transform: uppercase; letter-spacing: 0.04em; color: var(--pp-text-subtlest); }\r
\r
/* Tool row: icon-only buttons with a tooltip, and a handle to move the panel. */\r
.pp-ov-nav { position: relative; z-index: 2; }\r
.pp-ov-tools { display: flex; align-items: center; gap: 6px; padding: 8px 0 4px; cursor: grab; touch-action: none; }\r
.pp-ov-dragging .pp-ov-tools { cursor: grabbing; }\r
.pp-ov-dragging { user-select: none; box-shadow: 0 16px 40px rgba(9, 30, 66, 0.3); }\r
.pp-ov-grip { display: inline-flex; align-items: center; padding: 0 4px 0 2px; color: var(--pp-text-subtlest); }\r
.pp-ov-tools .pp-ov-tool { position: relative; flex: 0 0 auto; width: 40px; height: 34px; padding: 0; }\r
/* The tools sit on the right of the row; the grip stays on the left. */\r
.pp-ov-tools .pp-ov-tool:first-of-type { margin-left: auto; }\r
\r
/* Responsive preview: whether the mobile browser switch is on. */\r
.pp-dp-emu { margin-left: auto; padding: 0 10px; font-size: 12px; color: #8FD3A5; white-space: nowrap; }\r
.pp-dp-emu-warn { color: #F5CD47; }\r
`;var R="pixelpeek-host";function Ht(){let o=document.getElementById(R);o&&o.remove();let e=document.createElement("div");e.id=R,e.style.position="fixed",e.style.top="0",e.style.left="0",e.style.width="0",e.style.height="0",e.style.zIndex="2147483647";let t=e.attachShadow({mode:"closed"}),r=document.createElement("style");return r.textContent=Dt,t.appendChild(r),document.documentElement.appendChild(e),{host:e,root:t}}function Bt(){document.getElementById(R)?.remove()}var at=new Set(["HTML","BODY"]),Le=class{constructor(e,t){this.hovered=null;this.locked=null;this.rafPending=!1;this.lastMouseEvent=null;this.scrollRafPending=!1;this.outsideClickCount=0;this.measureEls=[];this.enabled=!0;this.scrolling=!1;this.scrollTimer=0;this.root=e,this.callbacks=t,this.outline=document.createElement("div"),this.outline.className="pixelpeek-outline",this.outline.style.display="none",this.chip=document.createElement("div"),this.chip.className="pixelpeek-chip",this.chip.style.display="none",this.root.appendChild(this.outline),this.root.appendChild(this.chip),this.onMouseMove=this.onMouseMove.bind(this),this.onClick=this.onClick.bind(this),this.onKeyDown=this.onKeyDown.bind(this),this.onScrollOrResize=this.onScrollOrResize.bind(this),this.onKeyUp=this.onKeyUp.bind(this),window.addEventListener("mousemove",this.onMouseMove,!0),window.addEventListener("click",this.onClick,!0),document.addEventListener("keydown",this.onKeyDown,!0),document.addEventListener("keyup",this.onKeyUp,!0),document.addEventListener("scroll",this.onScrollOrResize,!0),window.addEventListener("resize",this.onScrollOrResize)}destroy(){window.removeEventListener("mousemove",this.onMouseMove,!0),window.removeEventListener("click",this.onClick,!0),document.removeEventListener("keydown",this.onKeyDown,!0),document.removeEventListener("keyup",this.onKeyUp,!0),clearTimeout(this.scrollTimer),this.clearMeasure(),document.removeEventListener("scroll",this.onScrollOrResize,!0),window.removeEventListener("resize",this.onScrollOrResize),this.outline.remove(),this.chip.remove()}closeExtension(){this.callbacks.onDeactivate()}release(){this.locked&&this.unlock()}setEnabled(e){this.enabled=e,e||(this.hovered=null,this.callbacks.onHover?.(null),this.locked&&this.unlock(),this.outline.style.display="none",this.chip.style.display="none",this.clearMeasure())}refresh(){this.locked&&this.drawOutline(this.locked,!0)}isOwnElement(e){return e?.id===R}onMouseMove(e){if(this.enabled&&!this.scrolling){if(this.locked){e.altKey?this.measureTo(e.clientX,e.clientY):this.clearMeasure();return}this.lastMouseEvent=e,!this.rafPending&&(this.rafPending=!0,requestAnimationFrame(()=>{if(this.rafPending=!1,!this.lastMouseEvent)return;let t=document.elementFromPoint(this.lastMouseEvent.clientX,this.lastMouseEvent.clientY);t&&!this.isOwnElement(t)&&!at.has(t.tagName)&&this.setHovered(t)}))}}onClick(e){if(!this.enabled)return;let t=e.target;if(this.locked){if(this.isOwnElement(t)){this.outsideClickCount=0;return}if(t===this.locked||this.locked.contains(t)){this.outsideClickCount=0;return}this.outsideClickCount++,this.outsideClickCount===1?this.pulsePanel():(this.outsideClickCount=0,this.unlock());return}this.isOwnElement(t)||this.hovered&&(e.preventDefault(),e.stopPropagation(),this.lock(this.hovered))}pulsePanel(){this.callbacks.onOutsideClick?.()}onScrollOrResize(){this.scrolling||(this.scrolling=!0,this.callbacks.onScrolling?.(!0)),clearTimeout(this.scrollTimer),this.scrollTimer=window.setTimeout(()=>{this.scrolling=!1,this.callbacks.onScrolling?.(!1)},180),!this.scrollRafPending&&(this.scrollRafPending=!0,requestAnimationFrame(()=>{this.scrollRafPending=!1;let e=this.locked??this.hovered;e&&this.enabled&&this.drawOutline(e,!!this.locked)}))}onKeyDown(e){if(e.key==="Escape"){e.preventDefault(),e.stopPropagation(),this.callbacks.onEscape?.()||this.closeExtension();return}if(!this.locked&&this.enabled&&this.hovered&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&!this.isOwnElement(e.target)){let t=e.key.toLowerCase()==="f"?"figma":e.key.toLowerCase()==="s"?"save":null;if(t){e.preventDefault(),e.stopPropagation(),this.callbacks.onHoverKey?.(t,this.hovered);return}}if(!(!this.locked||!this.enabled))switch(e.key){case"ArrowUp":{let t=this.locked.parentElement;t&&!at.has(t.tagName)&&(e.preventDefault(),e.stopPropagation(),this.lock(t));return}case"ArrowDown":{let t=this.locked.children[0];t&&(e.preventDefault(),e.stopPropagation(),this.lock(t));return}case"ArrowLeft":{let t=this.locked.previousElementSibling;t&&(e.preventDefault(),e.stopPropagation(),this.lock(t));return}case"ArrowRight":{let t=this.locked.nextElementSibling;t&&(e.preventDefault(),e.stopPropagation(),this.lock(t));return}}}onKeyUp(e){e.key==="Alt"&&this.clearMeasure()}clearMeasure(){for(let e of this.measureEls)e.remove();this.measureEls=[]}measureTo(e,t){this.clearMeasure();let r=this.locked,n=document.elementFromPoint(e,t);if(!r||!n||this.isOwnElement(n)||n===r||at.has(n.tagName))return;let i=r.getBoundingClientRect(),s=n.getBoundingClientRect(),p=document.createElement("div");p.className="pixelpeek-measure-box",Object.assign(p.style,{top:`${s.top}px`,left:`${s.left}px`,width:`${s.width}px`,height:`${s.height}px`}),this.root.appendChild(p),this.measureEls.push(p);let a=(m,v,u,g,y)=>{if(y<=0)return;let $=v===g,k=document.createElement("div");k.className="pixelpeek-measure-line",Object.assign(k.style,$?{left:`${Math.min(m,u)}px`,top:`${v}px`,width:`${Math.abs(u-m)}px`,height:"1px"}:{left:`${m}px`,top:`${Math.min(v,g)}px`,width:"1px",height:`${Math.abs(g-v)}px`});let I=document.createElement("div");I.className="pixelpeek-measure-label",I.textContent=`${Math.round(y)}`,Object.assign(I.style,{left:`${(m+u)/2}px`,top:`${(v+g)/2}px`}),this.root.append(k,I),this.measureEls.push(k,I)},l=(Math.max(i.top,s.top)+Math.min(i.bottom,s.bottom))/2,c=(Math.max(i.left,s.left)+Math.min(i.right,s.right))/2,d=Math.max(i.top,s.top)<Math.min(i.bottom,s.bottom)?l:(i.top+i.bottom)/2,h=Math.max(i.left,s.left)<Math.min(i.right,s.right)?c:(i.left+i.right)/2;s.left>=i.right?a(i.right,d,s.left,d,s.left-i.right):i.left>=s.right?a(s.right,d,i.left,d,i.left-s.right):(a(Math.min(i.left,s.left),d,Math.max(i.left,s.left),d,Math.abs(i.left-s.left)),a(Math.min(i.right,s.right),d,Math.max(i.right,s.right),d,Math.abs(i.right-s.right))),s.top>=i.bottom?a(h,i.bottom,h,s.top,s.top-i.bottom):i.top>=s.bottom?a(h,s.bottom,h,i.top,i.top-s.bottom):(a(h,Math.min(i.top,s.top),h,Math.max(i.top,s.top),Math.abs(i.top-s.top)),a(h,Math.min(i.bottom,s.bottom),h,Math.max(i.bottom,s.bottom),Math.abs(i.bottom-s.bottom)))}setHovered(e){this.hovered=e,this.callbacks.onHover?.(e),this.drawOutline(e,!1)}lock(e){this.locked=e,this.hovered=e,this.callbacks.onHover?.(null),this.outsideClickCount=0,this.drawOutline(e,!0),this.callbacks.onLock(e)}unlock(){this.locked=null,this.hovered=null,this.callbacks.onHover?.(null),this.clearMeasure(),this.outline.style.display="none",this.chip.style.display="none",this.callbacks.onUnlock()}drawOutline(e,t){let r=e.getBoundingClientRect();this.outline.style.display="block",this.outline.className="pixelpeek-outline"+(t?" locked":""),this.outline.style.top=`${r.top}px`,this.outline.style.left=`${r.left}px`,this.outline.style.width=`${r.width}px`,this.outline.style.height=`${r.height}px`,this.chip.style.display="block",this.chip.className="pixelpeek-chip"+(t?" locked":""),this.chip.textContent=`${e.tagName.toLowerCase()} \xB7 ${Math.round(r.width)} \xD7 ${Math.round(r.height)}`;let n=r.top>20?r.top-20:r.bottom+4;this.chip.style.top=`${n}px`,this.chip.style.left=`${r.left}px`}};var K;function fn(o){if(K===void 0&&(K=document.createElement("canvas").getContext("2d",{willReadFrequently:!0})),!K||(K.clearRect(0,0,1,1),K.fillStyle="#010203",K.fillStyle=o,K.fillStyle==="#010203"))return null;K.fillRect(0,0,1,1);let[e,t,r,n]=K.getImageData(0,0,1,1).data;return{r:e,g:t,b:r,a:n/255}}function P(o){let e=o.trim().toLowerCase();if(!e)return null;if(e==="transparent")return{r:0,g:0,b:0,a:0};let t=e.match(/^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)$/);if(t){let n=t[4]===void 0?1:t[4].endsWith("%")?parseFloat(t[4])/100:parseFloat(t[4]);return{r:+t[1],g:+t[2],b:+t[3],a:n}}let r=e.match(/^#([0-9a-f]{3,8})$/);if(r){let n=r[1];if((n.length===3||n.length===4)&&(n=[...n].map(i=>i+i).join("")),n.length===6||n.length===8)return{r:parseInt(n.slice(0,2),16),g:parseInt(n.slice(2,4),16),b:parseInt(n.slice(4,6),16),a:n.length===8?parseInt(n.slice(6,8),16)/255:1}}return fn(e)}var Re=o=>Math.max(0,Math.min(255,Math.round(o))).toString(16).padStart(2,"0");function F({r:o,g:e,b:t,a:r}){return`#${Re(o)}${Re(e)}${Re(t)}${r<1?Re(r*255):""}`.toUpperCase()}function Nt({h:o,s:e,l:t}){let r=(1-Math.abs(2*t-1))*e,n=r*(1-Math.abs(o/60%2-1)),i=t-r/2,[s,p,a]=o<60?[r,n,0]:o<120?[n,r,0]:o<180?[0,r,n]:o<240?[0,n,r]:o<300?[n,0,r]:[r,0,n];return{r:(s+i)*255,g:(p+i)*255,b:(a+i)*255,a:1}}function Pe(o,e){let t=o.a+e.a*(1-o.a);if(t===0)return{r:0,g:0,b:0,a:0};let r=(n,i)=>(n*o.a+i*e.a*(1-o.a))/t;return{r:r(o.r,e.r),g:r(o.g,e.g),b:r(o.b,e.b),a:t}}function Ot({r:o,g:e,b:t}){let r=n=>{let i=n/255;return i<=.03928?i/12.92:((i+.055)/1.055)**2.4};return .2126*r(o)+.7152*r(e)+.0722*r(t)}function Vt(o,e){let t=Ot(o),r=Ot(e);return(Math.max(t,r)+.05)/(Math.min(t,r)+.05)}var bn={r:255,g:255,b:255,a:1},vn=/(rgba?\([^)]+\)|hsla?\([^)]+\)|#[0-9a-fA-F]{3,8}\b)/g;function jt(o,e){if(!o.includes("gradient("))return[];let t=[];for(let r of o.matchAll(vn)){let n=P(r[1]);n&&n.a>0&&t.push(n.a<1?Pe(n,e):n)}return t}function Ie(o,e=new WeakMap){let t=e.get(o);if(t)return t;let r=getComputedStyle(o),n=P(r.backgroundColor),i=r.backgroundImage!=="none",s=o.parentElement,p=i&&r.backgroundImage.includes("url("),a;if(n&&n.a>=1){let l=i&&!p?jt(r.backgroundImage,n):[];a=l.length?{color:l[0],stops:l,onImage:!1}:{color:n,onImage:p}}else{let l=s?Ie(s,e):{color:bn,onImage:!1},c=n&&n.a>0?Pe(n,l.color):l.color,d=i&&!p?jt(r.backgroundImage,c):[];a=d.length?{color:d[0],stops:d,onImage:l.onImage}:{color:c,onImage:p||l.onImage,stops:l.stops}}return e.set(o,a),a}function xn(o,e){return o>=24||o>=18.66&&e>=700}function pt(o,e,t,r){let n=e.stops&&e.stops.length?e.stops:[e.color],i=n[0],s=1/0,p=o;for(let l of n){let c=o.a<1?Pe(o,l):o,d=Vt(c,l);d<s&&(s=d,i=l,p=c)}let a=xn(t,r);return{ratio:s,gradient:n.length>1,fg:F({...p,a:1}),bg:F({...i,a:1}),large:a,aa:s>=(a?3:4.5),aaa:s>=(a?4.5:7),onImage:e.onImage}}var yn=new Set(["INPUT","BUTTON","TEXTAREA","SELECT"]);function oe(o){if(yn.has(o.tagName))return!0;for(let e of Array.from(o.childNodes))if(e.nodeType===Node.TEXT_NODE&&e.textContent?.trim())return!0;return!1}function ze(o,e,t){if(!oe(o))return;let r=P(e.color);if(!(!r||r.a===0))return pt(r,Ie(o,t),parseFloat(e.fontSize)||16,parseInt(e.fontWeight,10)||400)}var wn=3e3,$n=new Set(["SCRIPT","STYLE","NOSCRIPT","LINK","META","TEMPLATE","BR","WBR"]),kn=new Set(["path","circle","rect","ellipse","polygon","polyline","line","g","text","use"]),Sn=/(rgba?\([^)]+\)|hsla?\([^)]+\)|#[0-9a-fA-F]{3,8}\b)/g;function Ut(o){let e=new Map,t=(n,i,s)=>{let p=P(n);if(!p||p.a===0)return;let a=F(p),l=e.get(a)??{count:0,roles:new Set,own:!1};l.count++,l.roles.add(i),l.own=l.own||s,e.set(a,l)},r=[o,...Array.from(o.querySelectorAll("*")).slice(0,wn)];for(let n of r){if($n.has(n.tagName)||n.id===R)continue;let i=getComputedStyle(n);if(i.display==="none")continue;let s=n===o;if(n instanceof SVGElement&&kn.has(n.tagName.toLowerCase())){i.fill!=="none"&&t(i.fill,"icon",s),i.stroke!=="none"&&t(i.stroke,"icon",s);continue}t(i.backgroundColor,"background",s);let a=new Set;for(let l of["top","right","bottom","left"])parseFloat(i.getPropertyValue(`border-${l}-width`))>0&&i.getPropertyValue(`border-${l}-style`)!=="none"&&a.add(i.getPropertyValue(`border-${l}-color`));if(a.forEach(l=>t(l,"border",s)),i.backgroundImage.includes("gradient("))for(let l of i.backgroundImage.matchAll(Sn))t(l[1],"gradient",s);oe(n)&&t(i.color,"text",s)}return Array.from(e,([n,i])=>({hex:n,count:i.count,roles:Array.from(i.roles),own:i.own})).sort((n,i)=>Number(i.own)-Number(n.own)||i.count-n.count)}function ne(o,e=","){let t=[],r=0,n="";for(let i of o)i==="("&&r++,i===")"&&r--,i===e&&r===0?(t.push(n),n=""):n+=i;return n.trim()&&t.push(n),t.map(i=>i.trim())}var xe=/rgba?\([^)]*\)|#[0-9a-fA-F]{3,8}\b/;function z(o){let e=o.match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)/);if(!e)return o;let t=n=>Math.round(n).toString(16).padStart(2,"0"),r=`#${t(+e[1])}${t(+e[2])}${t(+e[3])}`;if(e[4]!==void 0){let n=e[4].endsWith("%")?parseFloat(e[4])/100:parseFloat(e[4]);n<1&&(r+=t(n*255))}return r.toUpperCase()}function lt(o){return o!==""&&o!=="transparent"&&o!=="rgba(0, 0, 0, 0)"}function ce(o){return!o||o==="none"?[]:ne(o).map(e=>{let t=/\binset\b/.test(e),r=e.match(xe),n=r?r[0]:"",s=(e.replace(n,"").replace(/\binset\b/,"").match(/-?\d*\.?\d+(?:px)?/g)??[]).map(d=>d.endsWith("px")?d:`${d}px`),[p="0px",a="0px",l="0px",c="0px"]=s;return{type:t?"Inner":"Drop",x:p,y:a,blur:l,spread:c,color:n?z(n):"transparent"}})}var Cn={"to top":0,"to right":90,"to bottom":180,"to left":270,"to top right":45,"to right top":45,"to bottom right":135,"to right bottom":135,"to bottom left":225,"to left bottom":225,"to top left":315,"to left top":315};function ye(o){return`${Math.round(o*100)/100}deg`}function En(o){let e=Cn[o.trim()];if(e!==void 0)return ye(e);let t=o.match(/^(-?[\d.]+)(deg|turn|rad|grad)$/);if(!t)return o;let r=parseFloat(t[1]);switch(t[2]){case"turn":return ye(r*360);case"rad":return ye(r*180/Math.PI);case"grad":return ye(r*.9);default:return ye(r)}}function Tn(o){let e=o.match(/^(repeating-)?(linear|radial|conic)-gradient\((.*)\)$/s);if(!e||e[1]||e[2]==="conic")return{type:"Other",stops:[],raw:o};let t=e[2]==="linear"?"Linear":"Radial",r=ne(e[3]),n;if(r.length&&!xe.test(r[0])){let s=r.shift();t==="Linear"&&(n=En(s))}else t==="Linear"&&(n="180deg");let i=r.map(s=>{let p=s.match(xe);if(!p)return{color:s};let a=s.replace(p[0],"").trim();return{color:z(p[0]),position:a||void 0}});return{type:t,angle:n,stops:i,raw:o}}function de(o){return!o||o==="none"?[]:ne(o).filter(e=>e.includes("gradient(")).map(Tn)}var E=o=>parseFloat(o)||0,ue=o=>String(Math.round(o*100)/100),q=o=>`[${ue(o)}px]`;function j(o){return o===1?"px":o%4===0&&o<=384||o%2===0&&o<16?ue(o/4):q(o)}var Mn=o=>o.replace(/\s+/g,"_"),Gt={12:"xs",14:"sm",16:"base",18:"lg",20:"xl",24:"2xl",30:"3xl",36:"4xl",48:"5xl",60:"6xl",72:"7xl",96:"8xl",128:"9xl"},Wt={100:"thin",200:"extralight",300:"light",400:"normal",500:"medium",600:"semibold",700:"bold",800:"extrabold",900:"black"},Kt={1:"none","1.25":"tight","1.375":"snug","1.5":"normal","1.625":"relaxed",2:"loose"},qt={"-0.05":"tighter","-0.025":"tight","0.025":"wide","0.05":"wider","0.1":"widest"},An={2:"sm",4:"",6:"md",8:"lg",12:"xl",16:"2xl",24:"3xl"},Ln={"flex-start":"start",start:"start",center:"center","flex-end":"end",end:"end","space-between":"between","space-around":"around","space-evenly":"evenly"},Rn={"flex-start":"start",start:"start",center:"center","flex-end":"end",end:"end",baseline:"baseline",stretch:"stretch"},Pn=new Set([0,10,20,30,40,50]);function In(o){let e=(o.split(",")[0]??"").trim().replace(/^["']|["']$/g,"");return e?/mono|courier|consolas|menlo/i.test(e)?"font-mono":/^(serif|georgia|times)/i.test(e)?"font-serif":/^(ui-sans-serif|system-ui|-apple-system|blinkmacsystemfont|sans-serif|segoe ui|helvetica|arial)/i.test(e)?"font-sans":`font-[${e.replace(/\s+/g,"_")}]`:""}function Yt(o,e,t,r,n){if(!e&&!t&&!r&&!n)return[];if(e===t&&t===r&&r===n)return[`${o}-${j(e)}`];let i=[];return n===t&&n?i.push(`${o}x-${j(n)}`):(n&&i.push(`${o}l-${j(n)}`),t&&i.push(`${o}r-${j(t)}`)),e===r&&e?i.push(`${o}y-${j(e)}`):(e&&i.push(`${o}t-${j(e)}`),r&&i.push(`${o}b-${j(r)}`)),i}function Zt(o,e){if(e>=9999)return`${o}-full`;let t=An[e];return t!==void 0?t?`${o}-${t}`:o:`${o}-${q(e)}`}function zn(o){if(!o)return 0;let e=getComputedStyle(o);return o.getBoundingClientRect().width-E(e.paddingLeft)-E(e.paddingRight)-E(e.borderLeftWidth)-E(e.borderRightWidth)}function Fe(o,e){let t=[],r=o.getBoundingClientRect();if(e.display!=="inline"&&t.push(e.display==="none"?"hidden":e.display==="inline-block"?"inline-block":e.display),e.position!=="static"&&t.push(e.position),e.position!=="static"&&e.position!=="relative")for(let x of["top","right","bottom","left"]){let S=e[x];S&&S!=="auto"&&t.push(E(S)===0?`${x}-0`:`${x}-${q(E(S))}`)}let n=parseInt(e.zIndex,10);if(!Number.isNaN(n)&&n!==0&&t.push(Pn.has(n)?`z-${n}`:`z-[${n}]`),e.display.includes("flex")){e.flexDirection==="column"?t.push("flex-col"):e.flexDirection==="row-reverse"?t.push("flex-row-reverse"):e.flexDirection==="column-reverse"&&t.push("flex-col-reverse"),e.flexWrap==="wrap"&&t.push("flex-wrap");let x=Ln[e.justifyContent];x&&x!=="start"&&t.push(`justify-${x}`);let S=Rn[e.alignItems];S&&S!=="stretch"&&t.push(`items-${S}`)}if(e.display.includes("flex")||e.display.includes("grid")){let x=E(e.columnGap),S=E(e.rowGap);x&&x===S?t.push(`gap-${j(x)}`):(x&&t.push(`gap-x-${j(x)}`),S&&t.push(`gap-y-${j(S)}`))}let i=o.parentElement,s=i&&Math.abs(r.width-zn(i))<1.5&&e.display!=="inline",p=["IMG","VIDEO","CANVAS","IFRAME"].includes(o.tagName)||o instanceof SVGElement,a=["INPUT","SELECT","TEXTAREA"].includes(o.tagName),l=o.children.length>0||!!(o.textContent??"").trim();r.width&&(s?t.push("w-full"):(p||a||!l)&&t.push(`w-${q(r.width)}`)),r.height&&(p||!l&&e.display!=="inline")&&t.push(`h-${q(r.height)}`),t.push(...Yt("m",E(e.marginTop),E(e.marginRight),E(e.marginBottom),E(e.marginLeft))),t.push(...Yt("p",E(e.paddingTop),E(e.paddingRight),E(e.paddingBottom),E(e.paddingLeft)));let c=oe(o),d=c?In(e.fontFamily):"";d&&t.push(d);let h=c?E(e.fontSize):0;h&&t.push(Gt[h]?`text-${Gt[h]}`:`text-${q(h)}`);let m=c?parseInt(e.fontWeight,10):0;if(m&&m!==400&&t.push(Wt[m]?`font-${Wt[m]}`:`font-[${m}]`),c&&e.fontStyle==="italic"&&t.push("italic"),e.lineHeight!=="normal"&&h){let x=ue(E(e.lineHeight)/h);t.push(Kt[x]?`leading-${Kt[x]}`:`leading-${q(E(e.lineHeight))}`)}if(e.letterSpacing!=="normal"&&E(e.letterSpacing)&&h){let x=ue(Math.round(E(e.letterSpacing)/h*1e3)/1e3);t.push(qt[x]?`tracking-${qt[x]}`:`tracking-${q(E(e.letterSpacing))}`)}c&&!["start","left"].includes(e.textAlign)&&t.push(`text-${e.textAlign}`),c&&e.textTransform!=="none"&&t.push(e.textTransform==="capitalize"?"capitalize":e.textTransform),c&&e.textDecorationLine.includes("underline")&&t.push("underline"),c&&e.textDecorationLine.includes("line-through")&&t.push("line-through"),e.whiteSpace==="nowrap"&&t.push("whitespace-nowrap"),e.textOverflow==="ellipsis"&&e.whiteSpace==="nowrap"&&e.overflow!=="visible"&&t.push("truncate"),c&&t.push(`text-[${z(e.color)}]`);let v=z(e.backgroundColor);e.backgroundColor!=="rgba(0, 0, 0, 0)"&&e.backgroundColor!=="transparent"&&t.push(`bg-[${v}]`);let u=de(e.backgroundImage);u.length&&t.push(`bg-[${Mn(u.map(x=>x.raw).join(","))}]`);let g=["Top","Right","Bottom","Left"].map(x=>e.getPropertyValue(`border-${x.toLowerCase()}-style`)==="none"?0:E(e.getPropertyValue(`border-${x.toLowerCase()}-width`))),[y,$,k,I]=g,N=x=>x===1||x>0&&x<1?"":x===0?"-0":[2,4,8].includes(x)?`-${x}`:`-${q(x)}`;if(y||$||k||I){y===$&&$===k&&k===I?t.push(`border${N(y)}`):(y&&t.push(`border-t${N(y)}`),$&&t.push(`border-r${N($)}`),k&&t.push(`border-b${N(k)}`),I&&t.push(`border-l${N(I)}`)),(e.borderTopStyle==="dashed"||e.borderTopStyle==="dotted")&&t.push(`border-${e.borderTopStyle}`);let x=g.findIndex(ee=>ee>0),S=e.getPropertyValue(`border-${["top","right","bottom","left"][x]}-color`);t.push(`border-[${z(S)}]`)}let G=[E(e.borderTopLeftRadius),E(e.borderTopRightRadius),E(e.borderBottomRightRadius),E(e.borderBottomLeftRadius)];if(G.some(Boolean))if(G.every(x=>x===G[0])){let x=e.borderTopLeftRadius.endsWith("%")&&E(e.borderTopLeftRadius)>=50;t.push(Zt("rounded",x?9999:G[0]))}else["tl","tr","br","bl"].forEach((x,S)=>{G[S]&&t.push(Zt(`rounded-${x}`,G[S]))});let le=ce(e.boxShadow);le.length&&t.push(`shadow-[${le.map(x=>`${x.type==="Inner"?"inset_":""}${x.x}_${x.y}_${x.blur}${x.spread!=="0px"?`_${x.spread}`:""}_${x.color}`).join(",")}]`);let W=parseFloat(e.opacity);return W<1&&t.push(Math.round(W*100)%5===0?`opacity-${Math.round(W*100)}`:`opacity-[${ue(W)}]`),e.overflow!=="visible"&&t.push(`overflow-${e.overflow==="clip"?"clip":e.overflow}`),e.objectFit!=="fill"&&o.tagName==="IMG"&&t.push(`object-${e.objectFit}`),t.filter(Boolean)}var De=new Map,ct=new Map;function Xt(o){try{return o.cssRules,!0}catch{return!1}}function Jt(o){return[...Array.from(o.styleSheets),...o.adoptedStyleSheets??[]]}async function Fn(o,e){let t=new AbortController,r=setTimeout(()=>t.abort(),8e3);try{let n=await fetch(e,{mode:"cors",credentials:"omit",signal:t.signal});if(!n.ok)throw new Error(`HTTP ${n.status}`);let i=await n.text();if(i.length>8e6)throw new Error("too large");let s=new CSSStyleSheet({media:o.media.mediaText});await s.replace(i),De.set(e,s)}catch{De.set(e,null)}finally{clearTimeout(r)}}function he(o){let e=[];for(let t of Jt(o)){let r=t.href;if(!r||!/^https?:/.test(r)||Xt(t)||De.has(r))continue;let n=ct.get(r);n||(n=Fn(t,r).finally(()=>ct.delete(r)),ct.set(r,n)),e.push(n)}return Promise.all(e).then(()=>{})}function Y(o){let e=[],t=0;for(let r of Jt(o)){if(Xt(r)){e.push(r);continue}let n=r.href?De.get(r.href):null;n?e.push(n):t++}return{sheets:e,unreadable:t}}var V=o=>ne(o).map(e=>e.trim()),U=(o,e)=>o[e%o.length]??"",dt=new Map;function Qt(o,e,t=0){if(t>6)return null;for(let r of Array.from(e))try{if(r instanceof CSSKeyframesRule&&r.name===o)return{name:o,steps:Array.from(r.cssRules).map(i=>{let s=i;return{offset:s.keyText,css:s.style.cssText.trim()}})};let n=r.cssRules;if(n&&(r instanceof CSSMediaRule||r instanceof CSSSupportsRule)){let i=Qt(o,n,t+1);if(i)return i}}catch{}return null}function Dn(o){if(dt.has(o))return dt.get(o)??null;let e=null;for(let t of Y(document).sheets){try{e=Qt(o,t.cssRules)}catch{continue}if(e)break}return e&&dt.set(o,e),e}function _t(o){let e=[],t=V(o.transitionProperty),r=V(o.transitionDuration),n=V(o.transitionTimingFunction),i=V(o.transitionDelay);t.forEach((l,c)=>{let d=U(r,c);l==="none"||parseFloat(d)===0&&parseFloat(U(i,c))===0||e.push({property:l,duration:d,easing:U(n,c),delay:U(i,c)})});let s=[],p=[];if(V(o.animationName).forEach((l,c)=>{if(l==="none")return;s.push({name:l,duration:U(V(o.animationDuration),c),easing:U(V(o.animationTimingFunction),c),delay:U(V(o.animationDelay),c),iterations:U(V(o.animationIterationCount),c),direction:U(V(o.animationDirection),c),fill:U(V(o.animationFillMode),c)});let d=Dn(l);d&&p.push(d)}),!(!e.length&&!s.length))return{transitions:e,animations:s,keyframes:p}}var Z=o=>parseFloat(o)||0;function Hn(o){return/flex|grid/.test(o.display)}function oo(o){if(!o||o==="none")return;let e=o.match(/matrix(?:3d)?\(([^)]+)\)/);if(!e)return;let[t,r]=e[1].split(",").map(i=>parseFloat(i)),n=Math.round(Math.atan2(r,t)*180/Math.PI*100)/100;return n===0?void 0:`${n}deg`}function eo(o){return o==="center"?"center":/end|right/.test(o)&&!o.startsWith("space")?"end":"start"}function to(o){return o==="center"?"center":o==="baseline"||o==="first baseline"||o==="last baseline"?"baseline":/end/.test(o)?"end":o==="normal"||o==="stretch"?"stretch":"start"}function ut(o,e){let t={start:"Top",center:"Center",end:"Bottom"}[e],r={start:"left",center:"center",end:"right"}[o];return t==="Center"&&r==="center"?"Center":t==="Center"?`Center ${r}`:`${t} ${r}`}function no(o){if(!Hn(o))return;let e={top:Z(o.paddingTop),right:Z(o.paddingRight),bottom:Z(o.paddingBottom),left:Z(o.paddingLeft)},t=o.gap==="normal"?"0px":o.gap,r=/grid/.test(o.display),n=o.justifyContent,i=n.startsWith("space-")?`Space ${n.replace("space-","")}`:"Packed";if(r){let d=to(o.alignItems),h=eo(o.justifyItems==="normal"?"start":o.justifyItems);return{direction:"Grid",gap:t,align:ut(h,d==="stretch"||d==="baseline"?"start":d),distribute:"Packed",padding:e}}let s=o.flexDirection.startsWith("row"),p=eo(n),a=to(o.alignItems),l=a==="stretch"||a==="baseline"?"start":a,c=s?ut(p,l):ut(l,p);return{direction:s?"Horizontal":"Vertical",gap:t,align:a==="stretch"?`${c} (children stretch)`:c,distribute:i,padding:e}}var Bn=new Set(["img","video","canvas","svg","iframe","input","textarea","select"]);function ro(o,e,t,r){let n=o.tagName.toLowerCase(),i=o.style,s=r!==null&&/flex/.test(r.display),p=s&&r.flexDirection.startsWith("row"),a=Z(e.flexGrow),l=e.alignSelf==="auto"?r?.alignItems??"normal":e.alignSelf,c=l==="normal"||l==="stretch",d=/^(inline|inline-block|inline-flex|inline-grid|table-cell)$/.test(e.display),h=!t||!r?0:t.getBoundingClientRect().width-Z(r.paddingLeft)-Z(r.paddingRight)-Z(r.borderLeftWidth)-Z(r.borderRightWidth),m=o.getBoundingClientRect().width,v=u=>{let g=u==="width"?i.width:i.height;return g?g.endsWith("%")&&parseFloat(g)>=99?"Fill":"Fixed":Bn.has(n)?"Fixed":s?u==="width"===p?a>0?"Fill":e.flexBasis==="auto"?"Hug":"Fixed":c?"Fill":"Hug":d?"Hug":u==="width"?Math.abs(m-h)<=1?"Fill":"Fixed":"Hug"};return{width:v("width"),height:v("height")}}var On=0,X=o=>parseFloat(o)||0;function ht(o,e){let t=e==="border"?"-width":"";return{top:X(o.getPropertyValue(`${e}-top${t}`)),right:X(o.getPropertyValue(`${e}-right${t}`)),bottom:X(o.getPropertyValue(`${e}-bottom${t}`)),left:X(o.getPropertyValue(`${e}-left${t}`))}}function so(o){if(o.id)return`#${o.id}`;let e=Array.from(o.classList).slice(0,2).join(".");return e?`${o.tagName.toLowerCase()}.${e}`:o.tagName.toLowerCase()}function Nn(o){let e=[],t=o;for(;t&&t.tagName!=="HTML";)e.unshift(so(t)),t=t.parentElement;return e}function Vn(o){if(o%100>=11&&o%100<=13)return"th";switch(o%10){case 1:return"st";case 2:return"nd";case 3:return"rd";default:return"th"}}function jn(o,e){let t=Array.from(e.children),r=t.indexOf(o)+1;return`${r}${Vn(r)} of ${t.length}`}function io(o,e,t){let r=o.getBoundingClientRect(),n=e.getBoundingClientRect(),i=t==="vertical"?n.top-r.bottom:n.left-r.right;return`${Math.round(i)}px`}var Un=new Set(["p","h1","h2","h3","h4","h5","h6","li","blockquote"]);function Gn(o){let e=o.getPropertyValue("-webkit-line-clamp");return e&&e!=="none"?`${e} lines, then ellipsis`:o.textOverflow==="ellipsis"&&o.whiteSpace==="nowrap"&&o.overflow!=="visible"?"single line, ellipsis":"none"}var Wn=o=>{let e=parseFloat(o);return e>0&&e<1?"1px":o};function He(o,e){let t=e[0].toUpperCase()+e.slice(1),r=n=>o.getPropertyValue(`border-${e}-${n}`)||o.getPropertyValue(`border${t}${n}`);return{width:Wn(r("width")),style:r("style"),color:z(r("color"))}}var Kn=[["font-family",[]],["font-size",[]],["font-weight",[]],["line-height",["normal"]],["letter-spacing",["normal"]],["text-align",[]],["text-decoration-line",["none"]],["text-transform",["none"]],["color",[]],["background-color",["rgba(0, 0, 0, 0)"]],["background-image",["none"]],["border-top",[]],["border-right",[]],["border-bottom",[]],["border-left",[]],["border-radius",["0px"]],["box-shadow",["none"]],["opacity",["1"]],["margin",["0px"]],["padding",["0px"]],["width",[]],["height",[]],["position",["static"]],["display",[]],["transform",["none"]],["overflow",["visible"]],["z-index",["auto"]]];function qn(o){let e=[];for(let[t,r]of Kn){let n=o.getPropertyValue(t).trim();!n||r.includes(n)||t.startsWith("border-")&&t!=="border-radius"&&n.startsWith("0px none")||e.push(`${t}: ${t.startsWith("border-")&&t!=="border-radius"?n.replace(/^0\.\d+px/,"1px"):n};`)}return e}function Yn(o){let e=Array.from(o.childNodes).filter(t=>t.nodeType===Node.TEXT_NODE).map(t=>t.textContent??"").join(" ").replace(/\s+/g," ").trim();return e?e.slice(0,120):void 0}function gt(o){let e=getComputedStyle(o),t=o.getBoundingClientRect(),r=o.parentElement,n=r?getComputedStyle(r):null,i=o instanceof SVGElement&&e.stroke!=="none"&&parseFloat(e.strokeWidth)>0?{width:`${Math.round(parseFloat(e.strokeWidth)*100)/100}px`,style:"solid",color:z(e.stroke)}:null,s=i?{top:i,right:i,bottom:i,left:i}:{top:He(e,"top"),right:He(e,"right"),bottom:He(e,"bottom"),left:He(e,"left")},p=Object.values(s).some(g=>X(g.width)>0&&g.style!=="none"),a=Object.values(s).find(g=>X(g.width)>0&&g.style!=="none"),l=[];lt(e.backgroundColor)&&l.push({role:"background",value:e.backgroundColor}),lt(e.color)&&l.push({role:"text",value:e.color}),a&&l.push({role:"border",value:a.color});let c;r&&n&&(c={display:n.display,direction:n.display.includes("flex")?n.flexDirection:void 0,gap:/flex|grid/.test(n.display)?n.gap:void 0,childIndex:jn(o,r)});let d,h=o.previousElementSibling,m=o.nextElementSibling;if(h||m){let g=c?.direction?.startsWith("row")?"horizontal":"vertical";d={previous:h?io(h,o,g):void 0,next:m?io(o,m,g):void 0}}let v=r?.getBoundingClientRect(),u={x:Math.round((t.left-(v?.left??0)-(n?X(n.borderLeftWidth):0))*10)/10,y:Math.round((t.top-(v?.top??0)-(n?X(n.borderTopWidth):0))*10)/10};return{id:`pp-${On++}`,selector:so(o),tagName:o.tagName.toLowerCase(),domPath:Nn(o),text:Yn(o),layout:{typography:{fontFamily:e.fontFamily,fontSize:e.fontSize,lineHeight:e.lineHeight,fontWeight:e.fontWeight,color:e.color,letterSpacing:e.letterSpacing,textAlign:e.textAlign,textDecoration:e.textDecorationLine,textTransform:e.textTransform,truncation:Gn(e),paragraphSpacing:Un.has(o.tagName.toLowerCase())&&X(e.marginBottom)>0?e.marginBottom:void 0},colors:l,palette:Ut(o),contrast:ze(o,e),fills:de(e.backgroundImage),stroke:p?s:void 0,cornerRadius:{topLeft:e.borderTopLeftRadius,topRight:e.borderTopRightRadius,bottomRight:e.borderBottomRightRadius,bottomLeft:e.borderBottomLeftRadius},effects:{opacity:e.opacity!=="1"?e.opacity:void 0,shadows:ce(e.boxShadow)},boxModel:{margin:ht(e,"margin"),border:ht(e,"border"),padding:ht(e,"padding"),content:{width:Math.round(t.width),height:Math.round(t.height)}},position:e.position,offset:u,rotation:oo(e.transform),display:e.display,parentContext:c,autoLayout:n?no(n):void 0,resize:ro(o,e,r,n),siblingSpacing:d,animation:_t(e),tailwind:Fe(o,e),rawCss:qn(e)}}}function H(o){return o.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}async function we(o){await navigator.clipboard.writeText(o)}var Zn=(()=>{let o=new Uint32Array(256);for(let e=0;e<256;e++){let t=e;for(let r=0;r<8;r++)t=t&1?3988292384^t>>>1:t>>>1;o[e]=t>>>0}return o})();function Xn(o){let e=4294967295;for(let t=0;t<o.length;t++)e=Zn[(e^o[t])&255]^e>>>8;return(e^4294967295)>>>0}function Jn(o){return{time:o.getHours()<<11|o.getMinutes()<<5|o.getSeconds()>>1,day:Math.max(o.getFullYear(),1980)-1980<<9|o.getMonth()+1<<5|o.getDate()}}function ao(o){let e=new TextEncoder,{time:t,day:r}=Jn(new Date),n=[],i=[],s=0,p=0;for(let l of o){let c=e.encode(l.name),d=Xn(l.data),h=l.data.length,m=new DataView(new ArrayBuffer(30));m.setUint32(0,67324752,!0),m.setUint16(4,20,!0),m.setUint16(6,2048,!0),m.setUint16(8,0,!0),m.setUint16(10,t,!0),m.setUint16(12,r,!0),m.setUint32(14,d,!0),m.setUint32(18,h,!0),m.setUint32(22,h,!0),m.setUint16(26,c.length,!0),n.push(m.buffer,c,l.data);let v=new DataView(new ArrayBuffer(46));v.setUint32(0,33639248,!0),v.setUint16(4,20,!0),v.setUint16(6,20,!0),v.setUint16(8,2048,!0),v.setUint16(10,0,!0),v.setUint16(12,t,!0),v.setUint16(14,r,!0),v.setUint32(16,d,!0),v.setUint32(20,h,!0),v.setUint32(24,h,!0),v.setUint16(28,c.length,!0),v.setUint32(42,s,!0),i.push(v.buffer,c),p+=46+c.length,s+=30+c.length+h}let a=new DataView(new ArrayBuffer(22));return a.setUint32(0,101010256,!0),a.setUint16(8,o.length,!0),a.setUint16(10,o.length,!0),a.setUint32(12,p,!0),a.setUint32(16,s,!0),new Blob([...n,...i,a.buffer],{type:"application/zip"})}function mt(o,e){let t=URL.createObjectURL(o),r=document.createElement("a");r.href=t,r.download=e,r.rel="noopener",r.click(),setTimeout(()=>URL.revokeObjectURL(t),1e4)}function Be(o,e,t="text/plain"){mt(new Blob([o],{type:`${t};charset=utf-8`}),e)}var Qn=12e3;async function ge(o){let e=new AbortController,t=setTimeout(()=>e.abort(),Qn);try{let r=await fetch(o,{credentials:"omit",signal:e.signal});return r.ok?await r.blob():null}catch{return null}finally{clearTimeout(t)}}async function po(o){return o.svg?new Blob([o.svg],{type:"image/svg+xml"}):o.url?ge(o.url):null}async function lo(o){let e=await po(o);if(e)return mt(e,o.filename),!0;if(o.url){let t=document.createElement("a");t.href=o.url,t.target="_blank",t.rel="noopener",t.click()}return!1}async function co(o,e,t){let r=[],n=new Set,i=0,s=0,p=[...o],a=async()=>{for(let l=p.shift();l;l=p.shift()){let c=await po(l);if(c){let d=l.filename;for(let h=2;n.has(d);h++)d=l.filename.replace(/(\.[^.]*)?$/,`-${h}$1`);n.add(d),r.push({name:d,data:new Uint8Array(await c.arrayBuffer())})}else i++;t?.(++s,o.length)}};return await Promise.all(Array.from({length:5},a)),r.length&&mt(ao(r),e),{saved:r.length,skipped:i}}var uo=400,ho=/^(:root|html|body|:host)$/i,_n=/(\.dark\b|\.theme-dark\b|\.dark-mode\b|\[data-(?:bs-)?(?:theme|mode|color-scheme)\s*[~^$*|]?=\s*["']?dark["']?\])/i,go=/^--(tw-|webkit|moz|radix-|swiper-|wp-|cmdk-|sb-)/i,er=/^(\d+(?:\.\d+)?)(?:deg)?\s+(\d+(?:\.\d+)?)%\s+(\d+(?:\.\d+)?)%(?:\s*\/\s*[\d.]+%?)?$/;function $e(o){let e=o.trim().match(er);if(e)return F(Nt({h:parseFloat(e[1]),s:parseFloat(e[2])/100,l:parseFloat(e[3])/100}));let t=P(o);return t&&t.a>0?F(t):null}function mo(o,e){return $e(e)?"color":/^-?[\d.]+(px|rem|em|%|vw|vh|ch)$/.test(e)||/^calc\(/.test(e)?"dimension":/shadow|elevation/i.test(o)||/\d+(px|rem)\s+-?\d+(px|rem).*(rgba?\(|hsla?\(|#)/.test(e)?"shadow":/font|family/i.test(o)&&!/size|weight|height/i.test(o)||/,\s*(sans-serif|serif|monospace|system-ui|ui-)/i.test(e)?"font":"other"}function tr(o,e){let t=o.split(",").map(n=>n.trim()),r=null;for(let n of t)ho.test(n)&&!e?r=r??"light":(ho.test(n)&&e||_n.test(n)&&/^(:root|html|body|\.dark|\.theme-dark|\.dark-mode|\[|:host)/i.test(n)||e&&/^(:root|html|body)(:not\([^)]*\)|\[[^\]]*\])*$/i.test(n))&&(r="dark");return r}function Oe(o,e,t,r){for(let n of Array.from(o))if(n instanceof CSSStyleRule){let i=tr(n.selectorText,e);if(!i)continue;let s=i==="dark"?r:t;for(let p=0;p<n.style.length;p++){let a=n.style[p];a.startsWith("--")&&s.set(a,n.style.getPropertyValue(a).trim())}}else if(n instanceof CSSMediaRule){let i=n.conditionText||n.media.mediaText;/prefers-color-scheme\s*:\s*dark/i.test(i)?Oe(n.cssRules,!0,t,r):(/prefers-color-scheme\s*:\s*light/i.test(i)||/^\s*(all|screen)\s*$/i.test(i))&&Oe(n.cssRules,e,t,r)}else"cssRules"in n&&(n instanceof CSSSupportsRule||n.constructor.name==="CSSLayerBlockRule")&&Oe(n.cssRules,e,t,r)}function fo(){let o=new Map,e=new Map;for(let i of Y(document).sheets)try{Oe(i.cssRules,!1,o,e)}catch{}let t=document.documentElement.style;for(let i=0;i<t.length;i++){let s=t[i];s.startsWith("--")&&o.set(s,t.getPropertyValue(s).trim())}let r=getComputedStyle(document.documentElement),n=[];for(let[i,s]of o){if(go.test(i)||!s)continue;let p=r.getPropertyValue(i).trim()||s,a=s.match(/^var\(\s*(--[\w-]+)\s*(?:,[^)]*)?\)$/)?.[1];if(n.push({name:i,kind:mo(i,p),value:s,resolved:p,alias:a,dark:e.get(i)}),n.length>=uo)break}for(let[i,s]of e){if(o.has(i)||go.test(i)||n.length>=uo)continue;let p=r.getPropertyValue(i).trim()||s;n.push({name:i,kind:mo(i,p),value:p,resolved:p,dark:s})}return n}function yo(o){let e=o.replace(/\s+/g," ").trim().toLowerCase(),t=e.match(/(rgba?\([^)]*\)|hsla?\([^)]*\)|#[0-9a-f]{3,8}\b)/)?.[1],r=t?P(t):null;if(!r||!/\d+(px)?\s+-?\d+/.test(e.replace(t,"")))return e;let n=(e.replace(t,"").match(/-?\d*\.?\d+/g)??[]).map(Number);for(;n.length<4;)n.push(0);return`shadow:${n.slice(0,4).join(",")}|${F(r)}${r.a<1?`@${r.a}`:""}`}function or(o){let e=new Map,t=new Map,r=(n,i,s)=>{let p=n.get(i)??[];p.length<6&&!p.includes(s)&&p.push(s),n.set(i,p)};for(let n of o)if(n.kind==="color"){let i=$e(n.resolved);i&&r(e,i,n.name)}else r(t,yo(n.resolved),n.name);return{color:e,other:t}}var nr={H1:"H1",H2:"H2",H3:"H3",H4:"H4",H5:"H5",H6:"H6",BUTTON:"Button",INPUT:"Input",TEXTAREA:"Input",SELECT:"Input",A:"Link",LABEL:"Label",LI:"List item",TD:"Table cell",TH:"Table head"};function rr(o){let e=o.textStyles.filter(n=>n.size>=8&&n.size<=200).slice(0,16),t=new Map;return e.map(n=>{let i=Object.entries(n.tags).sort((p,a)=>a[1]-p[1])[0]?.[0]??"",s=nr[i]??"Text";return t.set(s,(t.get(s)??0)+1),{base:s,style:n}}).sort((n,i)=>i.style.size-n.style.size||i.style.count-n.style.count).map(({base:n,style:i})=>({name:(t.get(n)??0)>1?`${n} ${Math.round(i.size*10)/10}/${i.weight}`:n,family:i.family,size:`${Math.round(i.size*10)/10}px`,weight:i.weight,lineHeight:i.lineHeight,letterSpacing:i.letterSpacing,count:i.count}))}var bo=o=>{let e=o.match(/(-?[\d.]+)px\s+(-?[\d.]+)px\s+([\d.]+)px/);return e?parseFloat(e[3]):0},vo=/radius|rounded|corner/i,xo=/space|spacing|gap|pad|margin|inset|gutter/i,Ne=o=>parseFloat(o)||0;function wo(o){let e=or(o.tokens),t=(a,l)=>(e.other.get(yo(a))??[]).filter(c=>!l||l.test(c)),r=o.colors.map(a=>({hex:a.hex,count:a.count,surface:a.background,text:a.text,border:a.border,icon:a.icon,tokens:e.color.get(a.hex)??[]})),n=o.shadows.slice(0,6).sort((a,l)=>bo(a.value)-bo(l.value)).map((a,l)=>{let c=t(a.value);return{name:c[0]??`Shadow ${l+1}`,value:a.value,count:a.count,tokens:c}}),i=o.radii.slice(0,10).sort((a,l)=>Ne(a.value)-Ne(l.value)).map(a=>({name:t(a.value,vo)[0]??a.value,value:a.value,count:a.count,tokens:t(a.value,vo)})),s=o.spacing.slice(0,14).filter(a=>Number.isInteger(parseFloat(a.value)*2)).sort((a,l)=>Ne(a.value)-Ne(l.value)).map(a=>({name:t(a.value,xo)[0]??a.value,value:a.value,count:a.count,tokens:t(a.value,xo)})),p=o.gradients.slice(0,6).map((a,l)=>{let c=t(a.value);return{name:c[0]??`Gradient ${l+1}`,value:a.value,count:a.count,tokens:c}});return{source:{url:o.url,title:o.title},tokens:o.tokens,colors:r,fonts:o.fonts.map(a=>({family:a.family,weights:a.weights,source:a.source})),textStyles:rr(o),shadows:n,radii:i,spacing:s,gradients:p}}var bt={css:"CSS vars",tailwind:"Tailwind v4",scss:"SCSS",dtcg:"DTCG",json:"JSON",md:"DESIGN.md"},me=o=>o.replace(/^--/,""),J=o=>o.toLowerCase().replace(/#/g,"").replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,""),$o=o=>/[\s,]/.test(o)?`"${o}"`:o;function Ve(o,e){return e==="dark"?o.tokens.filter(t=>t.dark).map(t=>[me(t.name),t.dark]):o.tokens.map(t=>[me(t.name),t.value])}function ft(o){let e=new Set(o.tokens.map(n=>me(n.name))),t=[],r=(n,i)=>{e.has(n)||t.push([n,i])};for(let n of o.colors)n.tokens.length||r(`color-${J(n.hex)}`,n.hex);return o.fonts.forEach(n=>r(`font-${J(n.family)}`,$o(n.family))),o.shadows.forEach((n,i)=>!n.tokens.length&&r(`shadow-${i+1}`,n.value)),o.radii.forEach(n=>!n.tokens.length&&r(`radius-${J(n.value)}`,n.value)),o.spacing.forEach(n=>!n.tokens.length&&r(`space-${J(n.value)}`,n.value)),o.gradients.forEach((n,i)=>!n.tokens.length&&r(`gradient-${i+1}`,n.value)),t}var vt=(o,e)=>e.length?`${o} {
${e.map(([t,r])=>`  --${t}: ${r};`).join(`
`)}
}
`:"",je=o=>`Read by PixelPeek from ${o.source.url}`,ko=o=>{let e=Ve(o,"dark");return e.length?`
${vt(".dark",e)}`:""};function ir(o){return`/* ${je(o)} */
${vt(":root",[...Ve(o,"light"),...ft(o)])}${ko(o)}`}function sr(o){let e=n=>Object.fromEntries(n.map(([i,s,p])=>[i,{$value:s,$type:p}])),t=n=>({color:"color",dimension:"dimension",font:"fontFamily",shadow:"shadow"})[n]??"string",r={$description:je(o),declared:e(o.tokens.map(n=>[me(n.name),n.alias?`{declared.${me(n.alias)}}`:n.value,t(n.kind)])),color:e(o.colors.filter(n=>!n.tokens.length).map(n=>[J(n.hex),n.hex,"color"])),fontFamily:e(o.fonts.map(n=>[J(n.family),$o(n.family),"fontFamily"])),textStyle:Object.fromEntries(o.textStyles.map(n=>[J(n.name),{$type:"typography",$value:{fontFamily:n.family,fontSize:n.size,fontWeight:n.weight,lineHeight:n.lineHeight,letterSpacing:n.letterSpacing}}])),shadow:e(o.shadows.map((n,i)=>[n.tokens[0]?me(n.tokens[0]):`shadow-${i+1}`,n.value,"shadow"])),radius:e(o.radii.map(n=>[J(n.value),n.value,"dimension"])),spacing:e(o.spacing.map(n=>[J(n.value),n.value,"dimension"]))};return JSON.stringify(r,null,2)}function ar(o){let e=["# Design system","",`Read from ${o.source.url}${o.source.title?` ("${o.source.title}")`:""} with PixelPeek. Every value is taken from the page.`];if(o.tokens.length){e.push("","## Variables declared by the site","","| Name | Value | Dark |","| --- | --- | --- |");for(let t of o.tokens)e.push(`| \`${t.name}\` | \`${t.value}\`${t.alias?"":t.resolved!==t.value?` \u2192 \`${t.resolved}\``:""} | ${t.dark?`\`${t.dark}\``:""} |`)}e.push("","## Colors in use","","| Color | Surface | Text | Border | Icon | Token |","| --- | --- | --- | --- | --- | --- |");for(let t of o.colors.slice(0,40))e.push(`| ${t.hex} | ${t.surface} | ${t.text} | ${t.border} | ${t.icon} | ${t.tokens.map(r=>`\`${r}\``).join(", ")} |`);if(o.textStyles.length){e.push("","## Text styles","","| Style | Font | Size | Weight | Line height | Letter spacing |","| --- | --- | --- | --- | --- | --- |");for(let t of o.textStyles)e.push(`| ${t.name} | ${t.family} | ${t.size} | ${t.weight} | ${t.lineHeight} | ${t.letterSpacing} |`)}return o.shadows.length&&e.push("","## Effect styles (shadows)","",...o.shadows.map(t=>`- ${t.name}: \`${t.value}\``)),o.radii.length&&e.push("","## Corner radius","",...o.radii.map(t=>`- ${t.name}${t.name!==t.value?`: ${t.value}`:""} (${t.count}\xD7)`)),o.spacing.length&&e.push("","## Spacing in use","",...o.spacing.map(t=>`- ${t.name}${t.name!==t.value?`: ${t.value}`:""} (${t.count}\xD7)`)),o.gradients.length&&e.push("","## Gradients","",...o.gradients.map(t=>`- ${t.name}: \`${t.value}\``)),`${e.join(`
`)}
`}function Ue(o,e){let t=bt[e];switch(e){case"css":return{label:t,filename:"tokens.css",mime:"text/css",text:ir(o)};case"tailwind":return{label:t,filename:"theme.css",mime:"text/css",text:`/* ${je(o)} */
@import "tailwindcss";

${vt("@theme",[...Ve(o,"light"),...ft(o)])}${ko(o)}`};case"scss":return{label:t,filename:"tokens.scss",mime:"text/x-scss",text:`// ${je(o)}
${[...Ve(o,"light"),...ft(o)].map(([r,n])=>`$${r}: ${n};`).join(`
`)}
`};case"dtcg":return{label:t,filename:"tokens.json",mime:"application/json",text:sr(o)};case"json":return{label:t,filename:"design-system.json",mime:"application/json",text:JSON.stringify(o,null,2)};case"md":return{label:t,filename:"DESIGN.md",mime:"text/markdown",text:ar(o)}}}var ke="pixelpeek-library",pr=300,So=()=>typeof chrome<"u"&&!!chrome.storage?.local;async function xt(){try{return So()?(await chrome.storage.local.get(ke))[ke]??[]:JSON.parse(localStorage.getItem(ke)??"[]")}catch{return[]}}async function yt(o){So()?await chrome.storage.local.set({[ke]:o}):localStorage.setItem(ke,JSON.stringify(o))}function Co(){return xt()}async function wt(o,e){let{layout:t}=o,r={id:`${Date.now()}-${Math.random().toString(36).slice(2,7)}`,savedAt:Date.now(),url:e.url,title:e.title,selector:o.selector,tagName:o.tagName,width:t.boxModel.content.width,height:t.boxModel.content.height,text:o.text,tailwind:t.tailwind,css:t.rawCss,colors:t.colors.map(i=>({role:i.role,value:z(i.value)})),font:t.typography?.fontFamily},n=await xt();return await yt([r,...n].slice(0,pr)),r}async function Eo(o){await yt((await xt()).filter(e=>e.id!==o))}async function To(){await yt([])}var T=(o,e,t,r,n,i)=>({id:o,name:e,category:t,width:r,height:n,frame:i}),Ge=[T("responsive","Responsive","responsive",390,780,"plain"),T("iphone-16-pro-max","iPhone 16 Pro Max","phones",440,956,"island"),T("iphone-16-pro","iPhone 16 Pro","phones",402,874,"island"),T("iphone-16-plus","iPhone 16 Plus","phones",430,932,"island"),T("iphone-16","iPhone 16","phones",393,852,"island"),T("iphone-15-pro","iPhone 15 Pro","phones",393,852,"island"),T("iphone-14","iPhone 14","phones",390,844,"notch"),T("iphone-13-mini","iPhone 13 mini","phones",375,812,"notch"),T("iphone-se","iPhone SE","phones",375,667,"home"),T("pixel-9-pro","Pixel 9 Pro","phones",412,915,"punch"),T("pixel-8","Pixel 8","phones",412,915,"punch"),T("pixel-7","Pixel 7","phones",412,915,"punch"),T("galaxy-s24","Galaxy S24","phones",360,780,"punch"),T("galaxy-s24-ultra","Galaxy S24 Ultra","phones",384,824,"punch"),T("galaxy-s23","Galaxy S23","phones",360,780,"punch"),T("galaxy-z-fold-5","Galaxy Z Fold 5 (folded)","phones",344,882,"fold"),T("ipad-pro-13",'iPad Pro 13"',"tablets",1032,1376,"tablet"),T("ipad-pro-11",'iPad Pro 11"',"tablets",834,1194,"tablet"),T("ipad-air","iPad Air","tablets",820,1180,"tablet"),T("ipad-mini","iPad mini","tablets",744,1133,"tablet"),T("galaxy-tab-s9","Galaxy Tab S9","tablets",800,1280,"tablet"),T("macbook-air-13",'MacBook Air 13"',"desktop",1440,900,"laptop"),T("macbook-pro-14",'MacBook Pro 14"',"desktop",1512,982,"laptop"),T("macbook-pro-16",'MacBook Pro 16"',"desktop",1728,1117,"laptop"),T("imac-24",'iMac 24"',"desktop",2240,1260,"monitor"),T("desktop-hd","Desktop HD","desktop",1920,1080,"monitor"),T("apple-watch-10","Apple Watch Series 10","watches",208,248,"watch"),T("apple-watch-ultra-2","Apple Watch Ultra 2","watches",205,251,"watch")],We={responsive:"Responsive",phones:"Phones",tablets:"Tablets",desktop:"Desktop",watches:"Watches"},Mo="iphone-16-pro";function Se(o){return Ge.find(e=>e.id===o)}function Ao(o){let{layout:e}=o,t=e.typography,r=[];r.push("Recreate this UI element as a React component styled with Tailwind CSS. Match the values below exactly."),r.push(""),r.push(`Element: <${o.tagName}> (${o.selector})`),r.push(`Size: ${e.boxModel.content.width} \xD7 ${e.boxModel.content.height}px`),o.text&&r.push(`Text: "${o.text}"`),r.push(`Location: ${o.domPath.slice(-4).join(" > ")}`),r.push(""),e.tailwind.length&&(r.push("Tailwind classes:"),r.push(e.tailwind.join(" ")),r.push("")),r.push("Design details:"),t&&r.push(`- Font: ${t.fontFamily}, ${t.fontSize} / ${t.lineHeight}, weight ${t.fontWeight}, letter spacing ${t.letterSpacing}`);for(let p of e.colors)r.push(`- ${p.role[0].toUpperCase()}${p.role.slice(1)} color: ${z(p.value)}`);e.contrast&&r.push(`- Text contrast: ${e.contrast.ratio.toFixed(2)}:1 (${e.contrast.aa?"passes":"fails"} WCAG AA)`),e.fills.length&&r.push(`- Background gradient: ${e.fills.map(p=>p.raw).join(", ")}`);let n=e.cornerRadius;r.push(`- Corner radius: ${n.topLeft} ${n.topRight} ${n.bottomRight} ${n.bottomLeft}`);for(let p of e.effects.shadows)r.push(`- ${p.type} shadow: ${p.x} ${p.y} blur ${p.blur} spread ${p.spread} ${p.color}`);let{padding:i,margin:s}=e.boxModel;return r.push(`- Padding: ${i.top}px ${i.right}px ${i.bottom}px ${i.left}px; margin: ${s.top}px ${s.right}px ${s.bottom}px ${s.left}px`),e.autoLayout&&r.push(`- Parent layout: ${e.autoLayout.direction}, gap ${e.autoLayout.gap}, align ${e.autoLayout.align}, distribute ${e.autoLayout.distribute}`),r.push(""),r.push("CSS:"),r.push(...e.rawCss),r.push(""),r.push("Use semantic HTML, keep the component self-contained, and do not invent values that are not listed above."),r.join(`
`)}var Ke=64,lr=4e3,cr={"image/svg+xml":"svg","image/png":"png","image/jpeg":"jpg","image/gif":"gif","image/webp":"webp","image/avif":"avif","image/x-icon":"ico","video/mp4":"mp4","video/webm":"webm"};function re(o){try{return new URL(o,document.baseURI).href}catch{return null}}function dr(o,e){if(o.startsWith("data:"))return cr[o.slice(5,o.indexOf(";")>0?o.indexOf(";"):o.indexOf(","))]??e;try{let t=new URL(o).pathname.match(/\.([a-z0-9]{2,5})$/i);return t?t[1].toLowerCase():e}catch{return e}}function ur(o,e,t){let r=dr(o,t),n="";if(!o.startsWith("data:")&&!o.startsWith("blob:"))try{n=decodeURIComponent(new URL(o).pathname.split("/").pop()??"").replace(/\.[a-z0-9]{2,5}$/i,"")}catch{n=""}return n=n.replace(/[^\w.-]+/g,"-").replace(/^-+|-+$/g,"").slice(0,60)||`asset-${e}`,{name:`${n}.${r}`,filename:`${n}.${r}`}}function hr(o){return o.startsWith("data:")?Math.round(o.length*.75):performance.getEntriesByName(o)[0]?.encodedBodySize||void 0}function Lo(o){return o?o<1024?`${o} B`:o<1024*1024?`${Math.round(o/1024)} KB`:`${(o/1024/1024).toFixed(1)} MB`:""}function gr(o){return`data:image/svg+xml;charset=utf-8,${encodeURIComponent(o)}`}function Ro(o){return o.svg?gr(o.svg):o.kind==="video"||o.kind==="lottie"?o.poster:o.url}function qe(o){return!!o.closest(`#${R}`)}function Po(o){let e=[],t=l=>o?[...o.matches(l)?[o]:[],...Array.from(o.querySelectorAll(l))]:Array.from(document.querySelectorAll(l)),r=new Set,n=l=>{let c=l.svg??l.url;if(!c||r.has(c))return;r.add(c);let d=e.length+1,h=l.url?ur(l.url,d,l.ext):{name:`inline-${d}.${l.ext}`,filename:`inline-${d}.${l.ext}`},{ext:m,...v}=l,u=l.svg?l.svg.length:l.url?hr(l.url):void 0;e.push({...v,id:`asset-${d}`,...h,format:h.filename.split(".").pop()?.toUpperCase()??l.ext.toUpperCase(),bytes:u})},i=(l,c,d)=>c>0&&d>0&&c<=Ke&&d<=Ke?"icon":/\.svg(\?|#|$)/i.test(l)||l.startsWith("data:image/svg")?"svg":"image";for(let l of t("img")){if(qe(l))continue;let c=re(l.currentSrc||l.src);if(!c||l.naturalWidth<=1&&l.naturalHeight<=1&&!/\.svg/i.test(c))continue;let d=l.naturalWidth||l.width,h=l.naturalHeight||l.height;n({kind:i(c,l.width||d,l.height||h),url:c,width:d,height:h,ext:"png"})}for(let l of t("svg")){if(qe(l)||l.closest("svg")!==l)continue;let c=l.getBoundingClientRect();if(c.width<2||c.height<2)continue;let d=l.cloneNode(!0);d.getAttribute("xmlns")||d.setAttribute("xmlns","http://www.w3.org/2000/svg"),d.getAttribute("width")||d.setAttribute("width",String(Math.round(c.width))),d.getAttribute("height")||d.setAttribute("height",String(Math.round(c.height)));let h=new XMLSerializer().serializeToString(d).replace(/currentColor/g,getComputedStyle(l).color);n({kind:c.width<=Ke&&c.height<=Ke?"icon":"svg",svg:h,width:Math.round(c.width),height:Math.round(c.height),ext:"svg"})}for(let l of t("video")){if(qe(l))continue;let c=l.poster?re(l.poster)??void 0:void 0,d=[l.currentSrc||l.src,...Array.from(l.querySelectorAll("source")).map(h=>h.src)];for(let h of d){let m=h&&!h.startsWith("blob:")?re(h):null;m&&n({kind:"video",url:m,width:l.videoWidth||void 0,height:l.videoHeight||void 0,poster:c,ext:"mp4"})}c&&n({kind:"image",url:c,ext:"jpg"})}for(let l of t("lottie-player, dotlottie-player, dotlottie-wc, lottie-web")){let c=l.getAttribute("src"),d=c?re(c):null;d&&n({kind:"lottie",url:d,ext:"json"})}for(let l of o?[]:performance.getEntriesByType("resource"))/\.lottie(\?|$)|lottie[^/]*\.json(\?|$)/i.test(l.name)&&n({kind:"lottie",url:l.name,ext:"json"});let s=(o?[o,...Array.from(o.querySelectorAll("*"))]:Array.from(document.body?.querySelectorAll("*")??[])).slice(0,lr);for(let l of s){if(qe(l))continue;let c=getComputedStyle(l).backgroundImage;if(!(!c||c==="none"))for(let d of c.matchAll(/url\(\s*["']?([^"')]+)["']?\s*\)/g)){let h=re(d[1]);if(!h)continue;let m=l.getBoundingClientRect();n({kind:i(h,Math.round(m.width),Math.round(m.height)),url:h,ext:"png"})}}for(let l of o?[]:Array.from(document.querySelectorAll('link[rel~="icon"], link[rel="apple-touch-icon"]'))){let c=re(l.href);c&&n({kind:"icon",url:c,ext:"png"})}let p=o?void 0:document.querySelector('meta[property="og:image"]')?.content,a=p?re(p):null;return a&&n({kind:"image",url:a,ext:"png"}),e}var A=o=>`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${o}</svg>`,w={palette:A('<path d="M12 3a9 9 0 100 18c1.7 0 2-1.2 1.4-2.2-.7-1.2.1-2.8 1.6-2.8H17a4 4 0 004-4c0-4.4-4-9-9-9z"/><circle cx="7.5" cy="11" r="1"/><circle cx="11" cy="7" r="1"/><circle cx="16" cy="8" r="1"/>'),type:A('<path d="M4 20l6-16 6 16M6.5 14h7M17 20h4M19 11v9"/>'),effect:A('<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>'),play:A('<circle cx="12" cy="12" r="9"/><path d="M10 8.5l5 3.5-5 3.5z"/>'),layout:A('<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>'),spacing:A('<rect x="3" y="7" width="18" height="10" rx="1.5"/><path d="M7 7v4M11 7v3M15 7v4M19 7v3"/>'),figma:A('<path d="M8 3h4a3 3 0 010 6H8z"/><path d="M12 3h4a3 3 0 010 6h-4z"/><path d="M8 9h4a3 3 0 010 6H8z"/><circle cx="15" cy="12" r="3"/><path d="M8 15a3 3 0 103 3v-3z"/>'),info:A('<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>'),image:A('<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/>'),svg:A('<path d="M12 3l9 5v8l-9 5-9-5V8z"/><path d="M12 12l9-4M12 12v9M12 12L3 8"/>'),star:A('<path d="M12 3l2.6 5.6 6.1.7-4.5 4.2 1.2 6L12 16.5 6.6 19.5l1.2-6L3.3 9.3l6.1-.7z"/>'),video:A('<rect x="2" y="5" width="14" height="14" rx="2"/><path d="M16 10l6-3v10l-6-3z"/>'),wand:A('<path d="M15 4l5 5L9 20l-5-5zM13 6l5 5M5 3v3M3.5 4.5h3M19 15v3M17.5 16.5h3"/>'),boxes:A('<rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="3" width="8" height="8" rx="1.5"/><rect x="3" y="13" width="8" height="8" rx="1.5"/><rect x="13" y="13" width="8" height="8" rx="1.5"/>'),tokens:A('<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>'),code:A('<path d="M8 7l-5 5 5 5M16 7l5 5-5 5M14 4l-4 16"/>'),file:A('<path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5"/>'),download:'<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12m0 0l-5-5m5 5l5-5M4 21h16"/></svg>',chevron:'<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg>',phone:A('<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>'),tablet:A('<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M11 18h2"/>'),desktop:A('<rect x="2" y="4" width="20" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>'),watch:A('<rect x="6" y="6" width="12" height="12" rx="3"/><path d="M9 6l1-4h4l1 4M9 18l1 4h4l1-4"/>'),responsive:A('<path d="M3 8V5a2 2 0 012-2h3M16 3h3a2 2 0 012 2v3M21 16v3a2 2 0 01-2 2h-3M8 21H5a2 2 0 01-2-2v-3"/>')},f=H,Ye='<button class="pp-btn" data-pp-act="rescan">Rescan</button>',D=o=>`<div class="pp-empty">${o}</div>`,mr=o=>`<p class="pp-note" style="margin:0 0 8px">${o}</p>`,Ho=o=>o.text?`<p class="pp-status${o.tone?` pp-${o.tone}`:""}">${f(o.text)}</p>`:"",$t=o=>`<div class="pp-empty">Couldn't read this page</div><p class="pp-status pp-warn">${f(o)}</p>`,Bo=o=>`${(Math.floor(o*100)/100).toFixed(2)}:1`,fr=/^(arial|helvetica|helvetica neue|times|times new roman|georgia|courier|courier new|verdana|tahoma|trebuchet ms|impact|segoe ui|system-ui|ui-sans-serif|ui-serif|ui-monospace|sans-serif|serif|monospace|cursive|fantasy|-apple-system|blinkmacsystemfont|menlo|consolas|monaco)$/i;function Oo(o,e){return e?` \xB7 <a href="${f(e)}" target="_blank" rel="noopener noreferrer">source</a>`:fr.test(o)?" \xB7 system font":" \xB7 no font file found (not loaded, or in a stylesheet PixelPeek cannot read)"}function L(o,e,t,r,n,i={}){let s=o.cards[e]??!i.closed;return`
    <section class="pp-card${s?" pp-card-open":""}" data-pp-anchor="${e.split(":")[1]??e}">
      <div class="pp-card-head" data-pp-act="card" data-pp-value="${f(e)}" role="button" tabindex="0" aria-expanded="${s}">
        <span class="pp-card-ico">${r}</span>
        <h3>${f(t)}</h3>
        ${i.meta?`<span class="pp-card-meta">${i.meta}</span>`:""}
        ${i.actions??""}
        <span class="pp-card-chev">${w.chevron}</span>
      </div>
      ${s?`<div class="pp-card-body">${n}</div>`:""}
    </section>`}function M(o,e,t,r){let n=r?`<span class="pp-swatch" style="background:${f(r)}"></span>`:"",i=`<span class="pp-cv-k">${f(o)}</span><span class="pp-cv-v">${n}${f(e)}</span>`;return t!==void 0?`<button class="pp-cv" data-pp-act="copy" data-pp-copy="${f(t)}" title="Click to copy">${i}<span class="pp-cv-i">\u29C9</span></button>`:`<div class="pp-cv pp-cv-off">${i}</div>`}function kt(o,e,t=o){return`
    <button class="pp-sq" data-pp-act="copy" data-pp-copy="${f(t)}" title="Copy ${f(t)}">
      <span class="pp-sq-fill" style="background:${f(o)}"><span class="pp-sq-copy">Copy</span></span>
      <span class="pp-sq-hex">${f(o)}</span>
      <span class="pp-sq-sub">${e}</span>
    </button>`}var te=(...o)=>`<div class="pp-cv-grid">${o.filter(Boolean).join("")}</div>`,br=new Set(["input","button","textarea","select"]),ie=o=>`${Math.round(o*10)/10}px`,Io=(o,e,t,r)=>o===e&&e===t&&t===r?ie(o):o===t&&e===r?`${ie(o)} ${ie(e)}`:`${ie(o)} ${ie(e)} ${ie(t)} ${ie(r)}`,No=o=>!o||parseFloat(o)===0;function vr(o){let{margin:e,border:t,padding:r,content:n}=o.layout.boxModel,i=s=>s?String(Math.round(s*10)/10):"\u2013";return`
    <div class="pp-boxmodel" aria-label="Box model">
      <div class="pp-bm pp-bm-margin"><span class="pp-bm-name">margin</span><span class="pp-bm-t">${i(e.top)}</span>
        <div class="pp-bm pp-bm-border"><span class="pp-bm-name">border</span><span class="pp-bm-t">${i(t.top)}</span>
          <div class="pp-bm pp-bm-padding"><span class="pp-bm-name">padding</span><span class="pp-bm-t">${i(r.top)}</span>
            <div class="pp-bm pp-bm-content">${Math.round(n.width)} \xD7 ${Math.round(n.height)}</div>
            <span class="pp-bm-b">${i(r.bottom)}</span><span class="pp-bm-l">${i(r.left)}</span><span class="pp-bm-r">${i(r.right)}</span>
          </div>
          <span class="pp-bm-b">${i(t.bottom)}</span><span class="pp-bm-l">${i(t.left)}</span><span class="pp-bm-r">${i(t.right)}</span>
        </div>
        <span class="pp-bm-b">${i(e.bottom)}</span><span class="pp-bm-l">${i(e.left)}</span><span class="pp-bm-r">${i(e.right)}</span>
      </div>
    </div>`}var xr={background:"fill",text:"text",border:"border",icon:"icon",gradient:"gradient"},zo=24;function yr(o,e){let t=e.layout.palette,r=o.cards["styles:colors:all"]===!0,n=r?t:t.slice(0,zo),i=u=>`${u.roles.map(g=>xr[g]).join("/")}${u.count>1?` \xB7 ${u.count}\xD7`:""}`,s=n.filter(u=>u.own),p=n.filter(u=>!u.own),a=(u,g)=>g.length?`${u?`<div class="pp-sub"><span>${u}</span></div>`:""}<div class="pp-squares">${g.map(y=>kt(y.hex,i(y))).join("")}</div>`:"",l=s.length&&p.length?`${a("On this element",s)}${a(`Inside it \xB7 ${t.length-s.length}`,p)}`:a("",n),c=t.length>zo?`<button class="pp-btn pp-btn-sm" style="margin-top:10px" data-pp-act="card" data-pp-value="styles:colors:all" aria-expanded="${r}">${r?"Show fewer":`Show all ${t.length}`}</button>`:"",d=e.layout.fills.map(u=>`<button class="pp-grad" style="background:${f(u.raw)}" data-pp-act="copy" data-pp-copy="background-image: ${f(u.raw)};" title="Copy gradient"><span>Copy gradient</span></button>`).join(""),h=e.layout.contrast,m=(u,g)=>`<span class="pp-tag ${u?"pp-tag-pass":"pp-tag-fail"}">${g} ${u?"pass":"fail"}</span>`,v=h?h.onImage?'<div class="pp-contrast"><span class="pp-pair-hex">Text sits over an image, so its contrast cannot be measured.</span></div>':`<div class="pp-contrast"><span class="pp-contrast-ratio" title="Text colour against what is behind it">${Bo(h.ratio)}</span>${m(h.aa,"AA")}${m(h.aaa,"AAA")}${h.large?'<span class="pp-pair-hex">large text</span>':""}${h.gradient?'<span class="pp-pair-hex">worst point of the gradient</span>':""}</div>`:"";return!t.length&&!d?"":L(o,"styles:colors","Colors",w.palette,`${l}${c}${d}${v}`,{meta:String(t.length)})}function wr(o,e){let t=e.layout.typography;if(!t||!(e.text||br.has(e.tagName)))return"";let r=(t.fontFamily.split(",")[0]??"").replace(/["']/g,"").trim(),n=[];["start","left"].includes(t.textAlign)||n.push(M("Align",t.textAlign,`text-align: ${t.textAlign};`)),t.textTransform!=="none"&&n.push(M("Case",t.textTransform,`text-transform: ${t.textTransform};`)),t.textDecoration!=="none"&&n.push(M("Decoration",t.textDecoration,`text-decoration: ${t.textDecoration};`)),t.truncation!=="none"&&n.push(M("Truncation",t.truncation));let i=`
    <button class="pp-fam" data-pp-act="copy" data-pp-copy="font-family: ${f(t.fontFamily)};" title="Copy font-family">
      <span class="pp-fam-sample" style="font-family:${f(t.fontFamily)}">Aa</span>
      <span class="pp-fam-info"><b>${f(r)}</b><span>${f(t.fontFamily)}</span></span>
      <span class="pp-cv-i">\u29C9</span>
    </button>
    ${te(M("Size",t.fontSize,`font-size: ${t.fontSize};`),M("Line height",t.lineHeight,`line-height: ${t.lineHeight};`),M("Weight",t.fontWeight,`font-weight: ${t.fontWeight};`),t.letterSpacing!=="normal"?M("Spacing",t.letterSpacing,`letter-spacing: ${t.letterSpacing};`):"",...n)}`;return L(o,"styles:typography","Typography",w.type,i)}function $r(o,e){let{stroke:t,cornerRadius:r,effects:n}=e.layout,i=[];if(t){let p=["top","right","bottom","left"].filter(l=>parseFloat(t[l].width)>0&&t[l].style!=="none"),a=t[p[0]];if(p.length===4&&p.every(l=>t[l].width===a.width&&t[l].color===a.color&&t[l].style===a.style)){let l=`${a.width} ${a.style} ${a.color}`;i.push(M("Stroke",l,`border: ${l};`,a.color))}else for(let l of p){let c=`${t[l].width} ${t[l].style} ${t[l].color}`;i.push(M(`Stroke ${l}`,c,`border-${l}: ${c};`,t[l].color))}}let s=[r.topLeft,r.topRight,r.bottomRight,r.bottomLeft];if(!s.every(No)){let p=s.every(a=>a===s[0])?s[0]:s.join(" ");i.push(M("Radius",p,`border-radius: ${p};`))}return n.shadows.forEach((p,a)=>{let l=`${p.type==="Inner"?"inset ":""}${p.x} ${p.y} ${p.blur}${p.spread!=="0px"?` ${p.spread}`:""} ${p.color}`;i.push(M(`${p.type==="Inner"?"Inner shadow":"Shadow"}${n.shadows.length>1?` ${a+1}`:""}`,l,`box-shadow: ${l};`,p.color))}),n.opacity&&i.push(M("Opacity",n.opacity,`opacity: ${n.opacity};`)),i.length?L(o,"styles:effect","Effect",w.effect,te(...i)):""}function kr(o,e){let t=e.layout.animation;if(!t)return"";let r=[];for(let i of t.transitions){let s=`${i.property} ${i.duration} ${i.easing}${parseFloat(i.delay)?` ${i.delay}`:""}`;r.push(M("Transition",s,`transition: ${s};`))}for(let i of t.animations){let s=`${i.name} ${i.duration} ${i.easing}${parseFloat(i.delay)?` ${i.delay}`:""} ${i.iterations}`;r.push(M("Animation",s,`animation: ${s};`))}let n=t.keyframes.map(i=>{let s=`@keyframes ${i.name} {
${i.steps.map(p=>`  ${p.offset} { ${p.css} }`).join(`
`)}
}`;return`<button class="pp-code-copy" data-pp-act="copy" data-pp-copy="${f(s)}" title="Copy keyframes"><pre class="pp-code">${f(s)}</pre></button>`}).join("");return L(o,"styles:animation","Animation",w.play,`${te(...r)}${n}`)}function Sr(o,e){let{boxModel:t,display:r,position:n,autoLayout:i}=e.layout,s=[M("Size",`${Math.round(t.content.width)} \xD7 ${Math.round(t.content.height)}`,`width: ${Math.round(t.content.width)}px;
height: ${Math.round(t.content.height)}px;`)],p=Io(t.padding.top,t.padding.right,t.padding.bottom,t.padding.left);(t.padding.top||t.padding.right||t.padding.bottom||t.padding.left)&&s.push(M("Padding",p,`padding: ${p};`));let a=Io(t.margin.top,t.margin.right,t.margin.bottom,t.margin.left);(t.margin.top||t.margin.right||t.margin.bottom||t.margin.left)&&s.push(M("Margin",a,`margin: ${a};`)),(r.includes("flex")||r.includes("grid"))&&s.push(M("Display",r,`display: ${r};`)),n!=="static"&&s.push(M("Position",n,`position: ${n};`)),i&&!No(i.gap)&&s.push(M("Parent gap",i.gap,`gap: ${i.gap};`));let l=`<button class="pp-btn" data-pp-act="guides" aria-pressed="${o.guidesOn}">${w.spacing} ${o.guidesOn?"Hide":"Show"} spacing on the page</button>`;return L(o,"styles:layout","Layout",w.layout,`${te(...s)}${vr(e)}<div class="pp-btn-row" style="margin-top:8px">${l}</div>`)}function Cr(o,e){let t=e.colors.slice(0,24).map(a=>kt(a.hex,`${a.count} use${a.count===1?"":"s"}`)).join(""),r=e.pairs.filter(a=>!a.aa),n=(o.failingOnly?r:e.pairs).slice(0,12),i=(a,l)=>`<span class="pp-tag ${a?"pp-tag-pass":"pp-tag-fail"}">${l} ${a?"pass":"fail"}</span>`,s=n.map(a=>`
      <div class="pp-pair">
        <span class="pp-pair-sample" style="background:${f(a.bg)};color:${f(a.fg)}">Aa</span>
        <div class="pp-pair-info"><div class="pp-pair-ratio">${Bo(a.ratio)}${a.large?' <span class="pp-pair-hex">large</span>':""}</div>
          <div class="pp-pair-hex">${f(a.fg)} on ${f(a.bg)} \xB7 ${a.count}\xD7</div></div>
        <div>${i(a.aa,"AA")} ${i(a.aaa,"AAA")}</div>
      </div>`).join(""),p=`
    ${e.colors.length?`<div class="pp-squares">${t}</div>`:D("No colours found")}
    ${e.colors.length>24?`<p class="pp-status">Showing the 24 most used of ${e.colors.length}.</p>`:""}
    <div class="pp-sub"><span>Contrast: ${r.length} of ${e.pairs.length} text styles fail AA</span>
      <button class="pp-chip" data-pp-act="failing" aria-pressed="${o.failingOnly}">Failing only</button></div>
    ${s||D(o.failingOnly?"Every text style passes AA.":"No text found")}`;return L(o,"styles:colors","Colors",w.palette,p,{meta:String(e.colors.length),actions:Ye.replace('class="pp-btn"','class="pp-btn pp-btn-sm"')})}function Er(o,e){let t=e.fonts.map(n=>{let i=n.sizes.length>1?`${n.sizes[0]}\u2013${n.sizes[n.sizes.length-1]}px`:`${n.sizes[0]}px`,s=Oo(n.family,n.source);return`
        <div class="pp-fam pp-fam-static">
          <button class="pp-fam-sample" data-pp-act="copy" data-pp-copy="font-family: ${f(JSON.stringify(n.family))};" title="Copy font-family" style="font-family:${f(JSON.stringify(n.family))}, sans-serif">Aa</button>
          <span class="pp-fam-info"><b>${f(n.family)}</b><span>${n.weights.join(", ")} \xB7 ${i} \xB7 ${n.count}\xD7${s}</span></span>
        </div>`}).join(""),r=e.textStyles.slice().sort((n,i)=>i.size-n.size||i.weight-n.weight).slice(0,10).map(n=>{let i=`font: ${n.weight} ${n.size}px/${n.lineHeight} ${n.family.includes(" ")?`"${n.family}"`:n.family};`;return M(`${n.size}px`,`${n.weight} \xB7 ${n.lineHeight}`,i)});return L(o,"styles:typography","Typography",w.type,`${t||D("No text found")}${r.length?`<div class="pp-sub"><span>Type scale</span></div>${te(...r)}`:""}`,{meta:`${e.fonts.length} families`})}function Tr(o,e){let t=(n,i,s)=>i.slice(0,4).map(p=>M(`${n} \xB7 ${p.count}\xD7`,p.value,`${s}: ${p.value};`)),r=[...t("Shadow",e.shadows,"box-shadow"),...t("Radius",e.radii,"border-radius"),...t("Gradient",e.gradients,"background-image")];return r.length?L(o,"styles:effect","Effect",w.effect,te(...r),{closed:!0}):""}function Mr(o,e){return e.spacing.length?L(o,"styles:layout","Spacing in use",w.spacing,te(...e.spacing.slice(0,10).map(t=>M(`${t.count}\xD7`,t.value,t.value))),{closed:!0}):""}function Vo(o){return o.capture?[yr(o,o.capture),wr(o,o.capture),$r(o,o.capture),kr(o,o.capture),Sr(o,o.capture)].join(""):o.scanError?$t(o.scanError):o.scanning||!o.scan?D("Reading the page\u2026"):`${mr("The whole page. Click any element to inspect just that one.")}${Cr(o,o.scan)}${Er(o,o.scan)}${Tr(o,o.scan)}${Mr(o,o.scan)}`}function jo(o){let e=o.figma,t=e?.warnings.length?`<ul class="pp-list">${e.warnings.map(i=>`<li>${f(i)}</li>`).join("")}</ul>`:"",r=`
    <p class="pp-status" style="margin:0 0 10px">Editable Figma layers: boxes with fills, strokes, radii and shadows, real text, images and icons. Then click the Figma canvas and press Ctrl+V (\u2318V on Mac).</p>
    ${o.capture?`<button class="pp-btn pp-btn-primary pp-btn-wide" data-pp-act="figma-element" ${o.busy?"disabled":""}>${w.figma} Copy <b>${f(o.capture.selector)}</b> for Figma</button>
      <div class="pp-sub"><span>Or the page</span></div>`:""}
    <div class="pp-btn-row">
      <button class="pp-btn ${o.capture?"":"pp-btn-primary"}" data-pp-act="figma-run" data-pp-value="viewport" ${o.busy?"disabled":""}>Copy visible area</button>
      <button class="pp-btn" data-pp-act="figma-run" data-pp-value="page" ${o.busy?"disabled":""}>Copy whole page</button>
    </div>
    ${Ho(o.figmaStatus)}${e?`<p class="pp-status">${e.layers} layer${e.layers===1?"":"s"} \xB7 ${Math.round(e.width)} \xD7 ${Math.round(e.height)}px</p>`:""}
    ${t}
    ${e?'<div class="pp-btn-row" style="margin-top:10px"><button class="pp-btn" data-pp-act="figma-copy-pending">Copy layers again</button></div>':""}`;return L(o,"figma:copy","Copy for Figma",w.figma,r)+L(o,"figma:expect","What to expect",w.info,`<ul class="pp-list" style="margin:0">
      <li>Layers match how the browser laid the page out. They are not auto layout.</li>
      <li>Text uses the page's fonts; Figma shows a missing-font notice for fonts you do not have.</li>
      <li>Rotated or scaled elements, inner shadows and conic gradients are simplified.</li>
      <li>Pages are capped at 4,000 elements and 20,000px tall.</li></ul>`,{closed:!0})}var Ar=[{kind:"image",title:"Images",icon:w.image},{kind:"svg",title:"SVG",icon:w.svg},{kind:"icon",title:"Icons",icon:w.star},{kind:"video",title:"Video",icon:w.video},{kind:"lottie",title:"Lottie",icon:w.wand}];function Uo(o){let e=r=>{let n=Ro(r),i=n?`<img src="${f(n)}" alt="" loading="lazy" referrerpolicy="no-referrer">`:r.kind,s=[r.format,Lo(r.bytes),r.width&&r.height?`${r.width}\xD7${r.height}`:""].filter(Boolean).join(" \xB7 ");return`
      <div class="pp-asset" title="${f(r.name)}">
        <div class="pp-asset-thumb">${i}</div>
        <button class="pp-asset-dl" data-pp-act="asset-dl" data-pp-value="${f(r.id)}" title="Download ${f(r.name)}" aria-label="Download ${f(r.name)}">${w.download}</button>
        <div class="pp-asset-meta">${f(r.name)}</div><div class="pp-asset-meta pp-asset-sub">${f(s)}</div>
      </div>`},t=Ar.map(({kind:r,title:n,icon:i})=>{let s=o.assets.filter(a=>a.kind===r);if(!s.length)return"";let p=`<button class="pp-btn pp-btn-sm" data-pp-act="assets-zip" data-pp-value="${r}" ${o.busy?"disabled":""} title="Download these as a ZIP">${w.download} ZIP</button>`;return L(o,`assets:${r}`,n,i,`<div class="pp-assets">${s.map(e).join("")}</div>`,{meta:String(s.length),actions:p})}).join("");return`
    <div class="pp-btn-row" style="margin-bottom:10px">
      <button class="pp-btn pp-btn-primary" data-pp-act="assets-zip" data-pp-value="all" ${o.assets.length&&!o.busy?"":"disabled"}>${w.download} Download all (ZIP)</button>
      ${Ye}
    </div>
    ${o.capture?`<p class="pp-note" style="margin:0 0 8px">Inside <b>${f(o.capture.selector)}</b>. Clear the selection to see the whole page.</p>`:""}
    ${Ho(o.assetStatus)}
    ${t||D(o.assetsLoading?"Reading the page\u2026":o.capture?"No images, icons or videos inside this element":"No assets found on this page")}`}var Fo=40,Do=o=>$e(o)??"";function Lr(o){let e=o.kind==="color"?Do(o.resolved):"",t=o.dark&&o.kind==="color"?Do(o.dark):"",r=o.alias?`${o.alias}${e?` \xB7 ${e}`:""}`:o.value;return`
    <button class="pp-tok" data-pp-act="copy" data-pp-copy="var(${f(o.name)})" title="Copy var(${f(o.name)})">
      ${o.kind==="color"?`<span class="pp-tok-sw" style="background:${f(e||o.resolved)}"></span>`:'<span class="pp-tok-sw pp-tok-none"></span>'}
      <span class="pp-tok-main"><b>${f(o.name)}</b><span>${f(r)}</span></span>
      ${o.dark?`<span class="pp-tok-dark" title="Dark mode: ${f(o.dark)}">${t?`<span class="pp-tok-sw" style="background:${f(t)}"></span>`:""}<em>dark</em></span>`:""}
    </button>`}function Rr(o,e){let t=[["Colors",e.tokens.filter(n=>n.kind==="color")],["Spacing, size and radius",e.tokens.filter(n=>n.kind==="dimension")],["Fonts",e.tokens.filter(n=>n.kind==="font")],["Shadows",e.tokens.filter(n=>n.kind==="shadow")],["Other",e.tokens.filter(n=>n.kind==="other")]],r=e.tokens.length?t.filter(([,n])=>n.length).map(([n,i])=>{let s=o.cards[`system:vars:${n}`]===!0,p=(s?i:i.slice(0,Fo)).map(Lr).join(""),a=i.length>Fo?`<button class="pp-btn pp-btn-sm" data-pp-act="card" data-pp-value="system:vars:${f(n)}" aria-expanded="${s}">${s?"Show fewer":`Show all ${i.length}`}</button>`:"";return`<div class="pp-sub"><span>${n} \xB7 ${i.length}</span></div><div class="pp-toks">${p}</div>${a}`}).join(""):'<p class="pp-note" style="margin:0">This site does not declare CSS variables, so it has no named tokens. The cards below show what the page actually uses.</p>';return L(o,"system:variables","Variables",w.tokens,r,{meta:e.tokens.length?`declared \xB7 ${e.tokens.length}`:"none declared",actions:Ye.replace('class="pp-btn"','class="pp-btn pp-btn-sm"')})}function Pr(o,e){let r=[["Surface","surface"],["Text","text"],["Border","border"],["Icon and fill","icon"]].map(([n,i])=>{let s=e.colors.filter(d=>d[i]>0).sort((d,h)=>h[i]-d[i]);if(!s.length)return"";let p=o.cards[`system:colors:${i}`]===!0,l=(p?s:s.slice(0,12)).map(d=>kt(d.hex,`${d.tokens[0]?`${d.tokens[0]} \xB7 `:""}${d[i]}\xD7`)).join(""),c=s.length>12?`<button class="pp-btn pp-btn-sm" style="margin-top:8px" data-pp-act="card" data-pp-value="system:colors:${i}" aria-expanded="${p}">${p?"Show fewer":`Show all ${s.length}`}</button>`:"";return`<div class="pp-sub"><span>${n} \xB7 ${s.length}</span></div><div class="pp-squares">${l}</div>${c}`}).join("");return L(o,"system:colors","Colors",w.palette,r||D("No colours found"),{meta:`${e.colors.length} in use`})}function Ir(o,e){let t=e.fonts.map(i=>{let s=Oo(i.family,i.source),p=JSON.stringify(i.family);return`
        <button class="pp-fam" data-pp-act="copy" data-pp-copy="font-family: ${f(p)};" title="Copy font-family">
          <span class="pp-fam-sample" style="font-family:${f(p)}, sans-serif">Aa</span>
          <span class="pp-fam-info"><b>${f(i.family)}</b><span>${i.weights.join(", ")}${s}</span></span>
          <span class="pp-cv-i">\u29C9</span>
        </button>`}).join(""),r=e.textStyles.map(i=>{let s=i.family.includes(" ")?`"${i.family}"`:i.family,p=`font: ${i.weight} ${i.size}/${i.lineHeight} ${s};${i.letterSpacing!=="normal"?`
letter-spacing: ${i.letterSpacing};`:""}`;return`
        <button class="pp-fam" data-pp-act="copy" data-pp-copy="${f(p)}" title="Copy text style">
          <span class="pp-fam-sample" style="font-family:${f(JSON.stringify(i.family))}, sans-serif;font-weight:${i.weight}">Aa</span>
          <span class="pp-fam-info"><b>${f(i.name)}</b><span>${f(i.size)} / ${f(i.lineHeight)} \xB7 ${i.weight}${i.letterSpacing!=="normal"?` \xB7 ${f(i.letterSpacing)}`:""} \xB7 ${i.count}\xD7</span></span>
          <span class="pp-cv-i">\u29C9</span>
        </button>`}).join(""),n=`${t?`<div class="pp-sub" style="margin-top:0"><span>Fonts \xB7 ${e.fonts.length}</span></div>${t}`:""}${r?`<div class="pp-sub"><span>Text styles \xB7 ${e.textStyles.length}</span></div>${r}`:""}`;return L(o,"system:typography","Typography",w.type,n||D("No text found"))}function zr(o,e){let t=e.shadows.map(n=>`
      <button class="pp-fx" data-pp-act="copy" data-pp-copy="box-shadow: ${f(n.value)};" title="Copy box-shadow">
        <span class="pp-fx-box" style="box-shadow:${f(n.value)}"></span>
        <span class="pp-fam-info"><b>${f(n.name)}</b><span>${f(n.value)} \xB7 ${n.count}\xD7</span></span>
      </button>`).join(""),r=e.gradients.map(n=>`
      <button class="pp-fx" data-pp-act="copy" data-pp-copy="background-image: ${f(n.value)};" title="Copy gradient">
        <span class="pp-fx-box" style="background:${f(n.value)}"></span>
        <span class="pp-fam-info"><b>${f(n.name)}</b><span>${f(n.value)} \xB7 ${n.count}\xD7</span></span>
      </button>`).join("");return!t&&!r?"":L(o,"system:effects","Effects",w.effect,`${t?`<div class="pp-sub" style="margin-top:0"><span>Shadows \xB7 ${e.shadows.length}</span></div>${t}`:""}${r?`<div class="pp-sub"><span>Gradients \xB7 ${e.gradients.length}</span></div>${r}`:""}`)}function Fr(o,e){if(!e.spacing.length&&!e.radii.length)return"";let t=(n,i)=>te(...n.map(s=>M(s.tokens[0]??`${s.count}\xD7`,s.value,i(s.value)))),r=`${e.spacing.length?`<div class="pp-sub" style="margin-top:0"><span>Spacing in use</span></div>${t(e.spacing,n=>n)}`:""}${e.radii.length?`<div class="pp-sub"><span>Corner radius in use</span></div>${t(e.radii,n=>`border-radius: ${n};`)}`:""}`;return L(o,"system:spacing","Spacing and radius",w.spacing,r,{closed:!0})}function Dr(o,e){return e||!o?D("Finding components\u2026"):o.length?o.map(t=>`
      <div class="pp-sub"><span>${t.kind}s \xB7 ${t.variants.reduce((r,n)=>r+n.count,0)}</span></div>
      ${t.variants.map(r=>`
          <div class="pp-comp">
            <div class="pp-comp-preview"><span style="${f(r.previewStyle)}">${f(r.label)}</span></div>
            <div class="pp-comp-details">${r.details.map(n=>`<span><i>${f(n.label)}</i>${n.label==="Fill"||n.label==="Text"?`<span class="pp-swatch" style="background:${f(n.value)}"></span>`:""}${f(n.value)}</span>`).join("")}</div>
            <div class="pp-comp-meta"><span>${r.count}\xD7 \xB7 ${f(r.size)}</span>
              <button class="pp-card-copy" data-pp-act="copy" data-pp-copy="${f(r.tailwind.join(" "))}" title="Copy Tailwind classes">\u29C9 Tailwind</button></div>
          </div>`).join("")}`).join(""):D("No buttons, inputs, cards or badges found")}function Go(o){if(o.scanError)return $t(o.scanError);let e=o.system;return o.scanning||!o.scan||!e?D("Reading the page\u2026"):Rr(o,e)+Pr(o,e)+Ir(o,e)+zr(o,e)+Fr(o,e)+L(o,"system:components","Components",w.boxes,Dr(o.components,o.componentsLoading))+'<div class="pp-btn-row" style="margin-top:12px"><button class="pp-btn pp-btn-primary" data-pp-act="tab" data-pp-value="export">Export these as code \u2192</button></div>'}var Hr=["css","tailwind","scss","dtcg","json","md"];function Wo(o){let e=[];if(o.capture){let s=o.capture,p=s.layout.tailwind.length?`<div class="pp-sub"><span>Tailwind classes \xB7 click one to copy</span><button class="pp-card-copy" data-pp-act="copy" data-pp-copy="${f(s.layout.tailwind.join(" "))}">\u29C9 all</button></div>
         <div class="pp-tw">${s.layout.tailwind.map(c=>`<button class="pp-tw-chip" data-pp-act="copy" data-pp-copy="${f(c)}" title="Copy ${f(c)}">${f(c)}</button>`).join("")}</div>`:"",a=s.layout.rawCss.join(`
`),l=`
      <div class="pp-btn-row" style="margin-bottom:8px">
        <button class="pp-btn" data-pp-act="copy" data-pp-copy="${f(Ao(s))}">Copy as AI prompt</button>
        <button class="pp-btn" data-pp-act="copy" data-pp-copy="${f(a)}">Copy all as CSS</button>
      </div>
      ${p}
      ${a?`<div class="pp-sub"><span>CSS</span></div><button class="pp-code-copy" data-pp-act="copy" data-pp-copy="${f(a)}" title="Copy CSS"><pre class="pp-code">${f(a)}</pre></button>`:""}`;e.push(L(o,"export:element",s.selector,w.code,l))}let t;if(o.scanError)t=$t(o.scanError);else if(o.scanning||!o.system)t=D("Reading the page\u2026");else{let s=Ue(o.system,o.exportFormat);t=`
      <div class="pp-chips">${Hr.map(a=>`<button class="pp-chip" data-pp-act="export-format" data-pp-value="${a}" aria-pressed="${o.exportFormat===a}">${bt[a]}</button>`).join("")}</div>
      <div class="pp-btn-row">
        <button class="pp-btn pp-btn-primary" data-pp-act="export-download">${w.download} Download ${f(s.filename)}</button>
        <button class="pp-btn" data-pp-act="export-copy">Copy</button>
      </div>
      <pre class="pp-code">${f(s.text)}</pre>`}e.push(L(o,"export:system","Design system",w.tokens,t,{closed:!!o.capture,actions:Ye.replace('class="pp-btn"','class="pp-btn pp-btn-sm"')}));let r=o.clone,n=r?.warnings.length?`<ul class="pp-list">${r.warnings.map(s=>`<li>${f(s)}</li>`).join("")}</ul>`:"",i=o.busy?"Saving\u2026":r?"Download again":"Download as HTML";return e.push(L(o,"export:clone","Whole page as HTML",w.file,`<p class="pp-status" style="margin:0 0 10px">One HTML file with its styles, fonts and images inside, so it opens offline. Scripts are removed: it is a static snapshot.</p>
       <button class="pp-btn pp-btn-primary" data-pp-act="clone-run" ${o.busy?"disabled":""}>${w.download} ${i}</button>
       ${o.cloneStatus?`<p class="pp-status">${f(o.cloneStatus)}</p>`:""}
       ${r?`<p class="pp-status pp-ok">Saved ${f(r.filename)} (${r.sizeMb.toFixed(1)} MB).</p>${n}`:""}`)),e.join("")}function Ko(o){let e=o.capture?`<button class="pp-btn pp-btn-primary pp-btn-wide" data-pp-act="save-element">Save <b>${f(o.capture.selector)}</b></button>`:'<p class="pp-note" style="margin:0 0 8px">Select an element to save it here.</p>';if(!o.saved.length)return`${e}${D("Nothing saved yet.")}`;let t=o.saved.map(r=>{let n=r.url;try{n=new URL(r.url).hostname.replace(/^www\./,"")}catch{}let i=r.colors.map(s=>`<span class="pp-swatch" title="${f(`${s.role} ${s.value}`)}" style="background:${f(s.value)}"></span>`).join("");return`
        <div class="pp-saved">
          <div class="pp-saved-head"><b>${f(r.selector)}</b><span>${r.width} \xD7 ${r.height}</span></div>
          <div class="pp-saved-meta">${f(n)} \xB7 ${new Date(r.savedAt).toLocaleDateString()} ${i}</div>
          ${r.text?`<div class="pp-saved-text">\u201C${f(r.text)}\u201D</div>`:""}
          <div class="pp-btn-row" style="margin-top:8px">
            <button class="pp-btn" data-pp-act="saved-tailwind" data-pp-value="${f(r.id)}">Copy Tailwind</button>
            <button class="pp-btn" data-pp-act="saved-css" data-pp-value="${f(r.id)}">Copy CSS</button>
            <button class="pp-btn" data-pp-act="saved-remove" data-pp-value="${f(r.id)}">Remove</button>
          </div>
        </div>`}).join("");return`${e}<div class="pp-sub"><span>${o.saved.length} saved</span><button class="pp-btn pp-btn-sm" data-pp-act="saved-clear">Clear all</button></div>${t}`}function qo(){return`
    <div class="pp-account">
      <div class="pp-account-avatar" aria-hidden="true">?</div>
      <b>You are not signed in</b>
      <p class="pp-status">PixelPeek works fully without an account. An account is planned for things that need a server, such as syncing your Saved library between computers and sharing it.</p>
      <button class="pp-btn" disabled title="Not available yet">Sign in with Google</button>
      <p class="pp-note">Nothing you inspect leaves your computer today.</p>
    </div>`}var Br={responsive:w.responsive,phones:w.phone,tablets:w.tablet,desktop:w.desktop,watches:w.watch};function Yo(o){let e=o.deviceQuery.trim().toLowerCase(),t=i=>{let s=Se(i);return`<button class="pp-dev-row" data-pp-act="device-open" data-pp-value="${s.id}"><span>${f(s.name)}</span><span class="pp-dev-size">${s.category==="responsive"?"any size":`${s.width} \xD7 ${s.height}`}</span></button>`},r;if(e){let i=Ge.filter(s=>s.name.toLowerCase().includes(e)||We[s.category].toLowerCase().includes(e));r=i.length?i.map(s=>t(s.id)).join(""):D("No devices match")}else r=Object.keys(We).map(i=>{let s=Ge.filter(a=>a.category===i),p=o.deviceOpen===i;return`
          <button class="pp-dev-cat" data-pp-act="device-cat" data-pp-value="${i}" aria-expanded="${p}">
            <span class="pp-dev-cat-name">${Br[i]} ${We[i].toUpperCase()}</span>
            <span class="pp-dev-cat-count">${s.length} ${w.chevron}</span>
          </button>
          ${p?`<div class="pp-dev-list">${s.map(a=>t(a.id)).join("")}</div>`:""}`}).join("");let n=Se(Mo);return`
    <div class="pp-dev-search"><input type="search" placeholder="Search devices\u2026" value="${f(o.deviceQuery)}" data-pp-device-search aria-label="Search devices"></div>
    <div class="pp-dev-groups">${r}</div>
    <p class="pp-note" style="text-align:center;margin:12px 0 8px">Click a device to see this page inside it.</p>
    <button class="pp-btn pp-btn-dark pp-btn-wide" data-pp-act="device-open" data-pp-value="${n.id}">${w.phone} Quick Start ${f(n.name)}</button>
  `}var Q=o=>`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${o}</svg>`,Or=[{id:"inspect",label:"Inspect",icon:Q('<path d="M4 4l7 17 2.5-7.5L21 11z"/>')},{id:"figma",label:"Figma",icon:Q('<path d="M8 3h4a3 3 0 010 6H8z"/><path d="M12 3h4a3 3 0 010 6h-4z"/><path d="M8 9h4a3 3 0 010 6H8z"/><circle cx="15" cy="12" r="3"/><path d="M8 15a3 3 0 103 3v-3z"/>')},{id:"colors",label:"Colors",icon:Q('<path d="M12 3a9 9 0 100 18c1.7 0 2-1.2 1.4-2.2-.7-1.2.1-2.8 1.6-2.8H17a4 4 0 004-4c0-4.4-4-9-9-9z"/><circle cx="7.5" cy="11" r="1"/><circle cx="11" cy="7" r="1"/><circle cx="16" cy="8" r="1"/>')},{id:"fonts",label:"Fonts",icon:Q('<path d="M4 20l6-16 6 16M6.5 14h7M17 20h4M19 11v9"/>')},{id:"assets",label:"Assets",icon:Q('<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/>')},{id:"saved",label:"Saved",icon:Q('<path d="M6 3h12v18l-6-4-6 4z"/>')},{id:"system",label:"System",icon:Q('<path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5M3 17l9 5 9-5" opacity=".6"/>')},{id:"clone",label:"Clone",icon:Q('<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 012-2h10"/>')}],Nr=Q('<path d="M18 6L6 18M6 6l12 12"/>'),Ze=class{constructor(e,t){this.bar=document.createElement("div"),this.bar.className="pp-dock",this.bar.innerHTML=Or.map((r,n)=>`${n===1?'<span class="pp-dock-sep"></span>':""}<button class="pp-dock-btn" data-pp-dock="${r.id}" aria-pressed="false" title="${r.label}">${r.icon}<span>${r.label}</span></button>`).join("")+`<span class="pp-dock-sep"></span><button class="pp-dock-btn pp-dock-close" data-pp-dock-exit title="Close PixelPeek (Esc)" aria-label="Close PixelPeek">${Nr}</button>`,this.bar.addEventListener("click",r=>{let n=r.target;if(n.closest("[data-pp-dock-exit]")){t.onExit();return}let i=n.closest("[data-pp-dock]")?.dataset.ppDock;i&&t.onPick(i)});for(let r of["click","dblclick","mousedown","mouseup","pointerdown","pointerup","contextmenu"])this.bar.addEventListener(r,n=>n.stopPropagation());e.appendChild(this.bar)}setActive(e){for(let t of Array.from(this.bar.querySelectorAll("[data-pp-dock]")))t.setAttribute("aria-pressed",String(t.dataset.ppDock===e))}destroy(){this.bar.remove()}};var Zo="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAdMUlEQVR42o2befRlV1XnP/uc+6ZfVf2qUlVJhZCRqQNhCNgCylKkwyABgssmEVBAW5dTM7Qs1FZoEsCWBrtbF7asphUaQYEODdoDk0AjYFQCRlEhJgypTJXU9Kvf8H7v3XvPOXv3H+fce1+V9Fpda916w73v/s7eZw/f/d37Cv+Pf9eb+Q+LpO7zX9qp9Zvv3/fwzd3xRadjHMVlEoDugpTyh5Qgrn4HtDHhE4An+e6E78+nlEh4AHzK94wrN++u80CKafii+zYlqtHYZjMfL9xT3feLV5/45jVHjsy1u+Rm89wg6TvJKd9R+vIDsxvdK4++4YUP1tywE+R7F4GHJvE+KqiBWXktn7G8tlTOWXmfbBBGbbhWAU35c1Iw8r1M87nu/lq+6z7nkytHkdQBPqQ0Eu5dd/pnl+zVD932sunHmgRcb54P/2MlnKUAMxMBELGfu6N+3jGt3jx3/km7Aeo5xBY0JDOwbmGqw63M8qpVISUBjJRATTAMKwtXK2u3QZGpU2QRNN9LSAZq1isGZBDaikbpFSGYl6wJmCjsd/HWR63Xr//zV+z7jN5ojpswROwfKcDMRMSZ2Rvdy77+ht864atXbe5CvZOSqqGKU5x0gmPDYjHDyAvuFq+pvKrl75AVazEwyYIVxXXKNC3fm6EmvbVY+W2366L5t2dZQlGMqJkllAhU3k+Bi6rFW+/95T2/GswEy5s8KMBMuAmxm74xuuHvHnbzyYm/7szxmDQiSZ3rhEhlQWaCZan6Xet2wfrFGkmlV5aVP2NqvVnDcP2ggCKHUhRgSG8RWcn5BuVzUXz/vjOvEpMkkSyCnzp/oa8/eN/r/92PyQ03CTejiJhgJteD+6iTdN2X24+cnI1+eOvBFMxkFMuiUvHnwWwNM1f80XqztF6aznSLJaz6t4HqcH3RI5qkN/XOUkyLomFQgkp+r4aY0N+grE2QbClZ+PxeFQLBzfzoEl+/7/63zF4R3/i5ijc9I0oX7X/4S/Ubju+ZvGXrAW1VGfeBTrMprvpr76fdHy0Rq1uArvhyHyeK1XQuYLZ6XbaMXrkqmEo2ZwPnisul4vtdhCwKGYLY4AbWWYlKVoaCJQvVzI0ePp2/+o437/ttbjYvmMmrvtY8+q+2Rn+zuTCnEZcU6SP5ql/basS2Yo6ru9P9JguYFy2kZL17YJDUUHVZuTq4Tq/YbgeLydui394VIW0wf1bMvwttuqqszk3MUKd7qti+8Mrw6A+8cnZPJSJ2+xfaN86dG8U6RsWJaRbOEFQt36dTuBmpnBsCUj66WIFKMXfptaa9SZes0H+3ouiU/5CUnZMI2hovvjpx7VWCdxA1HyHl11aNkKCOsIywCLBTG/NGmNewtYT5UthZGLu1SFOr1a6a3XI8/aogPyOv/JvlFbc8OPr7nSAzS4aWTGglBZlZ9mdAKVG7U6xKjsapLDoV/9PBpLsd7WKBruT61bRHoigAnAmikHaMNz8/8Zpneh5cDEI2EYIaTRSamF/rYOwGYbsxtnaFnRo2l3B6Dpu7sLUL84WwbMzmtWNscfslTzzz6OrrJ+SGpfi11KZkJp4unZqhZgVjyJB+HZxxYJNiljVMasdYDZc6JVhvHV067FKj9qBI0GRZaMu/y5Hb0FphIVx1UeKnn+H41ibUwWjK75oI8wZCsoI0YV7DojWakGNL3UJdG20jxBZSAI1gScSlpLVU+794554XVluNe/bSMJIVdCCYaTH5DGC0cyER5h7+7dXGUw5Co7AMxitvFU48KFQRvBquAKFk4IpfhrLDjpwF+oC2KrwCtfJDPwg7h42rpoIlIZUAW4lw+4YyccKBcU7J928buy0cmAo4Yxng2BljMpIVK8uBVUqcEDBN2OZu9axq2cqVKSGu2xVWfBIwHCZZCcmDjYwXHREeOZUCI5Rf26ecmgt7p1BvQ5zD+IAx87C7ARpg7wEwU3Y3PHhj70FIjbHcEPzYmM6gnUPcFR7xaPj6QYfN88KjGZMKPn2X8sZPCvtHxm88H3Za4Y2fgGbX+NkfgIeswx/8hXLsfuEpVxoPPV+IsShci8XlgOYsIbXJY11KHLLWQJ1Y2SUrvpzfa++bWrDAmWC0Clsxv26o8NOPTdx1HfzoY4xajA88x/j2jxiPulgJa8anfkT59EuFak15yGHjj34KbnxRDi6PvsJ4+2vgWc9VrDU2l8KpTVjOQcVICohwfMcIp+HURjb3ZTB2zkB7BnZKjNg4Dew4duYQUz40ZSvQwRrEIqhyuDJzE9Ns3l2eL9C4dwMVMFe+j7C3grGDsct5aY/BR486vrZl3HkMJAr/+lbjwAzuOumQGv7l57M5hh3h1AJe+z+NnbkgQfj2PcZ//JCx8WD+3FYQ9kAMQ51wZmk882Ge+JzE+kQ4b02YRfi5ZxhbS3jYBULdCtc9WbjnAeWCw8JiaaTUWUEBW0qPRwQm8qgPJps34GQFSZaqrk+jRQHqYDGFp1yuHNkjtApe4VN3CPXp4sctSDIsrRQtWurbEuT6ejcJYobF/DuCQGM85Epj6eDaRxi/fr3j26eNNkIdYOxz5N+qc/RHhGWAzbkxr4VFyAHyzA5sL2BnCbtL2K1hWefgGIPRRM+BSZhXlABB59Id7NUBuJhAKgqY1HDLHZ7LLk5csdf409sr2AXXGtICUUgJXEmNXf53BUxoBJLDpSy4xZzvJQrWGtYaD3zJ4HgiXWdoNUZNCKoYwsk5bDcQ1VGHHISXrdAEYdEYO7Wwu4RFA8sWmpCzREwFwNlqLSxUfU6Ws3M0valIyQBgYvgkODVedSm87HLHRX+XU1aKZVfjEC8GNFbukwQJBk2b40oyJIIFCqoxCIGRRSINyBTVCVEVQTi1C392V97REHNmCVFoY/7cBKGNkt9HIwSIUWiCkQLESF+ed9C5spT9Wl0HWrpYoAOeH+qNngH679+Cvz1tpB2H1DKYuJ7zWvK8RQVxyMZx+Mp7s9TaYBoRFLE0sB9VhZ1pkVNPI8mLiUkRHPdtChtz8Ca0LbSpKCEVhUQIIbtLKAKHZKROcB3qkW59vQUMxYoVyCs9UtNUAJEJiVyc/OU3hb8UkFrKDnY3tVKJDVVZrwwEayK2fTQ7vbW9qXSQC0DjCJolGjf7apRS1FEgcCqRPaWCOYqJ53O5Wk1F+CyHYMlKNujKZ+sUIKiUNGEDkaG68uOSETxG28LPPU259jLhBb+vuOjQZAXQCHT5NhoSigRJQStcWzOaKEZV0GIqlWQq1aXh/QjzASdZ4R13EJMRYi6Ho0LbmX/Kpt5Gy2lPhRQLG9XD7ZLVVAZugeICGg2Rc6q/NMDYgekpzI/CpBJm41JuxhVzT2V1eNzGg8ht/xWjxZHQ+S6Pe/wF3Pz5t1K3WaoYjUVjbC6UE1uJE1uRY5vK1+5uuPSxB1jWlsFYuW1aKQr3zYwQsyLqYFTOaB0EEVyJ604gISxjUYJyVnaqupTUxwW1npDo/bfAWStxSgR+6/PCb90CsqBE9kJAJIHoM6qsG9j4JriAScJ25oxSxSMvP0woJElMMC9Fy9qmMToViNPEfXXArzmSGrFQaEmzITmBx16accZuIyzaLupLTndNTnfLJqe+EGE8gtNnshWLaV829y5gBXGdFfg6fq68DsQGPPKwcuF+44snPNIpMZFNvm1APT42TPdW4PKOREuMJ1M2tiNNzOYf2sSiNk7tRE5vJjY3E9tbRr2TiM2EZGtEBbFcE4QozCbGob3CYglNm12yDdC2QgicdaSCBitvOCnprC/l+xhgfXlr55CdGRdYjwu8ZJe57gnGtVc6rrkNXDRSSCAVcu9X8Hd8iFS3XPWES3nfn7yNEJTZRNi/Zvz1t4XHvmILGU+Rjb/AHrgZkxEpLdHUoJrQ2ZOpt9ZZe9EjsRc8nZQSzmWSxQTqBo6eMg7tERJSPM8KV2DELigW4VOCRUmdOb+vxoCebu4wgBWayXpf0VS4OYVUCP3P3S7ctWHQ5EID9SCCLbaJO/diy0CV1rj04oPsLuG8dVgbwX3bygMntmDi4WSA+0+Cm0DaAa2BhOzfweZCaOocBIvVpRUO8Wv3gnPW44A25NQYkhDL7scu98d8nXUR3gaUWnVRXswKoyMDlV2YHbr0WCxEgNu+Ltz2DyA10CakaYGKkQtM1ypa75lNZzStEUJkey7oVNhZRMQ1uGqCjBI2zrs6mU2p/BjTSBg7GmkwUnbLjmgtKRmXlT5fCiGWvB8z5o/RiNHQIMSY6TiN5R5phUIriqxUB769s4CepkrWp8UsvOANUoQfenbiKQ83fuVdY6qvfhI5+knizoKXvPz7ef3v/w4nNyIH1ifs3wP7Zp5r31DzjfsqNG5iZ76Mbq3hdv+asXuA5ZldXv/rr+XlL3kB9xxPvOq1b+avj34Rwoio11IwVFFGtshRpVy8N+90HaCNlmFvm4/QQohWlEIPhkKT5RqyQCl7u0Zfz+mtdGM6gjNr0CAK1Ujwk+I79TY2vxfbXrBvolxy2SFme2AyhsplcuW+045jx7NriRYobBEvDWjDofP2cclDDmETGFUJdAfTZd9ac4VOiyZ4Zzz6oTkNL+rMFtWNsGyFujYWjdA00HTBMWT/V4Wlg8X8XCi8Qlt1lHLH5fWUVdFYKtbyvz7r+fjnQHYhpSbnU5fft41RNxGHw9YciDEZC25sOHMkM0RkoJFFWC5rdpcNO1sFayAgjti1zaTwlAqjCiYjaBpog9GGnA2aJhc/IWbXiCtBsDucFIo8l8NUxIJGCwO8qoysAFkpkBTE43Y3aT/3Tpzuws4mr/rZZ/DjL3oHp063XHHpQaYjuPCQw4lQ+YIkHyPoRWP8iTNUX3034sdI2iGZZ7K+xtt+83f5nXf9ISEapzd3wE9JqqWWyiYbSwBf1MKdDxgH91jm/tqcGeqmuENTUmMUYrAVFxCaWld6CUZlmuGriQ7dmK5JoVJYoZUmhABNjWx+HScL0qmTXHTes3jCVZdzYgPWZiCWmFRD51HEYL182FWcbvStHAPEO06d3uD4iVOAMB6vgfjSPyxlrBtqJcE4tgH3nizVX5sjfohGCEIqQmu0wYq7DbRC/JUSt7K+pTWYeY+XV1nb7rx0Pe5dkCVow6jKZOdonM1TpCAuWWlaNOUImiOU90PbxxKjUUVVdVE6gLWYxbPrk6IAJwWVhi7q50AXiyJSyLtt0VYbpkPrzopGk1FpygjP2crur/D2q/33XA8bNjsPrv5lUmhxQXjfp+/iL269iZ0zkRdc9zR+4uXPZXM7MhkLB9byLvonZsbIP3Ap4d53wnSKv/tzyN//HjaaZXhqDkstXPELcPgy7ODhrAAczoZZAzVhbWocOW+I+k0rNI3RtkbbZiwQA8x3StzqO0ddL1Mx1QKEUteRtb6poQqipUKiY0Ry0DI3ZXTVU/EO6g346pdu56vf+hS0kYdcegE/9tLnMN9NJPWsz3LyGF3g8BhO9pEu/R6Ygts+BmKI9zkD4TAnsPefwORJ6LTpO0la1heiYzIyLj+Sl7OooalgXMHYQ+Oh9UbjIY1y5to6Y1hX2GgJ/wXsVT3px0rP/jtOYWT/8UAKyvP+WeS7HxN5/dsmjKZGtV7RbhmHDkzZP3PEQxPGHpzL6t9uckttUSfYaUEn2O42trOAUGUE6ByWlkhcQlxixFymm/VN16S5Zomlzk+pEB/BsvkXd9CuMOuwvayMnfQtqrSSBlnJ/V03FSvRRweFCH3XVXwF5tDzv59WDqLLyP++5RTHfuotzOfw8Eddwht/6ccJIfH28yGMjG9NjLc8vUJGwuy7vo/Zj7wHdWN27oH6mCBRYf1xcGwK65aRnAhCaZCQzf1bDxh7prnuatpcCLWNEVshFApMk7GYFwF1dXhhCCpV174SsbOIUER6Po+V+iCpQAV//HHPH/+JIQslrT0Czr8QonLH0Zu545ZPQAtXPvVx/NJrXsZiqbzgIIwm8NUD8LZHeJzCdN/F7Nl/MRFY/C3onSANuARSR2yiA6FB3vmUwIuxOYfjp+l9XSPEIMTWIEBf2q62nFcHFTRD2h4Kd2BPOmqsKxq05E3L57qi6bLzlSP74da/kozsaMCPcWsjxuuesICD+0ccOuTZW3v8tMTQNdiepwx+SNRmJG9s7QBzB42RnEA7DFzFrs/Y0XSlqPNiKIIrlatYCeYY1nVkdUX4vqWebyyqnQtYbnysjqH05XDuqXXKqySnm5dfAy/+brjqZ0DwUE1yuXrgaoI5tG75xunAT/38O1BTxiOHjy3Tiy7kP73iJWhKVBX4Kjc7tx5pnFmPbG0bp7eVu1PgwvWKNla5FijkiWoxzr5KLVMsfXd5yJdiOpT1usrz90wPlRUq23yOAx0r1Pf+V2YO6Pr/TrjtqOGcgVVlTqHKuXvPFaTRRdC2nDzzd7z/3e/IIAGDepfHPPXx/PbrXkrTKiIuNzwwtg4lToyVu09FjrrEeCOwf6IEnZG6eYWV2aK+1o+FsFHBVEsmy6ZvqzN2Z1V93TWRqq+MKEGPlXZQISmHSYw8LsPI+NhnPB+LGfWp5BIV9ZnulgSVw83G+P0jTMA7Ic0j5x0Yw9Thpg4BvIGrPfgRFsAmShglUhVQJ0TNh0ZYn8Gl52fLbttc2YU28wCxpbTCpTDBI1JQmkWDpZT73KYFb1hp4ycqSSl/MApyk37gqHeDfpouU1upFa75gcTVl8B/+IBDJJfKiCDOY9UUnGFrl5COvAQLSxTF9rR847TjJ1/92/2wp1pmcNooLIMxrx3zZsTpky2Pf/qVXPXUa9BkxNLenlU5JLkE3mUgKU5wYuBAnOK8oRgyEqKDqJpjQgE/Qo5ropHKomYqu2OJxJ9FGZ01TSiCuLzBz3gcvPifwm9+JJOgZgmcK/y+z342OYQevgbCLhYaEOHEzjd4z7vemec6ZSW3igNXgUxgMoXtlksfNcXcMEwVY955SwPsDQ3E1gitEVtDo6HJSClnEDTRNwdWB5DKuSrfeVVKI49agjl/lhJEQKsciX/3zx2fvDOhgbwV5oosHlyOJpYAF6HyIFUefxmP8QfWMMkBRso4DniQMcYIYUqqRogf9+AnJtenO0t55iCVKq/7zjQLr6nzfxvq4I746IBOypG0kp5mkUFKyZO3ogkKPJUyfqreuPwxxvpe48SO46onKf9wu8e2R4iPBW9YNksEFQFfITpBkqJ6IenAMxGtQWNeLJkfMATTMeMjh0gXeFh/ZKnpXS+HxlzthZCtIEWIQYlBScFI0VDVrAgzTBNYQEqzw7r2Uikvq2FauTNDl4MFmasTGYhEE4Gp8u9fpjz5Es9OgFqUG96W+NZXHYxGOZ04RZNkCtlFsIgFn7dqNsEOPz/3rtMCqh0ICasFfEKmjvV/8TROtTPSzEiNoprr+o6b0LKJeepD+4nUVCq+vNHZCqyYiNlq23vICpUlLUhDVgb+pNDnPuMDWRlS9kY02KhhuwU/FpbeuPZ5idc83fMbHxc+8+kR/+YXlMdeLvzSfx5x9z1j3v46Q/yUX/k1z3mzMb/4ugu54+iSd994lEu+a8bTX30RX/nsFv/w3nvwM4VWMVFUXZ//dxfGgyfyVFqGvansvKIhYimVQi6DIE0Ra+uVcdU0KKG08CrRWPpNrjh59z5H1Zz/pUCsXBV6L/hK8Jrjlh8ZJ5bCl08qG0uDkfDNDYhTo44CHu48AYZi1YjWV9z54IhjGw7W9tPohAfvnjA/M4HRGn7NQ3QkZ6Xjm3t/Z7aM02cUjxGaRIqR1KYV/rubxYsD/i++n7vPsc8GHUFSDR1ENwhON59aGBAnoC53fBvhayeVap+yG4TFjtLuwldu83zlC1Z6Z4kP/mHBDuV+v/fOQulUytZO5PfeGiA2MIYTd835zJt2wC3BBdr7a8R5dKyEOCKl7PNVqU+0+LIlRbT4dY/7O+E7jB8LIsysqHT+Uwq+KrZhSZJZHvd04HyeFDS/0kUtIy9OkEa46f1CdSgH9rgt2P2CS4aLCY0JVcUXNqgbrPIOcDk9CYqbBSy2aHBI5XAHarRNWDA23n8U2zV49n7CEx9Giom2Ec5bhyOHhfncET1E50kuW7NREpEKpg5IWApIl93KYPUqGDLTUFW0m+hoRkwm4vMsi+TRuL57gGcIBh455YinS3oMuYTVoJhmP8Q0jwPYAKDy8xMl7ZUeveHB+TyNquPsZr4BW0K7ZLnrCDHP9IQ2NzkeesSxu89TL416CfVCaZpIDDHHg5hIIaAxgbRYyoMYeQSoG0nVTEVrPFGNJNwOowtJwUw0j4Q5PwREV1790CES58vQYTf+kpCUMI3Dlhfg1ClAijdZ11/vzruqmNm4PMNgmctbc9z7zS3mmxHE09SJ0MByabQ1tEsh1Im2TcQ2koISQ8JCzOvoqGAt4CHFbl4ONCmM3MTp1/0Fj//5I9tL/2xLjYqpE86dh2d1dq4gK10h2yOSQja34pOyQioKKw0HVcS6aeNVstEKAOsexFDEQ31mwfaZXS58+AWEVBGSK4DIEaIjJk9Inpgcqq4MRHJOBZjX2+EAsYRZwjtxFx1M76ie9PD0kROntt+0iDLFJTN1gvgytZzKkXO4SDHZlZqBjm0tryI6sMzIcK0UbywxJY8fWz8aI1Ku9RXCCAsJmU345q33cfzoKQ5ecj5mFW1QYttRYIkUlZQSGiOqqYzvn53rOzY4zwVkimky1c2nP3H//xAncMFzv/wHx7f2/ShpK5rzFeIZDjccrsrFDqUAGh44WmFcVyupAq4gD0jJUGHKWZWmldTVLTxAWEKoEV1gzSJ/1pgLEQrH10V8GR4oEudKnQGGz5smHpP8vSARv7966OHmXfd/4UU/69RMrrpC3zx1260lE7S1DLRbSA2Smvw+NhBrCDXEGgvL/DnW+Vx3XWoL9Czzb9oW4B7682IR04BozHBb0+roXv7P+zwt5kbIZIrM9iBre5DZGm6yhoxmyGgNRmuIX4NqCtUEpMrchIwRqRjAjEMMs+RlNqp3v+fq/b9umHiuv8kffe/Fpy55wsvDTrv/2RoWEVO/8iTDOcOD3fBtN0TUCZDOLjZW3ot1z7SlAkRKnOioK/TsuNDFj9LAKw/d5R22XESZWYknDK1tDNf178lzjVIoMjHDVONosre67Pz0r7743677LNdf5bODXn+zqz56Qzr0A3/6gRPb+19i8UwQ50dWXCD7JyvaHHw6+7hbKRnPnsSU1TjQFVtdZujdQIbJp45+1thHb9FsjZ3VYKHPONK1tAvYkTLJKHZWRW+mEp1fHx05r/kvJ/7qFT+Tvu/Gis+/Ka6gBMTsw3LBMw5/8PRi/Xptt1J2X+/NrczWILn1Je7s5y77YEd/TXe9iSDiMArxuBpEV5946lesZz9qkmKeHilwNqe2kCO6pozuJGcoK5FepG+FJVPEj/a6A3vjezb/9id+Mun1Hm7WgeZdefpoVIld9Mz/8/YHN/wvNq2ALVVETETE+pW7f5TnrQwgicu7bF03qbOc8j0mg0XZOVbTB8WzH0QUUyy1iMYMaVPZaeuAV8H6pphGE1MTS6qmDiZuOjI9fNDd9MCXf+ItSW90cFPPdp6zDZ2hiz3hn//JNfecrN48X7rvbYLPaKp7lMuGR09zzbDKIHVm7gbh+0yyYiU2WMvQcbFzpplX/NvSAGZIQ8GT4hBzNJRHTR0ijrGP7N8nX3jYEf+rX/rEj91i3OjgTXbOar/j09MebkijCr7rRZ/7wWMn0ou3F+F762CXqMnUylBDFqIIuvLcYP9dZwWuS4eyYv6r150tb68WYyUwpsElKIguhT6g5pnjhJe0HHu9e33m/+yyh0w+dOvHr/9sGwaZ/v+eHge4/mbPh/MPHJDsrum1rzxx6amT8wsXmzs+VlBFiFVFBURiodZKm3vlXyxXVHkeg+50PPfCci5G8j0idH+n/IXhbjH21xMzt7//vD3xgvP2H/+j3/2+u7xI6AA319/sOlnO/fd/AeNOCzuVUPyFAAAAAElFTkSuQmCC";var St="pp-pill-pos",Ce=40,se=8,Vr=250,jr=4,Ct=o=>`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${o}</svg>`,Ur='<svg width="12" height="18" viewBox="0 0 38 57" aria-hidden="true"><path d="M19 28.5a9.5 9.5 0 1 1 19 0 9.5 9.5 0 0 1-19 0z" fill="#1ABCFE"/><path d="M0 47.5A9.5 9.5 0 0 1 9.5 38H19v9.5a9.5 9.5 0 1 1-19 0z" fill="#0ACF83"/><path d="M19 0v19h9.5a9.5 9.5 0 1 0 0-19H19z" fill="#FF7262"/><path d="M0 9.5A9.5 9.5 0 0 0 9.5 19H19V0H9.5A9.5 9.5 0 0 0 0 9.5z" fill="#F24E1E"/><path d="M0 28.5A9.5 9.5 0 0 0 9.5 38H19V19H9.5A9.5 9.5 0 0 0 0 28.5z" fill="#A259FF"/></svg>',Et=[{id:"inspect",label:"Inspect elements",short:"Inspect",desc:"Hover any element to read its styles. Click it to select it.",svg:Ct('<path d="M4 4l7 17 2.5-7.5L21 11z"/>')},{id:"devices",label:"Responsive preview",short:"Responsive",desc:"See this page inside phone, tablet and desktop frames.",svg:Ct('<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>')},{id:"saved",label:"Saved",short:"Saved",desc:"Elements you saved, kept on this computer.",svg:Ct('<path d="M6 3h12v18l-6-4-6 4z"/>')},{id:"figma",label:"Copy to Figma",short:"Figma",desc:"Copies the selected element, or the one under your pointer, as editable Figma layers.",svg:Ur}],Gr=`<img src="${Zo}" alt="" width="28" height="28" draggable="false">`,Xe=class{constructor(e,t){this.callbacks=t;this.left=16;this.top=0;this.closeTimer=0;this.noteTimer=0;this.dragging=!1;this.pressed={inspect:!1,devices:!1,saved:!1,figma:!1};this.onResize=()=>this.place();this.top=Math.max(se,window.innerHeight-Ce-24),this.el=document.createElement("div"),this.el.className="pp-pill",this.el.innerHTML=`
      <div class="pp-pill-card" role="toolbar" aria-label="PixelPeek tools">
        <button class="pp-pill-mark" title="Drag to move" aria-label="PixelPeek tools: drag to move">${Gr}</button>
        ${Et.map(n=>`<button class="pp-pill-btn" data-pp-pill="${n.id}" aria-label="${n.label}" aria-pressed="false"><span class="pp-pill-ico">${n.svg}</span><span class="pp-pill-tip">${n.label}</span></button>`).join("")}
      </div>
      <div class="pp-pill-note" role="status"></div>`,this.card=this.el.querySelector(".pp-pill-card"),this.note=this.el.querySelector(".pp-pill-note");for(let n of["click","dblclick","mousedown","mouseup","pointerdown","pointerup","contextmenu"])this.el.addEventListener(n,i=>i.stopPropagation());this.card.addEventListener("mouseenter",()=>this.open()),this.card.addEventListener("mouseleave",()=>this.scheduleClose()),this.card.addEventListener("focusin",()=>this.open()),this.card.addEventListener("focusout",()=>this.scheduleClose()),this.card.addEventListener("click",n=>{let i=n.target.closest("[data-pp-pill]");i&&this.callbacks.onTool(i.dataset.ppPill)});let r=this.card.querySelector(".pp-pill-mark");r.addEventListener("pointerdown",n=>this.startDrag(n,r)),window.addEventListener("resize",this.onResize),e.append(this.el),this.place(),this.restore()}destroy(){clearTimeout(this.closeTimer),clearTimeout(this.noteTimer),window.removeEventListener("resize",this.onResize),this.el.remove()}setVisible(e){this.el.style.display=e?"":"none"}setState(e){Object.assign(this.pressed,e),this.card.querySelectorAll("[data-pp-pill]").forEach(t=>{t.setAttribute("aria-pressed",String(this.pressed[t.dataset.ppPill]))})}flash(e){this.note.textContent=e,this.note.classList.add("pp-pill-note-on"),clearTimeout(this.noteTimer),this.noteTimer=window.setTimeout(()=>this.note.classList.remove("pp-pill-note-on"),1800)}open(){clearTimeout(this.closeTimer),this.card.classList.add("pp-pill-open")}scheduleClose(){this.dragging||(clearTimeout(this.closeTimer),this.closeTimer=window.setTimeout(()=>{this.card.matches(":focus-within")||this.card.classList.remove("pp-pill-open")},Vr))}clamp(){let e=Math.max(se,window.innerWidth-Ce-se),t=Math.max(se,window.innerHeight-Ce-se);this.left=Math.min(Math.max(se,this.left),e),this.top=Math.min(Math.max(se,this.top),t)}place(){this.clamp(),this.el.style.left=`${this.left}px`,this.el.style.top=`${this.top}px`,this.el.classList.toggle("pp-pill-up",this.top+Ce/2>window.innerHeight/2),this.el.classList.toggle("pp-pill-left",this.left+Ce/2>window.innerWidth/2)}startDrag(e,t){if(e.button!==0)return;e.preventDefault();let r=e.clientX,n=e.clientY,i=this.left,s=this.top,p=!1;t.setPointerCapture(e.pointerId);let a=c=>{let d=c.clientX-r,h=c.clientY-n;!p&&Math.hypot(d,h)<jr||(p||(p=!0,this.dragging=!0,this.el.classList.add("pp-pill-dragging")),this.left=i+d,this.top=s+h,this.place())},l=()=>{t.removeEventListener("pointermove",a),t.removeEventListener("pointerup",l),t.removeEventListener("pointercancel",l),t.hasPointerCapture(e.pointerId)&&t.releasePointerCapture(e.pointerId),this.el.classList.remove("pp-pill-dragging"),this.dragging=!1,p&&this.save()};t.addEventListener("pointermove",a),t.addEventListener("pointerup",l),t.addEventListener("pointercancel",l)}async restore(){try{if(typeof chrome>"u"||!chrome.storage?.local)return;let e=(await chrome.storage.local.get(St))[St];e&&typeof e.left=="number"&&typeof e.top=="number"&&(this.left=e.left,this.top=e.top,this.place())}catch{}}async save(){try{if(typeof chrome>"u"||!chrome.storage?.local)return;await chrome.storage.local.set({[St]:{left:this.left,top:this.top}})}catch{}}};var Wr="pp-panel-pos",Kr='<svg width="10" height="16" viewBox="0 0 10 16" fill="currentColor" aria-hidden="true"><circle cx="2.5" cy="3" r="1.3"/><circle cx="7.5" cy="3" r="1.3"/><circle cx="2.5" cy="8" r="1.3"/><circle cx="7.5" cy="8" r="1.3"/><circle cx="2.5" cy="13" r="1.3"/><circle cx="7.5" cy="13" r="1.3"/></svg>',qr=[{id:"styles",label:"Styles"},{id:"figma",label:"Figma"},{id:"assets",label:"Assets"},{id:"system",label:"Design System"},{id:"export",label:"Export"}],Ee=o=>`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${o}</svg>`,Tt={inspect:Ee('<path d="M4 4l7 17 2.5-7.5L21 11z"/>'),device:Ee('<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>'),saved:Ee('<path d="M6 3h12v18l-6-4-6 4z"/>'),account:Ee('<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>'),close:Ee('<path d="M18 6L6 18M6 6l12 12"/>')},Je=class{constructor(e,t,r){this.backend=t;this.callbacks=r;this.anchor=null;this.toastTimer=0;this.alive=!0;this.s={capture:null,scan:null,scanning:!1,scanError:null,system:null,components:null,componentsLoading:!1,failingOnly:!1,guidesOn:!1,assets:[],assetsLoading:!1,assetStatus:{text:"",tone:""},busy:!1,figma:null,figmaStatus:{text:"",tone:""},exportFormat:"css",clone:null,cloneStatus:"",saved:[],deviceQuery:"",deviceOpen:"phones",cards:{}};this.tab="styles";this.mode="main";this.inspecting=!0;this.lastDock="colors";this.pos=null;this.onWindowResize=()=>{this.pos&&this.movePanel(this.pos,!1)};this.el=document.createElement("div"),this.el.className="pp-ov",this.el.innerHTML=`
      <div class="pp-ov-nav" data-pp-nav></div>
      <div class="pp-ov-body" data-pp-body></div>
      <div class="pp-ov-foot" data-pp-foot></div>
      <div class="pp-toast" data-pp-toast></div>
    `,this.nav=this.el.querySelector("[data-pp-nav]"),this.body=this.el.querySelector("[data-pp-body]"),this.foot=this.el.querySelector("[data-pp-foot]"),this.toastEl=this.el.querySelector("[data-pp-toast]"),this.el.addEventListener("click",n=>this.onClick(n)),this.el.addEventListener("input",n=>this.onInput(n)),this.el.addEventListener("pointerdown",n=>this.startPanelDrag(n)),this.el.addEventListener("dblclick",n=>{n.target.closest(".pp-ov-tools")&&!n.target.closest("button")&&this.movePanel(null)}),window.addEventListener("resize",this.onWindowResize);for(let n of["click","dblclick","mousedown","mouseup","pointerdown","pointerup","contextmenu"])this.el.addEventListener(n,i=>i.stopPropagation());this.pill=document.createElement("button"),this.pill.className="pp-exit-pill",this.pill.innerHTML=`${Tt.close}<span>Stop inspecting</span><kbd>Esc</kbd>`,this.pill.addEventListener("click",()=>this.callbacks.onExit());for(let n of["click","dblclick","mousedown","mouseup","pointerdown","pointerup","contextmenu"])this.pill.addEventListener(n,i=>i.stopPropagation());this.dock=null,e.append(this.pill,this.el),this.tools=new Xe(e,{onTool:n=>this.onPillTool(n)}),this.render(),this.loadForTab()}destroy(){this.alive=!1,window.removeEventListener("resize",this.onWindowResize),clearTimeout(this.toastTimer),this.el.remove(),this.pill.remove(),this.tools.destroy(),this.dock?.destroy()}setCapture(e){this.s.capture=e,this.s.figma=null,this.s.figmaStatus={text:"",tone:""},e&&(this.mode="main",(this.tab==="assets"||this.tab==="system")&&(this.tab="styles")),this.render(),this.tab==="assets"&&this.mode==="main"&&this.refreshAssets()}setInspecting(e){this.inspecting=e,this.render()}get collapsed(){return this.inspecting&&!this.s.capture&&this.mode==="main"}goTo(e){if(e==="inspect"){this.inspecting=!0,this.callbacks.onInspectToggle(!0),this.mode="main",this.anchor=null,this.render();return}if(this.inspecting&&!this.s.capture&&(this.inspecting=!1,this.callbacks.onInspectToggle(!1)),this.anchor=null,e==="saved"){this.mode="saved",this.loadSaved(),this.render();return}let t={figma:["figma",null],colors:["styles","colors"],fonts:["styles","typography"],assets:["assets",null],system:["system",null],clone:["export","clone"]},[r,n]=t[e];this.tab=r,this.mode="main",this.anchor=n,n&&(this.s.cards[`${r}:${n}`]=!0),this.lastDock=e,this.render(),this.loadForTab()}dockActive(){if(this.mode==="saved")return"saved";if(this.collapsed)return"inspect";if(this.mode!=="main")return null;switch(this.tab){case"figma":return"figma";case"assets":return"assets";case"system":return"system";case"export":return this.lastDock==="clone"?"clone":null;default:return this.s.capture?null:this.lastDock==="fonts"?"fonts":"colors"}}get isInspecting(){return this.inspecting}async ensureScan(e=!1){if(!(this.s.scanning||this.s.scan&&!e)){this.s.scanning=!0,this.s.scanError=null,this.render();try{this.s.scan=await this.backend.scan(),this.s.system=wo(this.s.scan)}catch(t){console.error("[PixelPeek] Could not scan this page",t),this.s.scanError=t instanceof Error?t.message:String(t)}finally{this.s.scanning=!1,this.alive&&this.render()}}}async loadComponents(){if(!(this.s.componentsLoading||this.s.components)){this.s.componentsLoading=!0,this.render();try{await new Promise(e=>setTimeout(e,30)),this.s.components=await this.backend.scanComponents()}catch(e){console.error("[PixelPeek] Could not scan components",e),this.s.components=[]}this.s.componentsLoading=!1,this.alive&&this.render()}}async refreshAssets(){this.s.assetStatus={text:"",tone:""},this.s.assetsLoading=!0,this.render();try{this.s.assets=await this.backend.collectAssets()}catch(e){console.error("[PixelPeek] Could not collect assets",e),this.s.assets=[],this.s.assetStatus={text:e instanceof Error?e.message:"Could not read the assets on this page.",tone:"warn"}}this.s.assetsLoading=!1,this.alive&&this.render()}async loadSaved(){this.s.saved=await Co(),this.alive&&this.render()}loadForTab(){this.mode==="saved"&&this.loadSaved(),this.mode==="main"&&(this.tab==="assets"&&this.refreshAssets(),this.tab==="styles"&&!this.s.capture&&this.ensureScan(),this.tab==="system"&&(this.ensureScan(),this.loadComponents()),this.tab==="export"&&this.ensureScan())}toast(e){this.toastEl.textContent=e,this.toastEl.classList.add("pp-toast-on"),clearTimeout(this.toastTimer),this.toastTimer=window.setTimeout(()=>this.toastEl.classList.remove("pp-toast-on"),1500)}async copy(e,t="Copied"){if(e)try{await we(e),this.toast(t)}catch{this.toast("Could not copy")}}onInput(e){let t=e.target;if(!t.matches("[data-pp-device-search]"))return;this.s.deviceQuery=t.value,this.renderBody();let r=this.body.querySelector("[data-pp-device-search]");r?.focus(),r?.setSelectionRange(r.value.length,r.value.length)}onClick(e){let r=e.target.closest("[data-pp-act], [data-pp-tab], [data-pp-top-btn], [data-pp-panel-tool]");if(!r)return;let n=r.dataset.ppPanelTool;if(n){this.onPillTool(n);return}let i=r.dataset.ppTopBtn;if(i){this.onTopButton(i);return}if(r.dataset.ppTab){this.setTab(r.dataset.ppTab);return}let s=r.dataset.ppValue??"";switch(r.dataset.ppAct){case"tab":this.setTab(s);return;case"deselect":this.callbacks.onDeselect();return;case"card":this.s.cards[s]=r.getAttribute("aria-expanded")!=="true",this.render();return;case"copy":this.copy(r.dataset.ppCopy);return;case"rescan":this.tab==="assets"?this.refreshAssets():(this.s.components=null,this.ensureScan(!0),this.tab==="system"&&this.loadComponents());return;case"failing":this.s.failingOnly=!this.s.failingOnly,this.render();return;case"guides":this.s.guidesOn=!this.s.guidesOn,this.callbacks.onGuides(this.s.guidesOn),this.render();return;case"asset-dl":this.downloadOne(s);return;case"assets-zip":this.downloadZip(s);return;case"export-format":this.s.exportFormat=s,this.render();return;case"export-download":{let p=this.currentExport();p&&Be(p.text,p.filename,p.mime);return}case"export-copy":this.copy(this.currentExport()?.text);return;case"clone-run":this.runClone();return;case"figma-run":this.runFigma(()=>this.backend.buildFigma(s),s==="page"?"the whole page":"the visible area");return;case"figma-element":this.runFigma(()=>this.callbacks.onFigmaElement(),"the element");return;case"figma-copy-pending":this.copyFigma();return;case"save-element":this.s.capture&&this.callbacks.onSaveElement(this.s.capture).then(()=>this.loadSaved()).then(()=>this.toast("Saved")).catch(()=>this.toast("Could not save"));return;case"saved-css":case"saved-tailwind":{let p=this.s.saved.find(a=>a.id===s);p&&this.copy(r.dataset.ppAct==="saved-css"?p.css.join(`
`):p.tailwind.join(" "));return}case"saved-remove":Eo(s).then(()=>this.loadSaved());return;case"saved-clear":To().then(()=>this.loadSaved());return;case"device-cat":this.s.deviceOpen=this.s.deviceOpen===s?null:s,this.render();return;case"device-open":{let p=Se(s);p&&this.callbacks.onOpenDevice(p);return}}}onTopButton(e){if(e==="inspect")this.inspecting=!this.inspecting,this.callbacks.onInspectToggle(this.inspecting),this.mode="main";else{let t=e;this.mode=this.mode===t?"main":t,this.mode==="saved"&&this.loadSaved()}this.render()}movePanel(e,t=!0){this.pos=e;let r=this.el.style;if(!e)r.left=r.top=r.right=r.bottom=r.height=r.maxHeight="";else{let n=this.el.offsetWidth,i=Math.min(Math.max(0,e.left),Math.max(0,window.innerWidth-n)),s=Math.min(Math.max(0,e.top),Math.max(0,window.innerHeight-80));this.pos={left:i,top:s},r.left=`${i}px`,r.top=`${s}px`,r.right="auto",r.bottom="auto",r.height=`${Math.max(240,window.innerHeight-s-12)}px`,r.maxHeight=`calc(100vh - ${s}px - 8px)`}if(t)try{typeof chrome<"u"&&chrome.storage?.local&&chrome.storage.local.set({[Wr]:this.pos})}catch{}}startPanelDrag(e){let t=e.target,r=t.closest(".pp-ov-tools");if(!r||t.closest("button")||e.button!==0)return;e.preventDefault();let n=this.el.getBoundingClientRect(),i=e.clientX,s=e.clientY;r.setPointerCapture(e.pointerId),this.el.classList.add("pp-ov-dragging");let p=l=>this.movePanel({left:n.left+l.clientX-i,top:n.top+l.clientY-s},!1),a=()=>{r.removeEventListener("pointermove",p),r.removeEventListener("pointerup",a),r.removeEventListener("pointercancel",a),r.hasPointerCapture(e.pointerId)&&r.releasePointerCapture(e.pointerId),this.el.classList.remove("pp-ov-dragging"),this.pos&&this.movePanel(this.pos)};r.addEventListener("pointermove",p),r.addEventListener("pointerup",a),r.addEventListener("pointercancel",a)}onPillTool(e){if(e!=="figma"){this.onTopButton(e);return}if(this.s.capture){this.runFigma(()=>this.callbacks.onFigmaElement(),"the element");return}this.notify("Building Figma layers\u2026"),this.callbacks.onFigmaHovered().then(t=>this.notify(t)).catch(()=>this.notify("Could not copy: try again"))}notify(e){this.collapsed?this.tools.flash(e):this.toast(e)}setTab(e){this.inspecting&&!this.s.capture&&(this.inspecting=!1,this.callbacks.onInspectToggle(!1)),this.tab=e,this.anchor=null,this.mode="main",this.render(),this.loadForTab()}currentExport(){return this.s.system?Ue(this.s.system,this.s.exportFormat):null}async downloadOne(e){let t=this.s.assets.find(r=>r.id===e);if(t){try{let r=await this.backend.downloadAsset(e);this.s.assetStatus=r?{text:`Saved ${t.filename}`,tone:"ok"}:{text:`${t.filename} is blocked by the site, so it opened in a new tab to save by hand.`,tone:"warn"}}catch(r){this.s.assetStatus={text:r instanceof Error?r.message:String(r),tone:"warn"}}this.render()}}async downloadZip(e){let t=e==="all"?this.s.assets:this.s.assets.filter(r=>r.kind===e);if(!(!t.length||this.s.busy)){this.s.busy=!0,this.s.assetStatus={text:`Preparing 0 of ${t.length}\u2026`,tone:""},this.render();try{let r=await this.backend.downloadZip(t.map(n=>n.id),(n,i)=>{this.s.assetStatus={text:`Preparing ${n} of ${i}\u2026`,tone:""},this.alive&&this.render()});this.s.assetStatus=r.saved?{text:`Saved ${r.saved} file${r.saved===1?"":"s"}${r.skipped?`; ${r.skipped} blocked by the site were left out.`:"."}`,tone:r.skipped?"warn":"ok"}:{text:"The site blocks reading these files, so nothing could be zipped. Use each file's download button.",tone:"warn"}}catch(r){this.s.assetStatus={text:r instanceof Error?r.message:String(r),tone:"warn"}}this.s.busy=!1,this.alive&&this.render()}}async runFigma(e,t){if(!this.s.busy){this.s.busy=!0,this.s.figma=null,this.s.figmaStatus={text:`Building layers for ${t}\u2026`,tone:""},this.render();try{this.s.figma=await e(),this.s.figmaStatus={text:"",tone:""},await this.copyFigma(!0)}catch(r){console.error("[PixelPeek] Could not build Figma layers",r),this.s.figmaStatus={text:r instanceof Error?r.message:String(r),tone:"warn"}}this.s.busy=!1,this.alive&&this.render()}}async copyFigma(e=!1){let t=this.s.figma;if(t){try{await we(t.svg),this.s.figmaStatus={text:`Copied ${t.layers} layer${t.layers===1?"":"s"}. Open Figma, click the canvas and press Ctrl+V (\u2318V on Mac).`,tone:"ok"},this.toast("Copied for Figma")}catch{this.s.figmaStatus={text:e?'The layers are built. Click "Copy layers again" to put them on the clipboard.':"Could not reach the clipboard.",tone:"warn"}}this.render()}}async runClone(){if(!this.s.busy){this.s.busy=!0,this.s.clone=null,this.s.cloneStatus="Starting\u2026",this.render();try{this.s.clone=await this.backend.clone(e=>{this.s.cloneStatus=e,this.alive&&this.render()}),this.s.cloneStatus=""}catch(e){console.error("[PixelPeek] Could not clone this page",e),this.s.cloneStatus=`Could not save this page: ${e instanceof Error?e.message:String(e)}`}this.s.busy=!1,this.alive&&this.render()}}render(){this.renderTop(),this.renderBody();let e=this.s.scan?.elementCount;this.foot.innerHTML=`<span>${e?`${e} elements`:""}</span><span>Esc to exit</span>`,this.pill.style.display=this.inspecting?"inline-flex":"none",this.el.classList.toggle("pp-ov-collapsed",this.collapsed),this.tools.setState({inspect:this.inspecting,devices:this.mode==="devices",saved:this.mode==="saved"}),this.tools.setVisible(this.collapsed),this.dock?.setActive(this.dockActive())}renderTop(){let e=this.s.capture,t={inspect:this.inspecting,devices:this.mode==="devices",saved:this.mode==="saved",figma:!1},r=Et.map(n=>`<button class="pp-ov-tool" data-pp-panel-tool="${n.id}" aria-pressed="${t[n.id]}" aria-label="${n.label}">${n.svg}</button>`).join("");this.nav.innerHTML=`
      <div class="pp-ov-tools" title="Drag to move the panel. Double-click to put it back."><span class="pp-ov-grip" aria-hidden="true">${Kr}</span>${r}</div>
      <div class="pp-ov-head">
        <div class="pp-ov-title" title="${H(e?e.domPath.join(" > "):document.title)}">${e?`<b>${H(e.selector)}</b><span>${Math.round(e.layout.boxModel.content.width)} \xD7 ${Math.round(e.layout.boxModel.content.height)}</span>`:`<b>Whole page</b><span>${H(document.title.slice(0,40))}</span>`}</div>
        <div class="pp-ov-head-btns">
          <button class="pp-close-btn" data-pp-top-btn="account" aria-pressed="${this.mode==="account"}" title="Account" aria-label="Account">${Tt.account}</button>
          ${e?`<button class="pp-close-btn" data-pp-act="deselect" title="Clear selection" aria-label="Clear selection">${Tt.close}</button>`:""}
        </div>
      </div>
      <div class="pp-ov-tabs" role="tablist">
        ${qr.map(n=>`<button class="pp-ov-tab" role="tab" data-pp-tab="${n.id}" aria-selected="${this.mode==="main"&&this.tab===n.id}">${n.label}</button>`).join("")}
      </div>`}renderBody(){let e=this.body.scrollTop,t;if(this.mode==="devices")t=Yo(this.s);else if(this.mode==="saved")t=Ko(this.s);else if(this.mode==="account")t=qo();else switch(this.tab){case"styles":t=Vo(this.s);break;case"figma":t=jo(this.s);break;case"assets":t=Uo(this.s);break;case"system":t=Go(this.s);break;case"export":t=Wo(this.s);break}if(this.body.innerHTML=t,this.body.scrollTop=e,this.anchor){let r=this.body.querySelector(`[data-pp-anchor="${this.anchor}"]`);r&&(this.body.scrollTop=r.offsetTop-this.body.offsetTop-6,this.anchor=null)}}};var At=8e3,Yr=new Set(["SCRIPT","STYLE","NOSCRIPT","LINK","META","HEAD","TITLE","BR","WBR","TEMPLATE"]),Zr=new Set(["path","circle","rect","ellipse","polygon","polyline","line","g"]);function Qe(o,e,t=1){o.set(e,(o.get(e)??0)+t)}function _e(o){return Array.from(o,([e,t])=>({value:e,count:t})).sort((e,t)=>t.count-e.count)}function Xr(o){return(o.split(",")[0]??"").trim().replace(/^["']|["']$/g,"")}function Jr(){let o=new Map,e=new Map;for(let t of Y(document).sheets){let r;try{r=t.cssRules}catch{continue}for(let n of Array.from(r)){if(!(n instanceof CSSFontFaceRule))continue;let i=n.style.getPropertyValue("font-family").trim().replace(/^["']|["']$/g,"").toLowerCase(),p=n.style.getPropertyValue("src").match(/url\(\s*["']?([^"')]+)["']?\s*\)/)?.[1];if(!(!i||!p||o.has(i)))try{o.set(i,new URL(p,t.href??document.baseURI).href)}catch{o.set(i,p)}}}for(let t of Array.from(document.querySelectorAll('link[href*="fonts.googleapis.com"], link[href*="fonts.bunny.net"], link[href*="use.typekit.net"]')))for(let r of t.href.matchAll(/[?&]family=([^&]+)/g)){let n=decodeURIComponent(r[1]).split(":")[0].replace(/\+/g," ").split("|")[0].toLowerCase();n&&e.set(n,t.href)}return{faces:o,links:e}}async function Xo(){await he(document);let o=new Map,e=new Map,t=new Map,r=new Map,n=new Map,i=new Map,s=new Map,p=new Map,a=new WeakMap,l=(u,g)=>{let y=P(u);if(!y||y.a===0)return;let $=F(y),k=o.get($);k||(k={hex:$,count:0,text:0,background:0,border:0,icon:0},o.set($,k)),k.count++,k[g]++},c=Array.from(document.body?.querySelectorAll("*")??[]),d=c.length>At?c.slice(0,At):c,h=0;for(let u of d){if(Yr.has(u.tagName)||u.id===R)continue;let g=getComputedStyle(u);if(g.display==="none")continue;h++;let y=u instanceof SVGElement&&Zr.has(u.tagName.toLowerCase());if(y)g.fill!=="none"&&l(g.fill,"icon"),g.stroke!=="none"&&l(g.stroke,"icon");else{l(g.backgroundColor,"background");for(let S of["Top","Right","Bottom","Left"])parseFloat(g.getPropertyValue(`border-${S.toLowerCase()}-width`))>0&&g.getPropertyValue(`border-${S.toLowerCase()}-style`)!=="none"&&l(g.getPropertyValue(`border-${S.toLowerCase()}-color`),"border")}g.backgroundImage.includes("gradient(")&&Qe(s,g.backgroundImage),g.boxShadow!=="none"&&Qe(i,g.boxShadow),g.borderRadius!=="0px"&&Qe(n,g.borderRadius);for(let S of["padding-top","padding-left","margin-top","margin-left","row-gap","column-gap"]){let ee=g.getPropertyValue(S);/^\d+(\.\d+)?px$/.test(ee)&&parseFloat(ee)>0&&Qe(p,ee)}if(y||!oe(u))continue;l(g.color,"text");let $=Xr(g.fontFamily),k=parseFloat(g.fontSize),I=parseInt(g.fontWeight,10)||400,N=t.get($)??{count:0,weights:new Set,sizes:new Set,headings:0};N.count++,N.weights.add(I),N.sizes.add(k),/^H[1-3]$/.test(u.tagName)&&N.headings++,t.set($,N);let G=`${$}|${k}|${I}|${g.lineHeight}|${g.letterSpacing}`,le=u.tagName,W=r.get(G);W?(W.count++,W.tags[le]=(W.tags[le]??0)+1):r.set(G,{size:k,weight:I,family:$,lineHeight:g.lineHeight,letterSpacing:g.letterSpacing,count:1,tags:{[le]:1}});let x=P(g.color);if(x&&x.a>0){let S=pt(x,Ie(u,a),k,I),ee=`${S.fg}|${S.bg}|${S.large}`,Ft=e.get(ee);Ft?Ft.count++:e.set(ee,{fg:S.fg,bg:S.bg,ratio:S.ratio,count:1,large:S.large,aa:S.aa,aaa:S.aaa})}}let m=Jr(),v=Array.from(t,([u,g])=>{let y=u.toLowerCase();return{family:u,count:g.count,weights:Array.from(g.weights).sort(($,k)=>$-k),sizes:Array.from(g.sizes).sort(($,k)=>$-k),source:m.faces.get(y)??m.links.get(y)??null,headings:g.headings}}).sort((u,g)=>g.count-u.count);return{url:location.href,title:document.title,elementCount:h,truncated:c.length>At,colors:Array.from(o.values()).sort((u,g)=>g.count-u.count),pairs:Array.from(e.values()).sort((u,g)=>g.count-u.count),fonts:v,textStyles:Array.from(r.values()).sort((u,g)=>g.count-u.count),radii:_e(n),shadows:_e(i),gradients:_e(s),spacing:_e(p),tokens:fo(),unreadableSheets:Y(document).unreadable}}var Qr=3e6,_r=4e7,Jo=/url\(\s*(["']?)([^"')]+)\1\s*\)/g;function ei(o){return new Promise((e,t)=>{let r=new FileReader;r.onload=()=>e(String(r.result)),r.onerror=()=>t(r.error),r.readAsDataURL(o)})}var Lt=class{constructor(){this.cache=new Map;this.total=0;this.failed=0}embed(e){if(e.startsWith("data:"))return Promise.resolve(e);let t=this.cache.get(e);return t||(t=this.load(e),this.cache.set(e,t)),t}async load(e){let t=await ge(e);return t?t.size>Qr||this.total+t.size>_r?null:(this.total+=t.size,ei(t)):(this.failed++,null)}};function Rt(o,e){if(o.startsWith("data:")||o.startsWith("#"))return null;try{return new URL(o,e).href}catch{return null}}async function et(o,e,t){let r=new Set;for(let i of o.matchAll(Jo)){let s=Rt(i[2],e);s&&r.add(s)}let n=new Map;return await Promise.all(Array.from(r).map(async i=>{n.set(i,await t.embed(i)??i)})),o.replace(Jo,(i,s,p)=>{let a=Rt(p,e);return a?`url("${n.get(a)??a}")`:i})}function Qo(o){try{return Array.from(o.cssRules).map(e=>e.cssText).join(`
`)}catch{return null}}async function ti(o,e){if(e){let r=Qo(e);if(r!==null)return r}let t=await ge(o.href);return t?t.text():null}function oi(){let o=location.hostname.replace(/^www\./,"")||"page",e=location.pathname.replace(/\/+$/,"").split("/").pop()??"";return`${(e?`${o}-${e}`:o).replace(/[^\w.-]+/g,"-").slice(0,80)}.html`}async function _o(o){let e=[],t=new Lt;o?.("Reading stylesheets\u2026"),await he(document);let r=document.documentElement.cloneNode(!0);r.querySelector(`#${R}`)?.remove(),r.querySelectorAll('script, noscript, link[rel~="preload"], link[rel~="modulepreload"], link[rel~="prefetch"], meta[http-equiv="Content-Security-Policy"]').forEach(u=>u.remove()),r.querySelectorAll("*").forEach(u=>{for(let g of Array.from(u.attributes))/^on/i.test(g.name)&&u.removeAttribute(g.name)});let n=r.querySelector("head")??r.insertBefore(document.createElement("head"),r.firstChild),i=document.createElement("base");i.href=document.baseURI,n.prepend(i),o?.("Inlining styles\u2026");let s=Array.from(document.querySelectorAll('link[rel~="stylesheet"]')),p=Array.from(r.querySelectorAll('link[rel~="stylesheet"]')),a=new Map(Array.from(document.styleSheets).map(u=>[u.ownerNode,u])),l=0;await Promise.all(p.map(async(u,g)=>{let y=s[g],$=y?await ti(y,a.get(y)):null;if($===null){u.setAttribute("href",y?.href??u.href),l++;return}let k=document.createElement("style");k.textContent=await et($,y.href,t),u.replaceWith(k)})),l&&e.push(`${l} stylesheet${l===1?"":"s"} could not be saved and still load from the live site.`);for(let u of Array.from(r.querySelectorAll("style")))u.textContent&&(u.textContent=await et(u.textContent,document.baseURI,t));for(let u of Y(document).sheets){if(u.ownerNode||u.href)continue;let g=Qo(u);if(!g)continue;let y=document.createElement("style");y.textContent=await et(g,document.baseURI,t),n.appendChild(y)}o?.("Embedding images\u2026");let c=Array.from(document.querySelectorAll("img")),d=Array.from(r.querySelectorAll("img"));r.querySelectorAll("picture source").forEach(u=>u.remove()),await Promise.all(d.map(async(u,g)=>{let y=c[g]?.currentSrc||c[g]?.src,$=y?Rt(y,document.baseURI):null;u.removeAttribute("srcset"),u.removeAttribute("loading"),$&&u.setAttribute("src",await t.embed($)??$)}));for(let u of Array.from(r.querySelectorAll('[style*="url("]')))u.setAttribute("style",await et(u.getAttribute("style")??"",document.baseURI,t));let h=r.querySelectorAll("canvas").length,m=r.querySelectorAll("video").length;return h&&e.push(`${h} canvas element${h===1?"":"s"} will be blank.`),m&&e.push(`${m} video${m===1?"":"s"} still stream from the live site.`),t.failed&&e.push(`${t.failed} file${t.failed===1?"":"s"} blocked by the site were left as links to the live site.`),{html:`<!DOCTYPE html>
${`<!-- Saved with PixelPeek from ${document.URL} on ${new Date().toISOString()} -->
`}${r.outerHTML}`,filename:oi(),warnings:e}}var ni=6e3,ri=6,Te=o=>parseFloat(o)||0,ii=o=>{let e=P(o);return!!e&&e.a>.05};function si(o,e){let t=[`background:${o.backgroundColor}`,`color:${o.color}`,`border:${o.borderTopWidth} ${o.borderTopStyle==="none"?"solid":o.borderTopStyle} ${o.borderTopColor}`,`border-radius:${o.borderTopLeftRadius}`,`padding:${o.paddingTop} ${o.paddingRight} ${o.paddingBottom} ${o.paddingLeft}`,`font-family:${o.fontFamily}`,`font-size:${o.fontSize}`,`font-weight:${o.fontWeight}`,`line-height:${o.lineHeight}`,`letter-spacing:${o.letterSpacing}`];return o.boxShadow!=="none"&&t.push(`box-shadow:${o.boxShadow}`),o.textTransform!=="none"&&t.push(`text-transform:${o.textTransform}`),e==="Card"?t.push("width:100%","min-height:56px","box-sizing:border-box"):t.push("display:inline-block","box-sizing:border-box"),t.join(";")}function ai(o){let e=i=>{let s=P(i);return s&&s.a>0?F(s):""},t=(i,s,p,a)=>i===s&&s===p&&p===a?i:i===p&&s===a?`${i} ${s}`:`${i} ${s} ${p} ${a}`,r=Te(o.borderTopWidth)>0&&o.borderTopStyle!=="none"?`${o.borderTopWidth} ${e(o.borderTopColor)}`:"";return[{label:"Fill",value:e(o.backgroundColor)},{label:"Text",value:e(o.color)},{label:"Border",value:r},{label:"Radius",value:o.borderTopLeftRadius!=="0px"?o.borderTopLeftRadius:""},{label:"Padding",value:t(o.paddingTop,o.paddingRight,o.paddingBottom,o.paddingLeft)},{label:"Font",value:`${(o.fontFamily.split(",")[0]??"").replace(/["']/g,"").trim()} ${o.fontSize}/${o.fontWeight}`},{label:"Shadow",value:o.boxShadow!=="none"?o.boxShadow:""}].filter(i=>i.value&&i.value!=="0px")}function pi(o){return[F(P(o.backgroundColor)??{r:0,g:0,b:0,a:0}),F(P(o.color)??{r:0,g:0,b:0,a:1}),o.borderTopWidth,o.borderTopColor,o.borderTopLeftRadius,o.paddingTop,o.paddingLeft,o.fontSize,o.fontWeight,o.boxShadow].join("|")}function li(o,e,t){let r=o.tagName;if(r==="INPUT"){let a=o.type;return["button","submit","reset"].includes(a)?"Button":["hidden","checkbox","radio","range","file","color","image"].includes(a)?null:"Input"}if(r==="TEXTAREA"||r==="SELECT")return"Input";if(t.width<8||t.height<8)return null;let n=ii(e.backgroundColor),i=Te(e.borderTopWidth)>0&&e.borderTopStyle!=="none",s=Te(e.borderTopLeftRadius),p=(o.textContent??"").trim();return r==="BUTTON"||o.getAttribute("role")==="button"||r==="A"&&(n||i)&&Te(e.paddingLeft)>=8&&p.length>0&&p.length<40&&t.height<90?"Button":n&&p.length>0&&p.length<=24&&t.height<=36&&s>=t.height/2-1&&Te(e.fontSize)<=14&&o.children.length<=1?"Badge":(i||e.boxShadow!=="none")&&s>=4&&n&&t.width>=140&&t.width<=720&&t.height>=60&&o.children.length>=1?"Card":null}function en(){let o=new Map,e=Array.from(document.body?.querySelectorAll("*")??[]).slice(0,ni);for(let r of e){if(r.id===R||r.closest(`#${R}`)||r instanceof SVGElement)continue;let n=getComputedStyle(r);if(n.display==="none"||n.visibility==="hidden")continue;let i=r.getBoundingClientRect(),s=li(r,n,i);if(!s)continue;let p=pi(n),a=o.get(s);a||o.set(s,a=new Map);let l=a.get(p);if(l){l.count++;continue}let c=(r.textContent??"").trim().replace(/\s+/g," ");a.set(p,{count:1,label:s==="Input"?r.placeholder||r.type||"Input":c.slice(0,24)||s,tailwind:Fe(r,n).filter(d=>!/^(w|h)-/.test(d)),previewStyle:si(n,s),size:`${Math.round(i.width)} \xD7 ${Math.round(i.height)}`,details:ai(n)})}return["Button","Input","Card","Badge"].filter(r=>o.has(r)).map(r=>({kind:r,variants:Array.from(o.get(r).values()).sort((n,i)=>i.count-n.count).slice(0,ri)}))}var Pt=4e3,It=2e4,ci=15e5,di=14e6,ui=new Set(["SCRIPT","STYLE","NOSCRIPT","LINK","META","HEAD","TITLE","TEMPLATE","BR","WBR","SOURCE","TRACK"]),tn=new Set(["hidden","auto","scroll","clip"]),B=o=>o.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"),C=o=>parseFloat(o)||0,b=o=>String(Math.round(o*100)/100),Me;function on(o){if(Me===void 0&&(Me=document.createElement("canvas").getContext("2d")),!Me)return{ascent:0,height:0};Me.font=o;let e=Me.measureText("Mg");return{ascent:e.fontBoundingBoxAscent,height:e.fontBoundingBoxAscent+e.fontBoundingBoxDescent}}function ae(o){let e=P(o);if(!e||e.a===0)return null;let t=r=>Math.round(r).toString(16).padStart(2,"0");return{fill:`#${t(e.r)}${t(e.g)}${t(e.b)}`,opacity:e.a}}var fe=(o,e="fill")=>{let t=ae(o);return t?`${e}="${t.fill}"${t.opacity<1?` ${e}-opacity="${b(t.opacity)}"`:""}`:`${e}="none"`};function hi(o,e,t,r,n,i,s,p){let a=l=>Math.max(0,Math.min(l,t/2,r/2));return[n,i,s,p]=[a(n),a(i),a(s),a(p)],[`M${b(o+n)} ${b(e)}`,`H${b(o+t-i)}`,i?`A${b(i)} ${b(i)} 0 0 1 ${b(o+t)} ${b(e+i)}`:"",`V${b(e+r-s)}`,s?`A${b(s)} ${b(s)} 0 0 1 ${b(o+t-s)} ${b(e+r)}`:"",`H${b(o+p)}`,p?`A${b(p)} ${b(p)} 0 0 1 ${b(o)} ${b(e+r-p)}`:"",`V${b(e+n)}`,n?`A${b(n)} ${b(n)} 0 0 1 ${b(o+n)} ${b(e)}`:"","Z"].join("")}function tt(o,e){return o.endsWith("%")?C(o)/100*e:C(o)}function Ae(o,e,t=0){let r=o.x+t,n=o.y+t,i=Math.max(0,o.w-t*2),s=Math.max(0,o.h-t*2),p=o.r.map(a=>Math.max(0,a-t));return p.every(a=>a===p[0])?`<rect x="${b(r)}" y="${b(n)}" width="${b(i)}" height="${b(s)}"${p[0]?` rx="${b(Math.min(p[0],i/2,s/2))}"`:""} ${e}/>`:`<path d="${hi(r,n,i,s,p[0],p[1],p[2],p[3])}" ${e}/>`}var zt=class{constructor(e,t,r){this.ox=e;this.oy=t;this.bounds=r;this.defs=[];this.layers=0;this.elements=0;this.warnings=new Set;this.ids=0;this.images=[];this.imageBytes=0;this.skippedImages=0;this.transformed=0}id(e){return`${e}${this.ids++}`}imageToken(e){let t=`@@IMG${this.images.length}@@`;return this.images.push({token:t,url:e}),t}async resolveImages(e){let t=new Map,r=async i=>{if(i.startsWith("data:"))return i;let s=await ge(i);return!s||s.size>ci||this.imageBytes+s.size>di?null:(this.imageBytes+=s.size,new Promise(p=>{let a=new FileReader;a.onload=()=>p(String(a.result)),a.onerror=()=>p(null),a.readAsDataURL(s)}))};await Promise.all(this.images.map(async({url:i})=>{t.has(i)||t.set(i,await r(i))}));let n=e;for(let{token:i,url:s}of this.images){let p=t.get(s);p||this.skippedImages++,n=n.replace(i,p??s)}return n}shadowFilter(e,t){let r=t.filter(a=>a.type==="Drop"&&ae(a.color));if(t.some(a=>a.type==="Inner")&&this.warnings.add("Inner shadows are not copied."),!r.length)return null;let n=this.id("shadow"),i=0;for(let a of r)i=Math.max(i,Math.abs(C(a.x))+Math.abs(C(a.y))+C(a.blur)*2+Math.abs(C(a.spread)));let s='<feFlood flood-opacity="0" result="BackgroundImageFix"/>',p="BackgroundImageFix";return r.forEach((a,l)=>{let c=ae(a.color),d=[1,3,5].map(h=>(parseInt(c.fill.slice(h,h+2),16)/255).toFixed(3));s+=`<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/><feOffset dx="${b(C(a.x))}" dy="${b(C(a.y))}"/><feGaussianBlur stdDeviation="${b(C(a.blur)/2)}"/><feComposite in2="hardAlpha" operator="out"/><feColorMatrix type="matrix" values="0 0 0 0 ${d[0]} 0 0 0 0 ${d[1]} 0 0 0 0 ${d[2]} 0 0 0 ${b(c.opacity)} 0"/><feBlend mode="normal" in2="${p}" result="effect${l+1}"/>`,p=`effect${l+1}`}),s+=`<feBlend mode="normal" in="SourceGraphic" in2="${p}" result="shape"/>`,this.defs.push(`<filter id="${n}" x="${b(e.x-i)}" y="${b(e.y-i)}" width="${b(e.w+i*2)}" height="${b(e.h+i*2)}" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">${s}</filter>`),n}gradientFill(e,t){if(e.type==="Other"||e.stops.length<2)return null;let r=this.id("grad"),n=e.stops.length,i=1,s;if(e.type==="Linear"){let l=C(e.angle??"180")*Math.PI/180,c=Math.sin(l),d=-Math.cos(l);i=Math.abs(t.w*c)+Math.abs(t.h*d)||1;let h=t.x+t.w/2,m=t.y+t.h/2;s=`<linearGradient id="${r}" gradientUnits="userSpaceOnUse" x1="${b(h-c*i/2)}" y1="${b(m-d*i/2)}" x2="${b(h+c*i/2)}" y2="${b(m+d*i/2)}">`}else i=Math.max(t.w,t.h)||1,s=`<radialGradient id="${r}" gradientUnits="userSpaceOnUse" cx="${b(t.x+t.w/2)}" cy="${b(t.y+t.h/2)}" r="${b(i/2)}">`;let p=e.stops.map((a,l)=>{let c=ae(a.color),d=n===1?0:l/(n-1);return a.position&&(d=a.position.endsWith("%")?C(a.position)/100:C(a.position)/(e.type==="Linear"?i:i/2)),`<stop offset="${b(Math.max(0,Math.min(1,d)))}" stop-color="${c?.fill??"#000000"}"${c&&c.opacity<1?` stop-opacity="${b(c.opacity)}"`:""}/>`}).join("");return this.defs.push(`${s}${p}</${e.type==="Linear"?"linearGradient":"radialGradient"}>`),r}clip(e){let t=this.id("clip");return this.defs.push(`<clipPath id="${t}">${Ae(e,"")}</clipPath>`),t}image(e,t,r,n){this.layers++;let i=r==="cover"?"xMidYMid slice":r==="fill"||r==="stretch"?"none":"xMidYMid meet",s=t.r.some(Boolean)||r==="cover"?` clip-path="url(#${this.clip(t)})"`:"";return`<image id="${B(n)}" x="${b(t.x)}" y="${b(t.y)}" width="${b(t.w)}" height="${b(t.h)}" preserveAspectRatio="${i}" href="${this.imageToken(e)}"${s}/>`}placeholder(e,t,r){return this.warnings.add(r),this.layers++,Ae(e,`id="${B(t)}" fill="#E5E7EB"`)}text(e,t){let r=[],n=C(t.fontSize),i=t.fontWeight,s=t.fontFamily,{ascent:p}=on(`${t.fontStyle==="italic"?"italic ":""}${i} ${n}px ${s}`),a=`font-family="${B(s.replace(/"/g,"'"))}" font-size="${b(n)}" font-weight="${i}"${t.fontStyle==="italic"?' font-style="italic"':""}${t.letterSpacing!=="normal"?` letter-spacing="${b(C(t.letterSpacing))}"`:""}${t.textDecorationLine!=="none"?` text-decoration="${B(t.textDecorationLine)}"`:""} ${fe(t.color)}`,l=c=>t.textTransform==="uppercase"?c.toUpperCase():t.textTransform==="lowercase"?c.toLowerCase():t.textTransform==="capitalize"?c.replace(/\b(\w)/g,d=>d.toUpperCase()):c;for(let c of Array.from(e.childNodes)){if(c.nodeType!==Node.TEXT_NODE||!c.textContent?.trim())continue;let d=c.textContent,h=[],m=document.createRange();for(let v of d.matchAll(/\S+/g)){let u=v.index??0;m.setStart(c,u),m.setEnd(c,u+v[0].length);let g=m.getClientRects()[0];if(!g||!g.width&&!g.height)continue;let y=h[h.length-1];y&&Math.abs(y.top-g.top)<Math.max(3,n*.4)?y.words.push(v[0]):h.push({top:g.top,left:g.left,words:[v[0]]})}for(let v of h){let u=l(v.words.join(" "));this.layers++,r.push(`<text id="${B(u.slice(0,40))}" x="${b(v.left-this.ox)}" y="${b(v.top-this.oy+p)}" ${a} xml:space="preserve">${B(u)}</text>`)}}return r.join("")}inlineSvg(e,t,r,n){let i=e.cloneNode(!0);i.setAttribute("xmlns","http://www.w3.org/2000/svg"),i.setAttribute("width",b(t.w)),i.setAttribute("height",b(t.h)),i.getAttribute("viewBox")||i.setAttribute("viewBox",`0 0 ${b(t.w)} ${b(t.h)}`),i.removeAttribute("class"),i.removeAttribute("style");let s=new Set;for(let a of Array.from(i.querySelectorAll("use"))){let l=a.getAttribute("href")??a.getAttribute("xlink:href");l?.startsWith("#")&&s.add(l.slice(1))}if(s.size){let a=document.createElementNS("http://www.w3.org/2000/svg","defs");for(let l of s){let c=document.getElementById(l);c&&a.appendChild(c.cloneNode(!0))}i.insertBefore(a,i.firstChild)}let p=new XMLSerializer().serializeToString(i).replace(/currentColor/g,r);return this.layers++,`<g id="${B(n)}" transform="translate(${b(t.x)} ${b(t.y)})">${p}</g>`}draw(e){if(ui.has(e.tagName)||e.id===R||this.elements>=Pt)return this.elements>=Pt&&this.warnings.add(`Only the first ${Pt} elements were copied.`),"";this.elements++;let t=getComputedStyle(e);if(t.display==="none"||t.visibility==="hidden"&&!e.children.length)return"";let r=parseFloat(t.opacity);if(r===0)return"";let n=e.getBoundingClientRect(),i={x:n.left-this.ox,y:n.top-this.oy,w:n.width,h:n.height,r:[tt(t.borderTopLeftRadius,n.width),tt(t.borderTopRightRadius,n.width),tt(t.borderBottomRightRadius,n.width),tt(t.borderBottomLeftRadius,n.width)]};t.transform!=="none"&&this.transformed++;let s=!this.bounds||i.x<this.bounds.w&&i.y<this.bounds.h&&i.x+i.w>0&&i.y+i.h>0,p=nn(e),a=[];if(s&&i.w>0&&i.h>0&&t.visibility!=="hidden"){let u=ae(t.backgroundColor),g=ce(t.boxShadow),y=u?this.shadowFilter(i,g):null;!u&&g.length&&g.some($=>$.type==="Drop")&&this.warnings.add("Shadows on transparent boxes are not copied."),u&&(this.layers++,a.push(Ae(i,`id="Background" ${fe(t.backgroundColor)}${y?` filter="url(#${y})"`:""}`)));for(let $ of de(t.backgroundImage)){let k=this.gradientFill($,i);k?(this.layers++,a.push(Ae(i,`id="Gradient" fill="url(#${k})"`))):$.type==="Other"&&this.warnings.add("Conic and repeating gradients are not copied.")}for(let $ of t.backgroundImage.matchAll(/url\(\s*["']?([^"')]+)["']?\s*\)/g))try{let k=new URL($[1],document.baseURI).href,I=t.backgroundSize;a.push(this.image(k,i,I.includes("cover")?"cover":I.includes("100% 100%")?"fill":"contain","Background image"))}catch{}if(a.push(...this.borders(t,i)),e instanceof HTMLImageElement){let $=e.currentSrc||e.src;if($){let k={...i,x:i.x+C(t.borderLeftWidth)+C(t.paddingLeft),y:i.y+C(t.borderTopWidth)+C(t.paddingTop),w:i.w-C(t.borderLeftWidth)-C(t.borderRightWidth)-C(t.paddingLeft)-C(t.paddingRight),h:i.h-C(t.borderTopWidth)-C(t.borderBottomWidth)-C(t.paddingTop)-C(t.paddingBottom)};a.push(this.image(new URL($,document.baseURI).href,k,t.objectFit==="cover"?"cover":t.objectFit==="fill"?"fill":"contain",p))}}else if(e instanceof SVGSVGElement)a.push(this.inlineSvg(e,i,t.color,p));else if(e instanceof HTMLCanvasElement)try{a.push(this.image(e.toDataURL(),i,"fill",p))}catch{a.push(this.placeholder(i,p,"Canvas elements that block reading were drawn as grey boxes."))}else e instanceof HTMLVideoElement?a.push(e.poster?this.image(new URL(e.poster,document.baseURI).href,i,"cover",p):this.placeholder(i,p,"Videos without a poster image were drawn as grey boxes.")):e instanceof HTMLIFrameElement?a.push(this.placeholder(i,p,"Embedded frames (iframes) were drawn as grey boxes.")):e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement||e instanceof HTMLSelectElement?a.push(this.formControlText(e,t,i)):a.push(this.text(e,t))}let l=e instanceof SVGSVGElement?[]:Array.from(e.children),c=u=>{let g=getComputedStyle(u);return g.position==="static"?0:parseInt(g.zIndex,10)||0},h=l.map((u,g)=>({c:u,i:g,z:c(u)})).sort((u,g)=>u.z-g.z||u.i-g.i).map(({c:u})=>this.draw(u)).join(""),m=a.filter(Boolean);if(m.length===1&&!h&&r===1)return m[0];let v=m.join("");return h&&(tn.has(t.overflowX)||tn.has(t.overflowY)?v+=`<g clip-path="url(#${this.clip(i)})">${h}</g>`:v+=h),v?`<g id="${B(p)}"${r<1?` opacity="${b(r)}"`:""}>${v}</g>`:""}borders(e,t){let n=["top","right","bottom","left"].map(s=>({side:s,w:e.getPropertyValue(`border-${s}-style`)==="none"?0:C(e.getPropertyValue(`border-${s}-width`)),color:e.getPropertyValue(`border-${s}-color`),dash:e.getPropertyValue(`border-${s}-style`)})).filter(s=>s.w>0&&ae(s.color));if(!n.length)return[];if(n.length===4&&n.every(s=>s.w===n[0].w&&s.color===n[0].color)){let s=n[0].w,p=n[0].dash==="dashed"?` stroke-dasharray="${b(s*3)} ${b(s*3)}"`:n[0].dash==="dotted"?` stroke-dasharray="${b(s)} ${b(s)}"`:"";return this.layers++,[Ae(t,`id="Border" fill="none" ${fe(n[0].color,"stroke")} stroke-width="${b(s)}"${p}`,s/2)]}return n.map(s=>{this.layers++;let[p,a,l,c]=s.side==="top"?[t.x,t.y,t.w,s.w]:s.side==="bottom"?[t.x,t.y+t.h-s.w,t.w,s.w]:s.side==="left"?[t.x,t.y,s.w,t.h]:[t.x+t.w-s.w,t.y,s.w,t.h];return`<rect id="Border ${s.side}" x="${b(p)}" y="${b(a)}" width="${b(l)}" height="${b(c)}" ${fe(s.color)}/>`})}formControlText(e,t,r){let n="",i=t.color;if(e instanceof HTMLSelectElement)n=e.selectedOptions[0]?.textContent?.trim()??"";else{if(e instanceof HTMLInputElement&&["checkbox","radio","range","file","color","hidden"].includes(e.type))return"";n=e.value,!n&&e.placeholder&&(n=e.placeholder,i="rgba(0,0,0,0.4)")}if(!n)return"";let s=C(t.fontSize),{ascent:p,height:a}=on(`${t.fontWeight} ${s}px ${t.fontFamily}`);this.layers++;let l=r.y+r.h/2-a/2+p;return`<text id="${B(n.slice(0,40))}" x="${b(r.x+C(t.borderLeftWidth)+C(t.paddingLeft))}" y="${b(l)}" font-family="${B(t.fontFamily.replace(/"/g,"'"))}" font-size="${b(s)}" font-weight="${t.fontWeight}" ${fe(i)} xml:space="preserve">${B(n)}</text>`}};function nn(o){let e=o.tagName.toLowerCase();if(o.id)return`${e}#${o.id}`;let t=Array.from(o.classList).find(r=>/^[a-z][\w-]{2,}$/i.test(r));return t?`${e}.${t}`:e}async function be(o,e){let t=0,r=0,n,i,s=null,p,a="";if(e==="element"){let m=o.getBoundingClientRect();t=m.left,r=m.top,n=m.width,i=m.height,p=nn(o)}else{o=document.body;let m=document.documentElement;e==="page"?(t=-window.scrollX,r=-window.scrollY,n=Math.max(m.scrollWidth,window.innerWidth),i=Math.min(Math.max(m.scrollHeight,window.innerHeight),It)):(n=window.innerWidth,i=window.innerHeight,s={w:n,h:i}),p=document.title.slice(0,60)||location.hostname;let v=[getComputedStyle(m).backgroundColor,getComputedStyle(document.body).backgroundColor].find(u=>ae(u))??"#ffffff";a=`<rect id="Page background" width="${b(n)}" height="${b(i)}" ${fe(v)}/>`}let l=new zt(t,r,s);a&&l.layers++;let c=l.draw(o),d=`<svg xmlns="http://www.w3.org/2000/svg" width="${b(n)}" height="${b(i)}" viewBox="0 0 ${b(n)} ${b(i)}" fill="none">${e==="element"?c:`<g id="${B(p)}">${a}${c}</g>`}${l.defs.length?`<defs>${l.defs.join("")}</defs>`:""}</svg>`;d=await l.resolveImages(d);let h=Array.from(l.warnings);return l.skippedImages&&h.push(`${l.skippedImages} image${l.skippedImages===1?" was":"s were"} too large or blocked by the site, so Figma will show them empty.`),l.transformed&&h.push(`${l.transformed} rotated or scaled element${l.transformed===1?" was":"s were"} drawn upright at ${l.transformed===1?"its":"their"} final size and position.`),e==="page"&&document.documentElement.scrollHeight>It&&h.push(`The page is taller than ${It}px, so the bottom was cut off.`),{svg:d,layers:l.layers,width:n,height:i,warnings:h}}var ot=class{constructor(e=()=>null){this.getLocked=e;this.assets=new Map}scan(){return Xo()}async collectAssets(){let e=this.getLocked(),t=Po(e?e.closest("svg")??e:void 0);return this.assets=new Map(t.map(r=>[r.id,r])),t}async downloadAsset(e){let t=this.assets.get(e);return t?lo(t):!1}async scanComponents(){return en()}downloadZip(e,t){let r=e.map(i=>this.assets.get(i)).filter(i=>!!i),n=location.hostname.replace(/^www\./,"")||"page";return co(r,`${n}-assets.zip`,t)}async buildFigma(e){let t=this.getLocked();if(e==="element"){if(!t)throw new Error("Lock an element first.");return be(t,"element")}return be(document.body,e)}async clone(e){let t=await _o(e);return Be(t.html,t.filename,"text/html"),{filename:t.filename,sizeMb:t.html.length/1024/1024,warnings:t.warnings}}};var rn=["click","dblclick","auxclick","contextmenu","mousedown","pointerdown","touchstart","touchend","submit","dragstart","mouseover","mouseout","mouseenter","mouseleave","pointerover","pointerout","pointerenter","pointerleave"],sn=["mousemove","pointermove","mouseup","pointerup"];function an(o){return o.target?.id===R}var nt=class{constructor(){this.blockHard=e=>{an(e)||(e.cancelable&&e.preventDefault(),e.stopImmediatePropagation())};this.blockSoft=e=>{an(e)||e.stopPropagation()};for(let e of rn)window.addEventListener(e,this.blockHard,{capture:!0});for(let e of sn)window.addEventListener(e,this.blockSoft,{capture:!0})}destroy(){for(let e of rn)window.removeEventListener(e,this.blockHard,{capture:!0});for(let e of sn)window.removeEventListener(e,this.blockSoft,{capture:!0})}};var gi="Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1",pn="Mozilla/5.0 (iPad; CPU OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1",ln="Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36",mi="Mozilla/5.0 (Linux; Android 14; SM-X710) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36";function cn(o,e){let t=/iphone|ipad/i.test(o.name);switch(o.category){case"phones":return t?{userAgent:gi,platform:"ios",mobile:!0,model:"iPhone"}:{userAgent:ln,platform:"android",mobile:!0,model:"Pixel 8"};case"tablets":return t?{userAgent:pn,platform:"ios",mobile:!1,model:"iPad"}:{userAgent:mi,platform:"android",mobile:!1,model:"SM-X710"};case"responsive":return e<768?{userAgent:ln,platform:"android",mobile:!0,model:"Pixel 8"}:e<1024?{userAgent:pn,platform:"ios",mobile:!1,model:"iPad"}:null;default:return null}}var fi={island:{top:14,right:14,bottom:14,left:14,radius:62},notch:{top:14,right:14,bottom:14,left:14,radius:52},punch:{top:14,right:14,bottom:14,left:14,radius:44},fold:{top:14,right:14,bottom:14,left:14,radius:34},home:{top:66,right:16,bottom:82,left:16,radius:46},tablet:{top:24,right:24,bottom:24,left:24,radius:36},laptop:{top:18,right:18,bottom:18,left:18,radius:20},monitor:{top:16,right:16,bottom:52,left:16,radius:18},watch:{top:22,right:22,bottom:22,left:22,radius:64},plain:{top:2,right:2,bottom:2,left:2,radius:12}},bi=[320,375,414,768,1024,1280,1440],rt=class{constructor(e,t){this.device=null;this.width=0;this.height=0;this.landscape=!1;this.onResize=()=>this.layout();this.callbacks=t,this.el=document.createElement("div"),this.el.className="pp-dp",this.el.style.display="none",this.el.addEventListener("click",r=>this.onClick(r)),this.el.addEventListener("input",r=>this.onInput(r));for(let r of["click","dblclick","mousedown","mouseup","pointerdown","pointerup","contextmenu","keydown","keyup"])this.el.addEventListener(r,n=>n.stopPropagation());e.appendChild(this.el)}get isOpen(){return this.device!==null}open(e){this.device=e,this.landscape=!1,this.width=e.width,this.height=e.height,this.el.style.display="flex",this.render(),window.addEventListener("resize",this.onResize)}close(){this.device&&(this.device=null,this.callbacks.emulate(null),this.el.style.display="none",this.el.innerHTML="",window.removeEventListener("resize",this.onResize))}destroy(){this.close(),this.el.remove()}screen(){return this.landscape?{w:this.height,h:this.width}:{w:this.width,h:this.height}}render(){let e=this.device;if(!e)return;let t=e.category==="responsive",{w:r,h:n}=this.screen(),i=e.frame;this.el.innerHTML=`
      <div class="pp-dp-bar">
        <div class="pp-dp-title"><b>${H(e.name)}</b><span>${t?"":`${r} \xD7 ${n}`}</span></div>
        ${t?`
          <div class="pp-dp-size">
            <input type="number" min="200" max="3000" value="${r}" data-pp-dp-w aria-label="Width"> \xD7
            <input type="number" min="200" max="3000" value="${n}" data-pp-dp-h aria-label="Height">
          </div>
          <div class="pp-dp-presets">${bi.map(s=>`<button class="pp-chip" data-pp-dp-preset="${s}">${s}</button>`).join("")}</div>`:""}
        <span class="pp-dp-emu" data-pp-dp-emu></span>
        <span class="pp-dp-scale" data-pp-dp-scale></span>
        <button class="pp-btn" data-pp-dp-rotate title="Rotate">Rotate</button>
        <button class="pp-btn" data-pp-dp-reload title="Reload the preview">Reload</button>
        <button class="pp-btn" data-pp-dp-close>Close <kbd>Esc</kbd></button>
      </div>
      <div class="pp-dp-stage" data-pp-dp-stage>
        <div class="pp-dev pp-dev-${i}${this.landscape?" pp-landscape":""}" data-pp-dp-dev>
          <div class="pp-dev-screen">
            <iframe class="pp-dp-frame" data-pp-dp-iframe title="Preview of this page" referrerpolicy="same-origin"></iframe>
            <div class="pp-dp-blocked" data-pp-dp-blocked hidden>
              <b>This site cannot be shown inside a frame</b>
              <p>It sends headers that stop other pages (including this preview) from framing it. Open a real browser window at this size instead.</p>
              <button class="pp-btn pp-btn-primary" data-pp-dp-window>Open a ${r} \xD7 ${n} window</button>
            </div>
          </div>
          <span class="pp-dev-deco pp-dev-a"></span><span class="pp-dev-deco pp-dev-b"></span><span class="pp-dev-deco pp-dev-c"></span>
        </div>
      </div>
    `,this.layout(),this.loadFrame()}async loadFrame(){let e=this.el.querySelector("[data-pp-dp-iframe]"),t=this.el.querySelector("[data-pp-dp-blocked]");if(!e||!t)return;e.addEventListener("load",()=>{let p=!1;try{p=!!e.contentDocument?.body}catch{p=!1}t.hidden=p});let r=this.device,n=this.el.querySelector("[data-pp-dp-emu]"),i=r?cn(r,this.screen().w):null;n&&(n.textContent=i?"Switching to a mobile browser...":"");let s=await this.callbacks.emulate(i);e.isConnected&&(n&&(n.textContent=i?s.ok?`${i.platform==="ios"?"iOS":"Android"} browser on`:`Frame only (${s.error??"could not emulate"})`:"",n.classList.toggle("pp-dp-emu-warn",!!i&&!s.ok)),e.src=location.href)}layout(){let e=this.device,t=this.el.querySelector("[data-pp-dp-stage]"),r=this.el.querySelector("[data-pp-dp-dev]");if(!e||!t||!r)return;let{w:n,h:i}=this.screen(),s=fi[e.frame],p=this.landscape&&e.category!=="tablets"?{top:s.left,right:s.bottom,bottom:s.right,left:s.top,radius:s.radius}:s,a=n+p.left+p.right,l=i+p.top+p.bottom,c=e.frame==="laptop"?28:e.frame==="monitor"?64:e.frame==="watch"?80:0,d=Math.min(1,(t.clientWidth-48)/a,(t.clientHeight-24)/(l+c*2));r.style.cssText=`--sw:${n}px;--sh:${i}px;--bt:${p.top}px;--br:${p.right}px;--bb:${p.bottom}px;--bl:${p.left}px;--r:${p.radius}px;width:${a}px;height:${l}px;transform:scale(${d});`,r.parentElement.style.setProperty("--fit-w",`${a*d}px`),r.parentElement.style.setProperty("--fit-h",`${(l+c*2)*d}px`);let h=this.el.querySelector("[data-pp-dp-scale]");h&&(h.textContent=`${Math.round(d*100)}%`)}onInput(e){let t=e.target;if(t.matches("[data-pp-dp-w]"))this.width=Math.max(200,Math.min(3e3,parseInt(t.value,10)||this.width));else if(t.matches("[data-pp-dp-h]"))this.height=Math.max(200,Math.min(3e3,parseInt(t.value,10)||this.height));else return;this.layout()}onClick(e){let t=e.target;if(t.closest("[data-pp-dp-close]"))this.close(),this.callbacks.onClose();else if(t.closest("[data-pp-dp-rotate]"))this.landscape=!this.landscape,this.render();else if(t.closest("[data-pp-dp-reload]"))this.loadFrame();else if(t.closest("[data-pp-dp-window]")){let{w:r,h:n}=this.screen();this.callbacks.onOpenWindow(r,n)}else{let r=t.closest("[data-pp-dp-preset]")?.dataset.ppDpPreset;r&&(this.width=parseInt(r,10),this.render())}}};var O=o=>parseFloat(o)||0,it=class{constructor(e){this.target=null;this.raf=0;this.onMove=()=>{cancelAnimationFrame(this.raf),this.raf=requestAnimationFrame(()=>this.draw())};this.layer=document.createElement("div"),this.layer.className="pp-guides",this.layer.style.display="none",e.appendChild(this.layer)}get isOn(){return this.target!==null}show(e){this.target=e,this.layer.style.display="block",window.addEventListener("scroll",this.onMove,!0),window.addEventListener("resize",this.onMove),this.draw()}hide(){this.target=null,this.layer.style.display="none",this.layer.innerHTML="",window.removeEventListener("scroll",this.onMove,!0),window.removeEventListener("resize",this.onMove)}destroy(){this.hide(),this.layer.remove()}draw(){let e=this.target;if(!e)return;let t=getComputedStyle(e),r=e.getBoundingClientRect(),n={t:O(t.marginTop),r:O(t.marginRight),b:O(t.marginBottom),l:O(t.marginLeft)},i={t:O(t.borderTopWidth),r:O(t.borderRightWidth),b:O(t.borderBottomWidth),l:O(t.borderLeftWidth)},s={t:O(t.paddingTop),r:O(t.paddingRight),b:O(t.paddingBottom),l:O(t.paddingLeft)},p=(d,h,m,v,u,g)=>`<div class="${d}" style="left:${h}px;top:${m}px;width:${Math.max(0,v)}px;height:${Math.max(0,u)}px;${g?`border-width:${g.t}px ${g.r}px ${g.b}px ${g.l}px;`:""}"></div>`,a=(d,h,m,v)=>d>0?`<span class="pp-guide-label ${v}" style="left:${h}px;top:${m}px">${Math.round(d*10)/10}</span>`:"",l=r.left+r.width/2,c=r.top+r.height/2;this.layer.innerHTML=p("pp-guide pp-guide-margin",r.left-n.l,r.top-n.t,r.width,r.height,n)+p("pp-guide pp-guide-padding",r.left+i.l,r.top+i.t,r.width-i.l-i.r,r.height-i.t-i.b,s)+p("pp-guide pp-guide-content",r.left+i.l+s.l,r.top+i.t+s.t,r.width-i.l-i.r-s.l-s.r,r.height-i.t-i.b-s.t-s.b)+a(n.t,l,r.top-n.t/2,"pp-guide-label-margin")+a(n.b,l,r.bottom+n.b/2,"pp-guide-label-margin")+a(n.l,r.left-n.l/2,c,"pp-guide-label-margin")+a(n.r,r.right+n.r/2,c,"pp-guide-label-margin")+a(s.t,l,r.top+i.t+s.t/2,"pp-guide-label-padding")+a(s.b,l,r.bottom-i.b-s.b/2,"pp-guide-label-padding")+a(s.l,r.left+i.l+s.l/2,c,"pp-guide-label-padding")+a(s.r,r.right-i.r-s.r/2,c,"pp-guide-label-padding")}};var pe=o=>parseFloat(o)||0,dn=16,un="Click to select \xB7 <kbd>F</kbd> Figma \xB7 <kbd>S</kbd> Save",ve=o=>String(Math.round(o*10)/10);function vi(o){if(o.id)return`#${o.id}`;let e=Array.from(o.classList).slice(0,2).join(".");return e?`${o.tagName.toLowerCase()}.${e}`:o.tagName.toLowerCase()}var hn=(o,e,t,r)=>{let[n,i,s,p]=[pe(o),pe(e),pe(t),pe(r)];return!n&&!i&&!s&&!p?"":n===i&&i===s&&s===p?`${ve(n)}px`:`${ve(n)} ${ve(i)} ${ve(s)} ${ve(p)}`},st=class{constructor(e){this.flashTimer=0;this.el=document.createElement("div"),this.el.className="pp-hover",this.el.style.display="none",e.appendChild(this.el)}show(e){let t=getComputedStyle(e),r=e.getBoundingClientRect(),n=ze(e,t),i=v=>`<span class="pp-swatch" style="background:${H(v)}"></span>`,s=[],p=(t.fontFamily.split(",")[0]??"").replace(/["']/g,"").trim();(e.textContent??"").trim()&&(s.push(["Font",`${H(p)} \xB7 ${t.fontSize} \xB7 ${t.fontWeight}`]),s.push(["Text",`${i(t.color)}${z(t.color)}${n&&!n.onImage?` <span class="${n.aa?"pp-hv-ok":"pp-hv-bad"}">${n.ratio.toFixed(1)}:1</span>`:""}`])),t.backgroundColor!=="rgba(0, 0, 0, 0)"&&t.backgroundColor!=="transparent"&&s.push(["Fill",`${i(t.backgroundColor)}${z(t.backgroundColor)}`]);let a=hn(t.paddingTop,t.paddingRight,t.paddingBottom,t.paddingLeft),l=hn(t.marginTop,t.marginRight,t.marginBottom,t.marginLeft);a&&s.push(["Padding",a]),l&&s.push(["Margin",l]),pe(t.borderTopLeftRadius)&&s.push(["Radius",t.borderTopLeftRadius]),(t.display.includes("flex")||t.display.includes("grid"))&&s.push(["Layout",`${t.display}${pe(t.rowGap)?` \xB7 gap ${ve(pe(t.rowGap))}px`:""}`]),this.el.innerHTML=`
      <div class="pp-hover-head"><b>${H(vi(e))}</b><span>${Math.round(r.width)} \xD7 ${Math.round(r.height)}</span></div>
      ${s.map(([v,u])=>`<div class="pp-hover-row"><span>${v}</span><span>${u}</span></div>`).join("")}
      <div class="pp-hover-foot" data-pp-hover-foot>${un}</div>`,this.el.style.display="block";let c=this.el.getBoundingClientRect(),d=10,h=r.bottom+d;h+c.height>window.innerHeight-dn&&(h=r.top-c.height-d),h<8&&(h=Math.min(Math.max(8,r.top+8),window.innerHeight-c.height-dn));let m=Math.max(8,Math.min(r.left,window.innerWidth-c.width-8));this.el.style.top=`${h}px`,this.el.style.left=`${m}px`}flash(e){let t=this.el.querySelector("[data-pp-hover-foot]");t&&(t.textContent=e,t.classList.add("pp-hover-flash"),clearTimeout(this.flashTimer),this.flashTimer=window.setTimeout(()=>{t.innerHTML=un,t.classList.remove("pp-hover-flash")},1400))}hide(){this.el.style.display="none"}destroy(){this.el.remove()}};var _;function xi(){window.__pixelpeekActive=!0;let{root:o}=Ht(),e=null,t=null,r=!1,n=new ot(()=>e),i=new it(o),s=new st(o),p=()=>{let m=e??t;r&&m?i.show(m):i.hide()},a=new rt(o,{onOpenWindow:(m,v)=>{typeof chrome<"u"&&chrome.runtime?.id&&chrome.runtime.sendMessage({pp:"open-window",url:location.href,width:m,height:v}).catch(()=>{})},onClose:()=>{},emulate:async m=>{if(typeof chrome>"u"||!chrome.runtime?.id)return{ok:!1,error:"not available here"};try{return await chrome.runtime.sendMessage({pp:"emulate",spec:m})??{ok:!1,error:"no answer from the extension"}}catch(v){return{ok:!1,error:v instanceof Error?v.message.slice(0,100):"failed"}}}}),l=async m=>{let v=await be(m,"element");return await we(v.svg),`Copied ${v.layers} layer${v.layers===1?"":"s"} \u2713`},c=new Je(o,n,{onInspectToggle:m=>d.setEnabled(m),onDeselect:()=>d.release(),onFigmaElement:()=>e?be(e,"element"):Promise.reject(new Error("Select an element first.")),onFigmaHovered:async()=>{let m=e??t;return m?l(m):"Hover or select an element first"},onSaveElement:async m=>{await wt(m,{url:location.href,title:document.title})},onGuides:m=>{r=m,p()},onOpenDevice:m=>a.open(m),onExit:()=>d.closeExtension()}),d=new Le(o,{onLock:m=>{e=m,s.hide(),c.setCapture(gt(m)),p()},onUnlock:()=>{e=null,c.setCapture(null),p()},onScrolling:m=>{m?s.hide():t&&!e&&s.show(t)},onHoverKey:(m,v)=>{if(m==="save"){wt(gt(v),{url:location.href,title:document.title}).then(()=>s.flash("Saved \u2713")).catch(()=>s.flash("Could not save"));return}s.flash("Building Figma layers\u2026"),l(v).then(u=>s.flash(u)).catch(()=>s.flash("Could not copy: press F again"))},onHover:m=>{t=m,m&&!e?s.show(m):s.hide(),p()},onDeactivate:gn,onEscape:()=>a.isOpen?(a.close(),!0):!1});he(document);let h=new nt;_={picker:d,overlay:c,preview:a,guides:i,hover:s,guard:h}}function gn(){window.__pixelpeekActive=!1,_&&(_.guard.destroy(),_.picker.destroy(),_.guides.destroy(),_.hover.destroy(),_.preview.destroy(),_.overlay.destroy()),_=void 0,Bt()}window.__pixelpeekActive?window.__pixelpeekTeardown?.():(xi(),window.__pixelpeekTeardown=gn);})();
